# Create-DMLLS-Documentation-Simple.ps1
# Creates a Word document describing the DMLLS PowerShell folder structure and script purposes

Write-Host "Creating DMLLS Documentation Word Document..." -ForegroundColor Green

Try {
    # Create Word application
    $Word = New-Object -ComObject Word.Application
    $Word.Visible = $False
    
    # Create new document
    $Doc = $Word.Documents.Add()
    
    # Get the range for the document
    $Range = $Doc.Range()
    
    # Title
    $Range.Text = "DMLLS PowerShell Suite`nFolder Structure and Script Documentation`n`n"
    $Range.Font.Size = 18
    $Range.Font.Bold = $True
    $Range.ParagraphFormat.Alignment = 1  # Center alignment
    
    # Add line break
    $Range.Collapse(0)
    $Range.InsertBreak(7)  # Page break
    
    # Overview
    $Range.Text = "1. Overview`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "The Desktop Management Logon/Logoff Suite (DMLLS) PowerShell implementation is a complete replacement for the original VBScript-based solution. This document describes the folder structure and purpose of each script and module within the PS\Prod directory.`n`n"
    $Range.Text = "The PowerShell version provides enhanced error handling, better logging, modular design, and improved maintainability while maintaining full compatibility with the existing backend services.`n`n"
    
    # Main Entry Point Scripts
    $Range.Text = "2. Main Entry Point Scripts`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "These are the primary execution scripts that replace the original DesktopManagement.wsf file:`n`n"
    
    $Range.Text = "• DesktopManagement-Logon.ps1 - Handles user logon events, drive mapping, printer setup, PST configuration, and inventory logging`n"
    $Range.Text = "• DesktopManagement-Logoff.ps1 - Handles user logoff events, cleanup operations, and inventory logging`n"
    $Range.Text = "• DesktopManagement-TSLogon.ps1 - Handles Terminal Server logon events with TS-specific configurations`n"
    $Range.Text = "• DesktopManagement-TSLogoff.ps1 - Handles Terminal Server logoff events with TS-specific cleanup`n`n"
    
    # Modules Framework
    $Range.Text = "3. Modules Framework`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Core framework modules that provide essential functionality:`n`n"
    
    $Range.Text = "• DMLogger.psm1 - Centralized logging system with file and console output, log rotation, and structured formatting`n"
    $Range.Text = "• DMRegistry.psm1 - Registry operations for configuration storage, execution metadata, and state tracking`n"
    $Range.Text = "• DMComputer.psm1 - Computer information gathering including AD properties, groups, site detection, and hardware details`n"
    $Range.Text = "• DMUser.psm1 - User information gathering including AD properties, groups, password expiry, and session details`n"
    $Range.Text = "• DMWorkflowEngine.psm1 - Workflow execution engine that processes configuration-driven action sequences`n`n"
    
    # Modules Services
    $Range.Text = "4. Modules Services`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Web service communication modules for backend integration:`n`n"
    
    $Range.Text = "• DMServiceCommon.psm1 - Common web service utilities including SOAP request handling, authentication, and server discovery`n"
    $Range.Text = "• DMMapperService.psm1 - Retrieves drive mappings, printer mappings, and PST mappings from the backend service`n"
    $Range.Text = "• DMInventoryService.psm1 - Sends inventory data to backend including logon/logoff events and drive inventory`n`n"
    
    # Modules Utilities
    $Range.Text = "5. Modules Utilities`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Utility modules for specific functionality:`n`n"
    
    $Range.Text = "• Test-Environment.psm1 - Environment detection including VPN status, Terminal Server sessions, VM platforms, and Retail/Wholesale users`n"
    $Range.Text = "• Show-PasswordExpiryNotification.psm1 - Displays password expiry warnings with multi-language support and customizable messages`n"
    $Range.Text = "• Import-IEZoneConfiguration.psm1 - Manages Internet Explorer security zone configurations based on user environment`n`n"
    
    # Modules Inventory
    $Range.Text = "6. Modules Inventory`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Inventory management modules:`n`n"
    
    $Range.Text = "• Invoke-UserSessionInventory.psm1 - Handles user session inventory logging for logon and logoff events`n`n"
    
    # Modules Mappers
    $Range.Text = "7. Modules Mappers`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Mapping and configuration modules:`n`n"
    
    $Range.Text = "• Invoke-DriveMapping.psm1 - Manages network drive mappings based on user groups and site configuration`n"
    $Range.Text = "• Invoke-PrinterMapping.psm1 - Manages network printer connections and local printer configuration`n"
    $Range.Text = "• Invoke-PersonalFolderInventory.psm1 - Manages Outlook PST file connections and personal folder mapping`n`n"
    
    # Configuration Files
    $Range.Text = "8. Configuration Files`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Configuration files for regional and workflow settings:`n`n"
    
    $Range.Text = "• RegionalConfig.psd1 - Regional configuration settings including language codes, hotkeys, and regional-specific parameters`n`n"
    
    # Workflow Configuration
    $Range.Text = "9. Workflow Configuration`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Workflow configuration files that define the sequence and parameters for each job type:`n`n"
    
    $Range.Text = "• Workflow-Logon.psd1 - Defines workflow steps and parameters for user logon events`n"
    $Range.Text = "• Workflow-Logoff.psd1 - Defines workflow steps and parameters for user logoff events`n"
    $Range.Text = "• Workflow-TSLogon.psd1 - Defines workflow steps and parameters for Terminal Server logon events`n"
    $Range.Text = "• Workflow-TSLogoff.psd1 - Defines workflow steps and parameters for Terminal Server logoff events`n`n"
    
    # Documents
    $Range.Text = "10. Documents`n`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Font.Size = 11
    $Range.Font.Bold = $False
    $Range.Text = "Documentation and reference files:`n`n"
    
    $Range.Text = "• OBJECT-REFERENCE.md - Reference documentation for all PSCustomObjects and their properties used throughout the system`n"
    $Range.Text = "• START-HERE.txt - Quick start guide and navigation instructions for the DMLLS PowerShell suite`n`n"
    
    # Footer
    $Range.Text = "---`n`n"
    $Range.Text = "Document Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"
    $Range.Text = "DMLLS PowerShell Suite Version: 3.4`n"
    $Range.Text = "Generated by: Create-DMLLS-Documentation-Simple.ps1`n"
    
    # Save the document
    $DocPath = "C:\Temp\Script\DMLLS\PS\Prod\Documents\DMLLS-Folder-Structure-Documentation.docx"
    $Doc.SaveAs2($DocPath)
    
    # Close Word
    $Doc.Close()
    $Word.Quit()
    
    Write-Host "Document created successfully: $DocPath" -ForegroundColor Green
    Write-Host "You can now upload this document to Confluence." -ForegroundColor Yellow
    
} Catch {
    Write-Host "Error creating Word document: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Trying alternative method..." -ForegroundColor Yellow
    
    # Alternative: Create RTF file
    Try {
        $RTFContent = @"
{\rtf1\ansi\deff0 {\fonttbl {\f0 Times New Roman;}}
{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green128\blue0;}
{\*\generator DMLLS Documentation Generator;}

{\f0\fs28\b\cf2 DMLLS PowerShell Suite\par
Folder Structure and Script Documentation\par\par}

{\f0\fs20\b 1. Overview\par\par}
{\f0\fs18 The Desktop Management Logon/Logoff Suite (DMLLS) PowerShell implementation is a complete replacement for the original VBScript-based solution. This document describes the folder structure and purpose of each script and module within the PS\\Prod directory.\par\par
The PowerShell version provides enhanced error handling, better logging, modular design, and improved maintainability while maintaining full compatibility with the existing backend services.\par\par}

{\f0\fs20\b 2. Main Entry Point Scripts\par\par}
{\f0\fs18 These are the primary execution scripts that replace the original DesktopManagement.wsf file:\par\par
• DesktopManagement-Logon.ps1 - Handles user logon events, drive mapping, printer setup, PST configuration, and inventory logging\par
• DesktopManagement-Logoff.ps1 - Handles user logoff events, cleanup operations, and inventory logging\par
• DesktopManagement-TSLogon.ps1 - Handles Terminal Server logon events with TS-specific configurations\par
• DesktopManagement-TSLogoff.ps1 - Handles Terminal Server logoff events with TS-specific cleanup\par\par}

{\f0\fs20\b 3. Modules Framework\par\par}
{\f0\fs18 Core framework modules that provide essential functionality:\par\par
• DMLogger.psm1 - Centralized logging system with file and console output, log rotation, and structured formatting\par
• DMRegistry.psm1 - Registry operations for configuration storage, execution metadata, and state tracking\par
• DMComputer.psm1 - Computer information gathering including AD properties, groups, site detection, and hardware details\par
• DMUser.psm1 - User information gathering including AD properties, groups, password expiry, and session details\par
• DMWorkflowEngine.psm1 - Workflow execution engine that processes configuration-driven action sequences\par\par}

{\f0\fs20\b 4. Modules Services\par\par}
{\f0\fs18 Web service communication modules for backend integration:\par\par
• DMServiceCommon.psm1 - Common web service utilities including SOAP request handling, authentication, and server discovery\par
• DMMapperService.psm1 - Retrieves drive mappings, printer mappings, and PST mappings from the backend service\par
• DMInventoryService.psm1 - Sends inventory data to backend including logon/logoff events and drive inventory\par\par}

{\f0\fs20\b 5. Modules Utilities\par\par}
{\f0\fs18 Utility modules for specific functionality:\par\par
• Test-Environment.psm1 - Environment detection including VPN status, Terminal Server sessions, VM platforms, and Retail/Wholesale users\par
• Show-PasswordExpiryNotification.psm1 - Displays password expiry warnings with multi-language support and customizable messages\par
• Import-IEZoneConfiguration.psm1 - Manages Internet Explorer security zone configurations based on user environment\par\par}

{\f0\fs20\b 6. Modules Inventory\par\par}
{\f0\fs18 Inventory management modules:\par\par
• Invoke-UserSessionInventory.psm1 - Handles user session inventory logging for logon and logoff events\par\par}

{\f0\fs20\b 7. Modules Mappers\par\par}
{\f0\fs18 Mapping and configuration modules:\par\par
• Invoke-DriveMapping.psm1 - Manages network drive mappings based on user groups and site configuration\par
• Invoke-PrinterMapping.psm1 - Manages network printer connections and local printer configuration\par
• Invoke-PersonalFolderInventory.psm1 - Manages Outlook PST file connections and personal folder mapping\par\par}

{\f0\fs20\b 8. Configuration Files\par\par}
{\f0\fs18 Configuration files for regional and workflow settings:\par\par
• RegionalConfig.psd1 - Regional configuration settings including language codes, hotkeys, and regional-specific parameters\par\par}

{\f0\fs20\b 9. Workflow Configuration\par\par}
{\f0\fs18 Workflow configuration files that define the sequence and parameters for each job type:\par\par
• Workflow-Logon.psd1 - Defines workflow steps and parameters for user logon events\par
• Workflow-Logoff.psd1 - Defines workflow steps and parameters for user logoff events\par
• Workflow-TSLogon.psd1 - Defines workflow steps and parameters for Terminal Server logon events\par
• Workflow-TSLogoff.psd1 - Defines workflow steps and parameters for Terminal Server logoff events\par\par}

{\f0\fs20\b 10. Documents\par\par}
{\f0\fs18 Documentation and reference files:\par\par
• OBJECT-REFERENCE.md - Reference documentation for all PSCustomObjects and their properties used throughout the system\par
• START-HERE.txt - Quick start guide and navigation instructions for the DMLLS PowerShell suite\par\par}

{\f0\fs16 ---\par\par
Document Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')\par
DMLLS PowerShell Suite Version: 3.4\par
Generated by: Create-DMLLS-Documentation-Simple.ps1\par}
"@
        
        $RTFPath = "C:\Temp\Script\DMLLS\PS\Prod\Documents\DMLLS-Folder-Structure-Documentation.rtf"
        $RTFContent | Out-File -FilePath $RTFPath -Encoding ASCII
        
        Write-Host "RTF document created successfully: $RTFPath" -ForegroundColor Green
        Write-Host "You can open this in Word and save as .docx for Confluence upload." -ForegroundColor Yellow
        
    } Catch {
        Write-Host "Error creating RTF document: $($_.Exception.Message)" -ForegroundColor Red
    }
}
