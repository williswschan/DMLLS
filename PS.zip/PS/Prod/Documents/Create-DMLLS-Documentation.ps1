# Create-DMLLS-Documentation.ps1
# Creates a Word document describing the DMLLS PowerShell folder structure and script purposes

Write-Host "Creating DMLLS Documentation Word Document..." -ForegroundColor Green

Try {
    # Create Word application
    $Word = New-Object -ComObject Word.Application
    $Word.Visible = $False
    
    # Create new document
    $Doc = $Word.Documents.Add()
    
    # Set document properties
    $Doc.BuiltInDocumentProperties("Title").Value = "DMLLS PowerShell Suite - Folder Structure and Script Documentation"
    $Doc.BuiltInDocumentProperties("Author").Value = "Desktop Management Team"
    $Doc.BuiltInDocumentProperties("Subject").Value = "Desktop Management Logon/Logoff Suite - PowerShell Implementation"
    
    # Get the range for the document
    $Range = $Doc.Range()
    
    # Title
    $Range.Style = "Title"
    $Range.Text = "DMLLS PowerShell Suite`nFolder Structure and Script Documentation`n`n"
    $Range.Font.Size = 18
    $Range.Font.Bold = $True
    $Range.ParagraphFormat.Alignment = 1  # Center alignment
    
    # Add line break
    $Range.Collapse(0)  # wdCollapseEnd
    $Range.InsertBreak(7)  # wdPageBreak
    
    # Table of Contents
    $Range.Style = "Heading 1"
    $Range.Text = "Table of Contents`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Text = "1. Overview`n"
    $Range.Text = "2. Main Entry Point Scripts`n"
    $Range.Text = "3. Modules Framework`n"
    $Range.Text = "4. Modules Services`n"
    $Range.Text = "5. Modules Utilities`n"
    $Range.Text = "6. Modules Inventory`n"
    $Range.Text = "7. Modules Mappers`n"
    $Range.Text = "8. Configuration Files`n"
    $Range.Text = "9. Workflow Configuration`n"
    $Range.Text = "10. Documents`n`n"
    
    # Add page break
    $Range.Collapse(0)
    $Range.InsertBreak(7)  # wdPageBreak
    
    # 1. Overview
    $Range.Style = "Heading 1"
    $Range.Text = "1. Overview`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "The Desktop Management Logon/Logoff Suite (DMLLS) PowerShell implementation is a complete replacement for the original VBScript-based solution. This document describes the folder structure and purpose of each script and module within the PS\Prod directory.`n`n"
    $Range.Text = "The PowerShell version provides enhanced error handling, better logging, modular design, and improved maintainability while maintaining full compatibility with the existing backend services.`n`n"
    
    # 2. Main Entry Point Scripts
    $Range.Style = "Heading 1"
    $Range.Text = "2. Main Entry Point Scripts`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "These are the primary execution scripts that replace the original DesktopManagement.wsf file:`n`n"
    
    # Create table for entry point scripts
    $Table = $Doc.Tables.Add($Range, 4, 3)
    $Table.Style = "Table Grid"
    $Table.Cell(1,1).Range.Text = "Script Name"
    $Table.Cell(1,2).Range.Text = "Purpose"
    $Table.Cell(1,3).Range.Text = "Replaces"
    
    $Table.Cell(2,1).Range.Text = "DesktopManagement-Logon.ps1"
    $Table.Cell(2,2).Range.Text = "Handles user logon events, drive mapping, printer setup, PST configuration, and inventory logging"
    $Table.Cell(2,3).Range.Text = "DesktopManagement.wsf (Logon job)"
    
    $Table.Cell(3,1).Range.Text = "DesktopManagement-Logoff.ps1"
    $Table.Cell(3,2).Range.Text = "Handles user logoff events, cleanup operations, and inventory logging"
    $Table.Cell(3,3).Range.Text = "DesktopManagement.wsf (Logoff job)"
    
    $Table.Cell(4,1).Range.Text = "DesktopManagement-TSLogon.ps1"
    $Table.Cell(4,2).Range.Text = "Handles Terminal Server logon events with TS-specific configurations"
    $Table.Cell(4,3).Range.Text = "DesktopManagement.wsf (TSLogon job)"
    
    $Table.Cell(5,1).Range.Text = "DesktopManagement-TSLogoff.ps1"
    $Table.Cell(5,2).Range.Text = "Handles Terminal Server logoff events with TS-specific cleanup"
    $Table.Cell(5,3).Range.Text = "DesktopManagement.wsf (TSLogoff job)"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 3. Modules Framework
    $Range.Style = "Heading 1"
    $Range.Text = "3. Modules Framework`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Core framework modules that provide essential functionality:`n`n"
    
    # Framework modules table
    $Table2 = $Doc.Tables.Add($Range, 6, 2)
    $Table2.Style = "Table Grid"
    $Table2.Cell(1,1).Range.Text = "Module Name"
    $Table2.Cell(1,2).Range.Text = "Purpose"
    
    $Table2.Cell(2,1).Range.Text = "DMLogger.psm1"
    $Table2.Cell(2,2).Range.Text = "Centralized logging system with file and console output, log rotation, and structured formatting"
    
    $Table2.Cell(3,1).Range.Text = "DMRegistry.psm1"
    $Table2.Cell(3,2).Range.Text = "Registry operations for configuration storage, execution metadata, and state tracking"
    
    $Table2.Cell(4,1).Range.Text = "DMComputer.psm1"
    $Table2.Cell(4,2).Range.Text = "Computer information gathering including AD properties, groups, site detection, and hardware details"
    
    $Table2.Cell(5,1).Range.Text = "DMUser.psm1"
    $Table2.Cell(5,2).Range.Text = "User information gathering including AD properties, groups, password expiry, and session details"
    
    $Table2.Cell(6,1).Range.Text = "DMWorkflowEngine.psm1"
    $Table2.Cell(6,2).Range.Text = "Workflow execution engine that processes configuration-driven action sequences"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 4. Modules Services
    $Range.Style = "Heading 1"
    $Range.Text = "4. Modules Services`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Web service communication modules for backend integration:`n`n"
    
    # Services modules table
    $Table3 = $Doc.Tables.Add($Range, 3, 2)
    $Table3.Style = "Table Grid"
    $Table3.Cell(1,1).Range.Text = "Module Name"
    $Table3.Cell(1,2).Range.Text = "Purpose"
    
    $Table3.Cell(2,1).Range.Text = "DMServiceCommon.psm1"
    $Table3.Cell(2,2).Range.Text = "Common web service utilities including SOAP request handling, authentication, and server discovery"
    
    $Table3.Cell(3,1).Range.Text = "DMMapperService.psm1"
    $Table3.Cell(3,2).Range.Text = "Retrieves drive mappings, printer mappings, and PST mappings from the backend service"
    
    $Table3.Cell(4,1).Range.Text = "DMInventoryService.psm1"
    $Table3.Cell(4,2).Range.Text = "Sends inventory data to backend including logon/logoff events and drive inventory"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 5. Modules Utilities
    $Range.Style = "Heading 1"
    $Range.Text = "5. Modules Utilities`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Utility modules for specific functionality:`n`n"
    
    # Utilities modules table
    $Table4 = $Doc.Tables.Add($Range, 4, 2)
    $Table4.Style = "Table Grid"
    $Table4.Cell(1,1).Range.Text = "Module Name"
    $Table4.Cell(1,2).Range.Text = "Purpose"
    
    $Table4.Cell(2,1).Range.Text = "Test-Environment.psm1"
    $Table4.Cell(2,2).Range.Text = "Environment detection including VPN status, Terminal Server sessions, VM platforms, and Retail/Wholesale users"
    
    $Table4.Cell(3,1).Range.Text = "Show-PasswordExpiryNotification.psm1"
    $Table4.Cell(3,2).Range.Text = "Displays password expiry warnings with multi-language support and customizable messages"
    
    $Table4.Cell(4,1).Range.Text = "Import-IEZoneConfiguration.psm1"
    $Table4.Cell(4,2).Range.Text = "Manages Internet Explorer security zone configurations based on user environment"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 6. Modules Inventory
    $Range.Style = "Heading 1"
    $Range.Text = "6. Modules Inventory`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Inventory management modules:`n`n"
    
    # Inventory modules table
    $Table5 = $Doc.Tables.Add($Range, 2, 2)
    $Table5.Style = "Table Grid"
    $Table5.Cell(1,1).Range.Text = "Module Name"
    $Table5.Cell(1,2).Range.Text = "Purpose"
    
    $Table5.Cell(2,1).Range.Text = "Invoke-UserSessionInventory.psm1"
    $Table5.Cell(2,2).Range.Text = "Handles user session inventory logging for logon and logoff events"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 7. Modules Mappers
    $Range.Style = "Heading 1"
    $Range.Text = "7. Modules Mappers`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Mapping and configuration modules:`n`n"
    
    # Mappers modules table
    $Table6 = $Doc.Tables.Add($Range, 4, 2)
    $Table6.Style = "Table Grid"
    $Table6.Cell(1,1).Range.Text = "Module Name"
    $Table6.Cell(1,2).Range.Text = "Purpose"
    
    $Table6.Cell(2,1).Range.Text = "Invoke-DriveMapping.psm1"
    $Table6.Cell(2,2).Range.Text = "Manages network drive mappings based on user groups and site configuration"
    
    $Table6.Cell(3,1).Range.Text = "Invoke-PrinterMapping.psm1"
    $Table6.Cell(3,2).Range.Text = "Manages network printer connections and local printer configuration"
    
    $Table6.Cell(4,1).Range.Text = "Invoke-PersonalFolderInventory.psm1"
    $Table6.Cell(4,2).Range.Text = "Manages Outlook PST file connections and personal folder mapping"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 8. Configuration Files
    $Range.Style = "Heading 1"
    $Range.Text = "8. Configuration Files`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Configuration files for regional and workflow settings:`n`n"
    
    # Config files table
    $Table7 = $Doc.Tables.Add($Range, 2, 2)
    $Table7.Style = "Table Grid"
    $Table7.Cell(1,1).Range.Text = "File Name"
    $Table7.Cell(1,2).Range.Text = "Purpose"
    
    $Table7.Cell(2,1).Range.Text = "RegionalConfig.psd1"
    $Table7.Cell(2,2).Range.Text = "Regional configuration settings including language codes, hotkeys, and regional-specific parameters"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 9. Workflow Configuration
    $Range.Style = "Heading 1"
    $Range.Text = "9. Workflow Configuration`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Workflow configuration files that define the sequence and parameters for each job type:`n`n"
    
    # Workflow config table
    $Table8 = $Doc.Tables.Add($Range, 5, 2)
    $Table8.Style = "Table Grid"
    $Table8.Cell(1,1).Range.Text = "File Name"
    $Table8.Cell(1,2).Range.Text = "Purpose"
    
    $Table8.Cell(2,1).Range.Text = "Workflow-Logon.psd1"
    $Table8.Cell(2,2).Range.Text = "Defines workflow steps and parameters for user logon events"
    
    $Table8.Cell(3,1).Range.Text = "Workflow-Logoff.psd1"
    $Table8.Cell(3,2).Range.Text = "Defines workflow steps and parameters for user logoff events"
    
    $Table8.Cell(4,1).Range.Text = "Workflow-TSLogon.psd1"
    $Table8.Cell(4,2).Range.Text = "Defines workflow steps and parameters for Terminal Server logon events"
    
    $Table8.Cell(5,1).Range.Text = "Workflow-TSLogoff.psd1"
    $Table8.Cell(5,2).Range.Text = "Defines workflow steps and parameters for Terminal Server logoff events"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # 10. Documents
    $Range.Style = "Heading 1"
    $Range.Text = "10. Documents`n"
    $Range.Font.Size = 14
    $Range.Font.Bold = $True
    
    $Range.Collapse(0)
    $Range.Style = "Normal"
    $Range.Text = "Documentation and reference files:`n`n"
    
    # Documents table
    $Table9 = $Doc.Tables.Add($Range, 3, 2)
    $Table9.Style = "Table Grid"
    $Table9.Cell(1,1).Range.Text = "File Name"
    $Table9.Cell(1,2).Range.Text = "Purpose"
    
    $Table9.Cell(2,1).Range.Text = "OBJECT-REFERENCE.md"
    $Table9.Cell(2,2).Range.Text = "Reference documentation for all PSCustomObjects and their properties used throughout the system"
    
    $Table9.Cell(3,1).Range.Text = "START-HERE.txt"
    $Table9.Cell(3,2).Range.Text = "Quick start guide and navigation instructions for the DMLLS PowerShell suite"
    
    # Move cursor after table
    $Range = $Doc.Range()
    $Range.Collapse(0)
    $Range.MoveEnd(0, -1)
    $Range.Collapse(0)
    $Range.Text = "`n`n"
    
    # Footer
    $Range.Style = "Normal"
    $Range.Text = "`n`n---`n`n"
    $Range.Text = "Document Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"
    $Range.Text = "DMLLS PowerShell Suite Version: 3.4`n"
    $Range.Text = "Generated by: Create-DMLLS-Documentation.ps1`n"
    
    # Save the document
    $DocPath = "C:\Temp\Script\DMLLS\PS\Prod\Documents\DMLLS-Folder-Structure-Documentation.docx"
    $Doc.SaveAs2($DocPath)
    
    # Close Word
    $Doc.Close()
    $Word.Quit()
    
    Write-Host "Document created successfully: $DocPath" -ForegroundColor Green
    Write-Host "You can now upload this document to Confluence." -ForegroundColor Yellow
    
} Catch {
    Write-Host "Error creating Word document: $($_.Exception.Message)" -ForegroundColor Red
    If ($Word) {
        $Word.Quit()
    }
}
