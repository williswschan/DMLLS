# Desktop Management Suite - Deployment Guide

**Version:** 2.0.0  
**Last Updated:** 2025-10-13  
**Status:** Ready for Production Deployment

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Deployment Steps](#deployment-steps)
4. [Entry Point Scripts](#entry-point-scripts)
5. [Group Policy Configuration](#group-policy-configuration)
6. [Validation](#validation)
7. [Rollback Plan](#rollback-plan)
8. [Troubleshooting](#troubleshooting)

---

## Overview

The PowerShell Desktop Management Suite is a complete replacement for the VBScript-based DMLLS system. It provides:

- ✅ User session tracking (logon/logoff)
- ✅ Network drive mapping
- ✅ Network printer mapping
- ✅ Outlook PST file mapping
- ✅ Drive/printer/PST inventory collection
- ✅ Power management configuration
- ✅ Password expiry notifications
- ✅ Retail-specific customizations

---

## Prerequisites

### Domain Environment
- ✅ Domain-joined computers (Windows 10 or Server)
- ✅ Active Directory access
- ✅ Backend services accessible (`gdpmappercb.nomura.com`)

### PowerShell Requirements
- ✅ PowerShell 5.1 or later (Windows PowerShell)
- ✅ Execution policy: RemoteSigned or Bypass
- ✅ COM object support (for Outlook, Shell.Application)

### Network Access
- ✅ Backend web services (Mapper and Inventory)
- ✅ LDAP/AD connectivity
- ✅ Network share access (for script deployment)

---

## Deployment Steps

### Step 1: Copy Files to Network Share

```powershell
# Copy entire PS/Prod folder to network share
Copy-Item -Path "C:\Temp\Script\DMLLS\PS\Prod" -Destination "\\domain\netlogon\DesktopManagement" -Recurse
```

**Recommended Share Location:**
```
\\<DOMAIN>\NETLOGON\DesktopManagement\
or
\\<DOMAIN>\SYSVOL\<DOMAIN>\Scripts\DesktopManagement\
```

### Step 2: Set Execution Policy (If Needed)

```powershell
# On client computers (via GPO or manually)
Set-ExecutionPolicy RemoteSigned -Scope LocalMachine
```

### Step 3: Configure Group Policy

Create GPO with logon/logoff scripts:

**User Configuration → Windows Settings → Scripts**

**Logon Scripts:**
- Desktop/Laptop: `\\domain\netlogon\DesktopManagement\DesktopManagement-Logon.ps1`
- Terminal Server: `\\domain\netlogon\DesktopManagement\DesktopManagement-TSLogon.ps1`

**Logoff Scripts:**
- Desktop/Laptop: `\\domain\netlogon\DesktopManagement\DesktopManagement-Logoff.ps1`
- Terminal Server: `\\domain\netlogon\DesktopManagement\DesktopManagement-TSLogoff.ps1`

**Script Parameters:**
- Default: (none)
- Verbose: `-VerboseLogging`
- Custom log age: `-MaxLogAge 30`

### Step 4: Pilot Deployment

1. **Create pilot groups** in AD:
   - `Pilot Desktop Management Script-<REGION>-U` (users)
   - `Pilot Desktop Management Script-<REGION>-C` (computers)

2. **Apply GPO to pilot group** only

3. **Monitor logs** on pilot users:
   - `%USERPROFILE%\Nomura\GDP\Desktop Management\*.log`

4. **Validate functionality:**
   - Check drives mapped
   - Check printers mapped
   - Check backend data (inventory collected)

### Step 5: Production Rollout

1. **Disable VBScript WSF** (via GPO)
2. **Enable PowerShell scripts** for all users
3. **Monitor for issues**
4. **Collect feedback**

---

## Entry Point Scripts

### 1. DesktopManagement-Logon.ps1

**Purpose:** Windows 10/11 desktop user logon

**Workflow:**
1. Initialize logging and gather system info
2. Send logon inventory
3. Map drives, printers, PST files
4. Configure power settings
5. Show password expiry notification
6. Apply IE zones (legacy)
7. Set Retail V: drive label

**Usage:**
```powershell
.\DesktopManagement-Logon.ps1
.\DesktopManagement-Logon.ps1 -VerboseLogging
```

### 2. DesktopManagement-Logoff.ps1

**Purpose:** Windows 10/11 desktop user logoff

**Workflow:**
1. Initialize logging and gather system info
2. Send logoff inventory
3. Send drive/printer/PST inventory
4. Revert power settings to default

**Usage:**
```powershell
.\DesktopManagement-Logoff.ps1
```

### 3. DesktopManagement-TSLogon.ps1

**Purpose:** Terminal Server/Citrix user logon

**Workflow (Simplified):**
1. Initialize logging and gather system info
2. Send logon inventory
3. Map drives only (no printers/PST)
4. Apply IE zones (legacy)

**Usage:**
```powershell
.\DesktopManagement-TSLogon.ps1
```

### 4. DesktopManagement-TSLogoff.ps1

**Purpose:** Terminal Server/Citrix user logoff

**Workflow (Minimal):**
1. Initialize logging and gather system info
2. Send logoff inventory
3. Send drive inventory only

**Usage:**
```powershell
.\DesktopManagement-TSLogoff.ps1
```

---

## Group Policy Configuration

### Logon Script Configuration

1. Open **Group Policy Management**
2. Edit target GPO
3. Navigate to: **User Configuration → Policies → Windows Settings → Scripts (Logon/Logoff)**
4. Add scripts:

**For Desktops:**
- Logon: `DesktopManagement-Logon.ps1`
- Logoff: `DesktopManagement-Logoff.ps1`

**For Terminal Servers:**
- Logon: `DesktopManagement-TSLogon.ps1`
- Logoff: `DesktopManagement-TSLogoff.ps1`

### PowerShell Execution Policy (GPO)

**Computer Configuration → Policies → Administrative Templates → Windows Components → Windows PowerShell**

- **Turn on Script Execution:** Enabled
- **Execution Policy:** RemoteSigned

---

## Validation

### On Domain-Joined Computer

**Step 1: Run Validation Script**
```powershell
cd \\domain\netlogon\DesktopManagement
.\Validate-DomainFeatures.ps1
```

**Expected Results:**
- ✅ Domain Join: PASS
- ✅ Computer DN: PASS (shows full DN)
- ✅ User DN: PASS (shows full DN)
- ✅ Computer Groups: PASS (shows groups)
- ✅ User Groups: PASS (shows groups)
- ✅ City Code: PASS (extracts city)
- ✅ LDAP Connectivity: PASS
- ✅ Backend Services: PASS (if accessible)

**If any checks FAIL:**
- Review the detailed log file
- Check AD connectivity
- Verify backend service access

### Test Individual Components

**Test Logon Script:**
```powershell
.\DesktopManagement-Logon.ps1 -VerboseLogging
```

**Check Log:**
```powershell
cd "$env:USERPROFILE\Nomura\GDP\Desktop Management"
dir *.log | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | Get-Content
```

**Verify Drives Mapped:**
```powershell
net use
```

**Verify Backend Data:**
- Contact backend admin to verify inventory data received
- Check drive/printer/PST mappings in database

---

## Rollback Plan

### Immediate Rollback (If Issues)

1. **Disable PowerShell GPO**
2. **Re-enable VBScript WSF**
3. **Force GPO update:** `gpupdate /force`
4. **Users logoff/logon** to apply old scripts

### Files to Revert

Keep VBScript files until PowerShell proven stable:
- ✅ VB/DesktopManagement.wsf
- ✅ VB/Source/*.vbs

### Gradual Migration

**Week 1-2:** Pilot group (50-100 users)  
**Week 3-4:** Expand to 500 users  
**Week 5-6:** Regional rollout  
**Week 7+:** Full deployment

---

## Troubleshooting

### Issue: Scripts Not Running

**Check:**
```powershell
# Execution policy
Get-ExecutionPolicy

# Script path accessible
Test-Path "\\domain\netlogon\DesktopManagement\DesktopManagement-Logon.ps1"

# GPO applied
gpresult /r
```

### Issue: Drives Not Mapping

**Check:**
- Log file for errors
- Backend service connectivity
- User group memberships
- VPN detection (drives skip if VPN connected)

### Issue: Slow Logon

**Potential causes:**
- LDAP queries slow (forest-wide group enumeration)
- Backend service slow
- Too many drives/printers to map

**Solutions:**
- Check network connectivity
- Review log file for slow operations
- Consider caching AD queries (future optimization)

### Issue: No Data in Backend

**Check:**
- Inventory service connectivity
- SOAP request/response in log file
- Backend database logs
- Firewall rules

---

## Log Files

### Location
```
%USERPROFILE%\Nomura\GDP\Desktop Management\
```

### File Naming
```
<JobType>_<ComputerName>_<Timestamp>.log

Examples:
- Logon_WKS001_20251013120530.log
- Logoff_WKS001_20251013180530.log
- TSLogon_CITRIX01_20251013090000.log
```

### Log Retention
- Default: 60 days
- Configurable: `-MaxLogAge` parameter
- Old logs auto-purged at each run

### Verbose Logging

Enable with `-VerboseLogging` parameter:
```powershell
.\DesktopManagement-Logon.ps1 -VerboseLogging
```

This logs additional details for troubleshooting.

---

## Registry Tracking

### Execution Metadata

**Location:**
```
HKCU:\Software\Nomura\GDP\Desktop Management\<JobType>
```

**Values Stored:**
- Version (2.0.0)
- LastRun (timestamp)
- UserName
- ComputerName
- ScriptEngine (PowerShell)
- PSVersion

**Purpose:**
- Track script executions
- Audit trail
- Version tracking

---

## Workflow Configuration

### Disable Features Without Code Changes

Edit workflow config files: `Config\Workflow-*.psd1`

**Examples:**
```powershell
# Disable printer inventory (in Workflow-Logoff.psd1)
@{
    Name = 'Printer Inventory'
    Enabled = $False  # Changed from $True
    # ... rest unchanged
}

# Disable password notifications (in Workflow-Logon.psd1)
@{
    Name = 'Password Expiry Notification'
    Enabled = $False
    # ... rest unchanged
}
```

Apply changes:
- Copy updated workflow config to network share
- Users will use new settings on next logon

---

## Performance Tuning

### Current Performance Targets

- Logon: < 30 seconds
- Logoff: < 15 seconds

### If Performance Issues

**Check:**
1. LDAP query time (forest-wide group enumeration)
2. Backend service response time
3. Network latency to file shares
4. Outlook COM operations (PST mapping)

**Optimize:**
- Reduce LDAP scope (query single domain vs entire forest)
- Cache AD results (future enhancement)
- Parallel web service calls (future enhancement)

---

## Security Considerations

### Script Signing

**Recommended for production:**
```powershell
# Sign all .ps1 and .psm1 files
Set-AuthenticodeSignature -FilePath "DesktopManagement-Logon.ps1" -Certificate $cert
```

Update execution policy to `AllSigned` if scripts are signed.

### Credentials

- ✅ No credentials stored in scripts
- ✅ Uses logged-in user context
- ✅ LDAP queries use implicit auth
- ✅ Backend services use Windows Authentication (assumed)

### Sensitive Data

- ⚠️ Log files contain user/computer names
- ⚠️ Logs stored in user profile (limited access)
- ✅ No passwords logged
- ✅ No sensitive business data logged

---

## Support & Maintenance

### Common Tasks

**Update backend server URL:**
- Edit `Config\Settings.psd1`
- Update `Mapper.ProductionServer` or `Inventory.ProductionServer`

**Change log retention:**
- Edit `Config\Settings.psd1`
- Update `Logging.MaxAge`

**Disable a feature:**
- Edit `Config\FeatureFlags.psd1`
- Set feature to `$False`

### Version Updates

**To deploy new version:**
1. Update version number in entry point scripts
2. Test in Pilot environment
3. Copy to production network share
4. Monitor rollout

### Monitoring

**Check success rate:**
- Review backend inventory data
- Check for error logs
- Monitor help desk tickets

**Key metrics:**
- % users with successful logon
- Average logon time
- Backend data completeness
- Error rate by module

---

## Comparison: VBScript vs PowerShell

| Aspect | VBScript | PowerShell |
|--------|----------|------------|
| Entry Point | 1 WSF file, 4 job IDs | 4 separate .ps1 scripts |
| Configuration | Hardcoded in WSF | External .psd1 files |
| Modules | 20 .vbs files | 18 .psm1 files |
| Testing | Manual | Automated test scripts |
| Debugging | Limited (Echo) | Full ISE/VSCode support |
| Error Handling | On Error Resume Next | Try/Catch |
| Performance | Slower | Faster (.NET compiled) |
| Maintainability | Difficult | Modular, documented |

---

## Contact & Support

**For issues:**
1. Check log files first
2. Review this deployment guide
3. Run validation script on affected computer
4. Contact Desktop Management team with log files

**For feature requests:**
- Update workflow config to set Enabled = $False
- Submit enhancement request with business justification

---

**End of Deployment Guide**

