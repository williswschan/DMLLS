# How to Add New Actions to Desktop Management Suite

**Workflow-Based Architecture**  
**Version:** 2.0.0  
**Last Updated:** 2025-10-13

---

## 📋 Overview

The Desktop Management Suite uses a **workflow-based architecture**. All actions are defined in workflow configuration files (`Config/Workflow-*.psd1`), making it easy to add, remove, or reorder actions **without modifying entry point scripts**.

This is similar to the VBScript WSF approach where jobs were defined with included scripts.

---

## 🎯 Quick Start: Add New Action

### Example: Add "Copy Office Templates" to Logon

**What you want:** Copy MS Office templates to user's local machine during logon.

**Steps:**

### 1️⃣ Create the Module

**File:** `Modules/Utilities/Copy-OfficeTemplates.psm1`

```powershell
<#
.SYNOPSIS
    Copies MS Office templates to user's local machine
#>

Using Module ..\Framework\DMLogger.psm1

Function Invoke-DMOfficeTemplatesCopy {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo
    )
    
    Try {
        Write-DMLog "Office Templates: Starting template copy" -Level Info
        
        [String]$SourcePath = "\\$($ComputerInfo.Domain)\NETLOGON\OfficeTemplates"
        [String]$DestPath = "$env:APPDATA\Microsoft\Templates"
        
        # Check source exists
        If (-not (Test-Path $SourcePath)) {
            Write-DMLog "Office Templates: Source path not found, skipping" -Level Warning
            Return $True
        }
        
        # Create destination
        If (-not (Test-Path $DestPath)) {
            New-Item -ItemType Directory -Path $DestPath -Force | Out-Null
            Write-DMLog "Office Templates: Created destination folder" -Level Verbose
        }
        
        # Copy files
        $Files = Copy-Item -Path "$SourcePath\*" -Destination $DestPath -Force -PassThru
        
        Write-DMLog "Office Templates: Copied $($Files.Count) template file(s)" -Level Info
        Write-DMLog "Office Templates: Completed" -Level Info
        
        Return $True
    } Catch {
        Write-DMLog "Office Templates: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

Export-ModuleMember -Function @('Invoke-DMOfficeTemplatesCopy')
```

### 2️⃣ Add to Workflow Configuration

**File:** `Config/Workflow-Logon.psd1`

Find the `Steps` array and add:

```powershell
Steps = @(
    # ... existing steps ...
    
    @{
        Order = 340  # After Retail Label (330), before end
        Name = 'Copy Office Templates'
        Phase = 'Utilities'
        Module = 'Utilities\Copy-OfficeTemplates.psm1'
        Function = 'Invoke-DMOfficeTemplatesCopy'
        Enabled = $True
        Parameters = @{
            UserInfo = 'UserInfo'
            ComputerInfo = 'ComputerInfo'
        }
        ContinueOnError = $True
        Description = 'Copy MS Office templates to local machine'
    }
)
```

### 3️⃣ Deploy and Test

```powershell
# Test the new action
.\DesktopManagement-Logon.ps1 -VerboseLogging

# Check logs
cd "$env:USERPROFILE\Nomura\GDP\Desktop Management"
Get-Content (Get-ChildItem *.log | Sort-Object LastWriteTime -Descending | Select-Object -First 1)
```

**Expected log output:**
```
[20251013120000] --- Copy Office Templates ---
[20251013120001] Office Templates: Starting template copy
[20251013120002] Office Templates: Copied 25 template file(s)
[20251013120002] Office Templates: Completed
```

### 4️⃣ Done!

**No changes needed to:**
- ✅ Entry point scripts (DesktopManagement-*.ps1)
- ✅ Other modules
- ✅ Group Policy configuration

---

## 📖 Step-by-Step Guide

### Module Requirements

Your module **MUST**:

1. **Accept standard parameters:**
   ```powershell
   Param(
       [Parameter(Mandatory=$True)]
       [PSCustomObject]$UserInfo,
       
       [Parameter(Mandatory=$True)]
       [PSCustomObject]$ComputerInfo
   )
   ```

2. **Use Write-DMLog for all output:**
   ```powershell
   Write-DMLog "Your Action: Message" -Level Info
   Write-DMLog "Your Action: Warning" -Level Warning
   Write-DMLog "Your Action: Error" -Level Error
   ```

3. **Return Boolean:**
   ```powershell
   Return $True   # Success
   Return $False  # Failure
   ```

4. **Handle errors:**
   ```powershell
   Try {
       # Your logic
   } Catch {
       Write-DMLog "Your Action: Error - $($_.Exception.Message)" -Level Error
       Return $False
   }
   ```

5. **Export function:**
   ```powershell
   Export-ModuleMember -Function @('Invoke-DMYourAction')
   ```

---

## 🔧 Workflow Step Configuration

### Required Fields

```powershell
@{
    Order = 100                  # Execution order (lower = earlier)
    Name = 'Action Name'         # Display name for logs
    Phase = 'Utilities'          # Category (Inventory, Mapper, Utilities)
    Module = 'Path\Module.psm1'  # Module path (relative to Modules/)
    Function = 'Invoke-DMAction' # Function to call
    Enabled = $True              # Enable/disable
    Parameters = @{ ... }        # Function parameters
}
```

### Optional Fields

```powershell
@{
    # ... required fields ...
    
    ContinueOnError = $True      # Don't stop workflow if this fails
    Description = 'What it does' # Documentation
    TimeoutSeconds = 30          # Not implemented yet (future)
    RunIf = 'Condition'          # Not implemented yet (future)
}
```

---

## 🎨 Parameter Mapping

### Context Variables (from workflow context)

```powershell
Parameters = @{
    UserInfo = 'UserInfo'           # Gets $Context.UserInfo
    ComputerInfo = 'ComputerInfo'   # Gets $Context.ComputerInfo
}
```

### Static Values (hardcoded)

```powershell
Parameters = @{
    JobType = 'Static:Logon'        # Passes string "Logon"
    Path = 'Static:C:\Temp'         # Passes string "C:\Temp"
}
```

### Example: Mixed Parameters

```powershell
Parameters = @{
    UserInfo = 'UserInfo'              # From context
    ComputerInfo = 'ComputerInfo'      # From context
    SourcePath = 'Static:\\domain\share\templates'  # Static string
    Overwrite = 'Static:true'          # Static value
}
```

---

## 📊 Execution Order

Steps are executed in **Order** (ascending):

```powershell
Order = 100  # User Session Inventory
Order = 200  # Drive Mapper
Order = 210  # Printer Mapper
Order = 220  # PST Mapper
Order = 300  # Power Configuration
Order = 310  # Password Notification
Order = 320  # IE Zones
Order = 330  # Retail Label
Order = 340  # ← Your new action here!
```

**Tip:** Use increments of 10 to leave room for future insertions.

---

## 🔄 Common Scenarios

### Add Action to ALL Job Types

Add the same step to all 4 workflow files:
- `Workflow-Logon.psd1`
- `Workflow-Logoff.psd1`
- `Workflow-TSLogon.psd1`
- `Workflow-TSLogoff.psd1`

### Add Action to LOGON Only

Only add to:
- `Workflow-Logon.psd1`
- `Workflow-TSLogon.psd1`

### Add Action to DESKTOP Only (not Terminal Server)

Add to:
- `Workflow-Logon.psd1`
- `Workflow-Logoff.psd1`

**Skip:**
- `Workflow-TSLogon.psd1`
- `Workflow-TSLogoff.psd1`

---

## 🛠️ Disable an Action

### Temporary Disable (Quick)

Edit workflow config:
```powershell
@{
    Name = 'Copy Office Templates'
    Enabled = $False  # ← Change this!
    # ... rest unchanged
}
```

### Permanent Remove

Delete or comment out the entire step:
```powershell
# @{
#     Name = 'Copy Office Templates'
#     ...
# }
```

---

## 🔀 Reorder Actions

Change the `Order` field:

**Before:**
```powershell
@{ Order = 300; Name = 'Power Configuration'; ... }
@{ Order = 340; Name = 'Copy Office Templates'; ... }
```

**After (swap order):**
```powershell
@{ Order = 340; Name = 'Power Configuration'; ... }  # Moved down
@{ Order = 300; Name = 'Copy Office Templates'; ... }  # Moved up
```

**Now "Copy Office Templates" runs BEFORE "Power Configuration"!**

---

## 📝 Module Template

Use this template for new modules:

```powershell
<#
.SYNOPSIS
    Desktop Management <Your Feature> Module
    
.DESCRIPTION
    <What it does>
    
.NOTES
    Version: 2.0.0
    Author: <Your Name>
#>

# Import required modules
Using Module ..\Framework\DMLogger.psm1
# Add other dependencies as needed

<#
.SYNOPSIS
    <Brief description>
    
.DESCRIPTION
    <Detailed description>
    
.PARAMETER UserInfo
    User information object
    
.PARAMETER ComputerInfo
    Computer information object
    
.OUTPUTS
    Boolean - true if successful
    
.EXAMPLE
    Invoke-DMYourAction -UserInfo $User -ComputerInfo $Computer
#>
Function Invoke-DMYourAction {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo
    )
    
    Try {
        Write-DMLog "Your Action: Starting" -Level Info
        
        # Your logic here
        
        Write-DMLog "Your Action: Completed" -Level Info
        Return $True
    }
    Catch {
        Write-DMLog "Your Action: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

# Export module members
Export-ModuleMember -Function @(
    'Invoke-DMYourAction'
)
```

---

## 🧪 Testing New Actions

### 1. Test Module Standalone

```powershell
Import-Module .\Modules\Utilities\Copy-OfficeTemplates.psm1
Import-Module .\Modules\Framework\DMLogger.psm1
Import-Module .\Modules\Framework\DMComputer.psm1
Import-Module .\Modules\Framework\DMUser.psm1

Initialize-DMLog -JobType "Test"
$User = Get-DMUserInfo
$Computer = Get-DMComputerInfo

# Test your function
$Result = Invoke-DMOfficeTemplatesCopy -UserInfo $User -ComputerInfo $Computer

Export-DMLog
```

### 2. Test in Full Workflow

```powershell
# Run full logon with verbose logging
.\DesktopManagement-Logon.ps1 -VerboseLogging
```

### 3. Check Logs

```powershell
cd "$env:USERPROFILE\Nomura\GDP\Desktop Management"
notepad (Get-ChildItem Logon_*.log | Sort-Object LastWriteTime -Descending | Select-Object -First 1)
```

**Look for:**
```
[timestamp] --- Copy Office Templates ---
[timestamp] Office Templates: Starting template copy
[timestamp] Office Templates: Copied X template file(s)
[timestamp] Office Templates: Completed
```

---

## 📊 Workflow Configuration Reference

### Available Context Variables

When defining parameters, these context variables are available:

| Variable | Type | Description |
|----------|------|-------------|
| `UserInfo` | PSCustomObject | User information from Get-DMUserInfo |
| `ComputerInfo` | PSCustomObject | Computer info from Get-DMComputerInfo |
| `JobType` | String | Current job type (Logon, Logoff, etc.) |
| `ScriptVersion` | String | Script version (2.0.0) |

### UserInfo Properties

```powershell
$UserInfo.Name
$UserInfo.Domain
$UserInfo.DistinguishedName
$UserInfo.Groups
$UserInfo.CityCode
$UserInfo.OUMapping
$UserInfo.IsTerminalSession
$UserInfo.SessionType
```

### ComputerInfo Properties

```powershell
$ComputerInfo.Name
$ComputerInfo.Domain
$ComputerInfo.DistinguishedName
$ComputerInfo.Groups
$ComputerInfo.Site
$ComputerInfo.CityCode
$ComputerInfo.OUMapping
$ComputerInfo.IPAddresses
$ComputerInfo.OSCaption
$ComputerInfo.IsVPNConnected
```

---

## 🎭 Real Example: Your Scenario

**Requirement:** Copy Office templates during logon

### Complete Implementation:

**1. Module: `Modules/Utilities/Copy-OfficeTemplates.psm1`**
```powershell
Using Module ..\Framework\DMLogger.psm1

Function Invoke-DMOfficeTemplatesCopy {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo
    )
    
    Try {
        Write-DMLog "Office Templates: Starting template copy" -Level Info
        
        # Build paths
        [String]$Domain = $ComputerInfo.Domain
        [String]$SourcePath = "\\$Domain\NETLOGON\OfficeTemplates"
        [String]$DestPath = "$env:APPDATA\Microsoft\Templates"
        
        Write-DMLog "Office Templates: Source: $SourcePath" -Level Verbose
        Write-DMLog "Office Templates: Destination: $DestPath" -Level Verbose
        
        # Validate source
        If (-not (Test-Path $SourcePath)) {
            Write-DMLog "Office Templates: Source path not accessible, skipping" -Level Warning
            Return $True  # Not an error, just not applicable
        }
        
        # Create destination if needed
        If (-not (Test-Path $DestPath)) {
            New-Item -ItemType Directory -Path $DestPath -Force | Out-Null
            Write-DMLog "Office Templates: Created destination directory" -Level Verbose
        }
        
        # Copy templates
        [Array]$CopiedFiles = Copy-Item -Path "$SourcePath\*.dotx" -Destination $DestPath -Force -PassThru
        
        Write-DMLog "Office Templates: Copied $($CopiedFiles.Count) template file(s)" -Level Info
        
        # List copied files (verbose)
        ForEach ($File in $CopiedFiles) {
            Write-DMLog "Office Templates: Copied - $($File.Name)" -Level Verbose
        }
        
        Write-DMLog "Office Templates: Completed successfully" -Level Info
        Return $True
    } Catch {
        Write-DMLog "Office Templates: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

Export-ModuleMember -Function @('Invoke-DMOfficeTemplatesCopy')
```

**2. Workflow: `Config/Workflow-Logon.psd1`**

Add after Retail Label step:

```powershell
        @{
            Order = 340
            Name = 'Copy Office Templates'
            Phase = 'Utilities'
            Module = 'Utilities\Copy-OfficeTemplates.psm1'
            Function = 'Invoke-DMOfficeTemplatesCopy'
            Enabled = $True
            Parameters = @{
                UserInfo = 'UserInfo'
                ComputerInfo = 'ComputerInfo'
            }
            ContinueOnError = $True
            Description = 'Copy MS Office templates from network share to local AppData'
        }
```

**3. Deploy:**
- Copy updated files to network share
- Users get new action on next logon

**4. Log Output:**
```
[20251013120000] ========================================
[20251013120000] PHASE: Utilities
[20251013120000] ========================================

[20251013120000] --- Copy Office Templates ---
[20251013120001] Office Templates: Starting template copy
[20251013120001] Office Templates: Source: \\ASIAPAC.NOM\NETLOGON\OfficeTemplates
[20251013120001] Office Templates: Destination: C:\Users\jsmith\AppData\Roaming\Microsoft\Templates
[20251013120002] Office Templates: Copied 25 template file(s)
[20251013120002] Office Templates: Completed successfully
```

---

## 🎯 Benefits of This Approach

### vs VBScript WSF

| Feature | VBScript WSF | PowerShell Workflow |
|---------|--------------|---------------------|
| Add action | Edit WSF, add `<script src>` | Edit .psd1, add step |
| Remove action | Edit WSF, remove line | Set `Enabled = $False` |
| Reorder actions | Edit WSF, reorder includes | Change `Order` number |
| Test action | Run entire job | Test module standalone |
| Documentation | External | In config file |
| Version control | XML diffs | Clean .psd1 diffs |

### Flexibility

✅ **Add actions** - Edit config only  
✅ **Remove actions** - Set `Enabled = $False`  
✅ **Reorder actions** - Change `Order` number  
✅ **Job-specific actions** - Different config per job  
✅ **Conditional logic** - Coming in future (RunIf conditions)  
✅ **No script changes** - Entry scripts are generic  

---

## 📚 Advanced: Custom Parameters

If your action needs custom parameters:

**Module:**
```powershell
Function Invoke-DMCustomAction {
    Param(
        [PSCustomObject]$UserInfo,
        [PSCustomObject]$ComputerInfo,
        [String]$SourcePath,        # ← Custom parameter
        [Boolean]$OverwriteFiles    # ← Custom parameter
    )
    
    Write-DMLog "Custom Action: Source = $SourcePath, Overwrite = $OverwriteFiles"
    # Your logic
}
```

**Workflow:**
```powershell
@{
    Name = 'Custom Action'
    Function = 'Invoke-DMCustomAction'
    Parameters = @{
        UserInfo = 'UserInfo'
        ComputerInfo = 'ComputerInfo'
        SourcePath = 'Static:\\server\share'     # Static string
        OverwriteFiles = 'Static:true'           # Static boolean
    }
}
```

---

## 🔍 Troubleshooting

### Action Not Running

**Check:**
1. `Enabled = $True` in workflow config?
2. Module file exists at correct path?
3. Function name matches config?
4. Function exported in module?

**Debug:**
```powershell
# Run with verbose logging
.\DesktopManagement-Logon.ps1 -VerboseLogging

# Check workflow summary in log
```

### Action Fails

**Check log file for:**
```
[timestamp] Workflow Step Error: <error message>
[timestamp] Your Action: Error - <specific error>
```

**Common issues:**
- Module path incorrect
- Function not exported
- Parameters don't match
- Module dependencies not imported

---

## 📋 Checklist for New Actions

- [ ] Module created in appropriate folder
- [ ] Function signature accepts UserInfo and ComputerInfo
- [ ] Function uses Write-DMLog for output
- [ ] Function returns Boolean ($True/$False)
- [ ] Try/Catch error handling
- [ ] Function exported with Export-ModuleMember
- [ ] Added to workflow configuration file(s)
- [ ] Order number set appropriately
- [ ] Enabled = $True
- [ ] Parameters mapped correctly
- [ ] Tested standalone
- [ ] Tested in full workflow
- [ ] Logs verified
- [ ] Documentation updated

---

## 🎊 Summary

**Adding new actions is now as easy as:**

1. **Create module** (1 file)
2. **Edit workflow config** (add 1 block)
3. **Deploy** (copy files)
4. **Done!**

**No changes needed to entry scripts!**

Just like the VBScript WSF approach, but better! ✨

---

**For questions or issues, review this guide or check the existing modules for examples.**

