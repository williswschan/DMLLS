# PowerShell Objects Reference Guide

**Desktop Management Suite v2.0**  
**Purpose:** Reference for all PSCustomObjects (equivalent to VBScript classes)  
**Audience:** Developers maintaining the PowerShell scripts

---

## 📋 Overview

In VBScript, we used **classes** (e.g., `clsComputer`, `clsUser`, `clsLogging`).  
In PowerShell, we use **PSCustomObjects** which are returned by functions.

**Key Difference:**
```vbscript
' VBScript - Classes with methods
Set objComputer = New clsComputer
objComputer.Initialize()
strName = objComputer.Name

' PowerShell - Functions return objects with properties
$Computer = Get-DMComputerInfo
$Name = $Computer.Name
```

---

## 🗺️ VBScript Class → PowerShell Module Mapping

| VBScript Class | PowerShell Module | Main Function | Returns |
|---------------|-------------------|---------------|---------|
| `clsComputer` | `DMComputer.psm1` | `Get-DMComputerInfo` | ComputerInfo object |
| `clsUser` | `DMUser.psm1` | `Get-DMUserInfo` | UserInfo object |
| `clsLogging` | `DMLogger.psm1` | `Initialize-DMLog` | (uses module state) |
| `clsMain` | `DMCommon.psm1` | Various utilities | Various |
| `clsRegistry` | `DMRegistry.psm1` | `Get/Set-DMRegistryValue` | Values |
| Service classes | `DMServiceCommon.psm1` | `Invoke-DMSOAPRequest` | Response object |
| Mapper classes | `DMMapperService.psm1` | `Get-DMDriveMappings`, etc. | Array of objects |
| Inventory classes | `Invoke-*Inventory.psm1` | Various | Boolean |

---

## 📦 Core Objects (Always Available)

### 1. ComputerInfo Object

**Created By:** `Get-DMComputerInfo` (in `DMComputer.psm1`)

**VBScript Equivalent:** `clsComputer`

**Properties:**

```powershell
[PSCustomObject]@{
    # Basic Information
    Name                = [String]     # Computer name (e.g., "HKWKS01")
    Domain              = [String]     # Domain name (e.g., "ASIAPAC")
    DistinguishedName   = [String]     # AD DN (e.g., "CN=HKWKS01,OU=Computers,DC=asiapac,DC=nom")
    
    # Location Information
    Site                = [String]     # AD Site (e.g., "HKG", "TYO", "NYC")
    CityCode            = [String]     # 3-letter city code (e.g., "HKG", "TYO")
    OUPath              = [String]     # Full OU path (e.g., "RESOURCES/HKG/WORKSTATIONS")
    OUMapping           = [String]     # Standardized OU (e.g., "RESOURCES/HKG/WORKSTATIONS")
    
    # Group Memberships
    Groups              = [Array]      # Array of AD group names (string[])
    
    # Network Information
    IPAddresses         = [Array]      # Array of IP addresses (string[])
    IsVPNConnected      = [Boolean]    # $True if VPN active, $False otherwise
    
    # Operating System
    OSCaption           = [String]     # OS name (e.g., "Microsoft Windows 10 Enterprise")
    OSVersion           = [String]     # OS version (e.g., "10.0.19045")
    OSArchitecture      = [String]     # Architecture (e.g., "64-bit")
    
    # Hardware
    Manufacturer        = [String]     # Manufacturer (e.g., "Dell Inc.", "VMware, Inc.")
    Model               = [String]     # Model (e.g., "Latitude 7490", "VMware Virtual Platform")
    IsVirtual           = [Boolean]    # $True if VM, $False if physical
    VirtualPlatform     = [String]     # "VMware", "Hyper-V", "Physical"
}
```

**Usage Example:**
```powershell
# Get computer information
$Computer = Get-DMComputerInfo

# Access properties
Write-Host "Computer: $($Computer.Name)"
Write-Host "Domain: $($Computer.Domain)"
Write-Host "Site: $($Computer.Site)"
Write-Host "City: $($Computer.CityCode)"

# Check group membership
If ($Computer.Groups -contains "GRP_LAPTOP_USERS") {
    Write-Host "This is a laptop"
}

# Check VPN status
If ($Computer.IsVPNConnected) {
    Write-Host "VPN is active"
}
```

**Where Used:**
- All 4 entry point scripts (required)
- Workflow engine (passed to all steps)
- Inventory modules
- Mapper modules

---

### 2. UserInfo Object

**Created By:** `Get-DMUserInfo` (in `DMUser.psm1`)

**VBScript Equivalent:** `clsUser`

**Properties:**

```powershell
[PSCustomObject]@{
    # Basic Information
    Name                = [String]     # Username (e.g., "jsmith")
    Domain              = [String]     # Domain name (e.g., "ASIAPAC")
    DistinguishedName   = [String]     # AD DN (e.g., "CN=John Smith,OU=Users,DC=asiapac,DC=nom")
    
    # Location Information
    CityCode            = [String]     # 3-letter city code from DN
    OUPath              = [String]     # Full OU path
    OUMapping           = [String]     # Standardized OU mapping
    
    # Contact Information
    Email               = [String]     # Email address (e.g., "john.smith@nomura.com")
    
    # Group Memberships
    Groups              = [Array]      # Array of AD group names (string[])
    
    # Session Information
    IsTerminalSession   = [Boolean]    # $True if Terminal Server/Citrix, $False for desktop
    SessionType         = [String]     # "Console", "RemoteDesktop", "Citrix"
    SessionID           = [Int]        # Session ID number
    
    # Password Information (if available)
    PasswordExpiry      = [Object]     # PSCustomObject with password expiry details
                                       # Properties: DaysUntilExpiry, ExpiryDate, IsExpiring
}
```

**Usage Example:**
```powershell
# Get user information
$User = Get-DMUserInfo

# Access properties
Write-Host "User: $($User.Name)"
Write-Host "Email: $($User.Email)"
Write-Host "City: $($User.CityCode)"

# Check group membership
If ($User.Groups -contains "GRP_RETAIL_USERS") {
    Write-Host "User is in Retail"
}

# Check session type
If ($User.IsTerminalSession) {
    Write-Host "Terminal Server session"
} Else {
    Write-Host "Desktop session"
}

# Check password expiry
If ($Null -ne $User.PasswordExpiry -and $User.PasswordExpiry.IsExpiring) {
    Write-Host "Password expires in $($User.PasswordExpiry.DaysUntilExpiry) days"
}
```

**Where Used:**
- All 4 entry point scripts (required)
- Workflow engine (passed to all steps)
- Inventory modules
- Mapper modules
- Password expiry notification

---

## 🌐 Service Objects

### 3. SOAP Response Object

**Created By:** `Invoke-DMSOAPRequest` (in `DMServiceCommon.psm1`)

**VBScript Equivalent:** SOAP response handling in service classes

**Properties:**

```powershell
[PSCustomObject]@{
    Success         = [Boolean]    # $True if request succeeded
    StatusCode      = [Int]        # HTTP status code (200, 404, 500, etc.)
    ResponseText    = [String]     # Raw XML response text
    ResponseXML     = [XML]        # Parsed XML document (or $Null if parse failed)
    ErrorMessage    = [String]     # Error description if Success = $False
}
```

**Usage Example:**
```powershell
# Send SOAP request
$Response = Invoke-DMSOAPRequest -ServiceURL $URL -SoapRequest $Request

# Check result
If ($Response.Success) {
    # Parse XML
    $ResultNode = Get-DMSOAPResult -ResponseXML $Response.ResponseXML -MethodName "GetUserDrives"
    # Process result...
} Else {
    Write-DMLog "SOAP request failed: $($Response.ErrorMessage)" -Level Error
}
```

**Where Used:**
- `DMMapperService.psm1` - All mapping functions
- `DMInventoryService.psm1` - All inventory functions
- Service health checks

---

### 4. Drive Mapping Object

**Created By:** `Get-DMDriveMappings` (in `DMMapperService.psm1`)

**VBScript Equivalent:** Drive mapping array from mapper service

**Properties:**

```powershell
[PSCustomObject]@{
    Id              = [String]     # Unique mapping ID from backend
    DriveLetter     = [String]     # Drive letter (e.g., "H:", "U:", "V:")
    UncPath         = [String]     # UNC path (e.g., "\\server\share\folder")
    Description     = [String]     # Mapping description
    IsPersistent    = [Boolean]    # $True for persistent, $False for session-only
}
```

**Usage Example:**
```powershell
# Get drive mappings from service
[Array]$DriveMappings = Get-DMDriveMappings -UserInfo $User -ComputerInfo $Computer

# Process each mapping
ForEach ($Mapping in $DriveMappings) {
    Write-Host "Map $($Mapping.DriveLetter) to $($Mapping.UncPath)"
    
    # Apply mapping
    New-PSDrive -Name $Mapping.DriveLetter.TrimEnd(':') `
                -PSProvider FileSystem `
                -Root $Mapping.UncPath `
                -Persist:$Mapping.IsPersistent
}
```

**Where Used:**
- `Invoke-DriveMapper.psm1` - Apply drive mappings
- Workflow engine (via Drive Mapper step)

---

### 5. Printer Mapping Object

**Created By:** `Get-DMPrinterMappings` (in `DMMapperService.psm1`)

**VBScript Equivalent:** Printer mapping array from mapper service

**Properties:**

```powershell
[PSCustomObject]@{
    Id              = [String]     # Unique mapping ID from backend
    PrinterPath     = [String]     # UNC printer path (e.g., "\\printserver\HP_LaserJet_1234")
    Description     = [String]     # Printer description
    IsDefault       = [Boolean]    # $True if should be set as default printer
}
```

**Usage Example:**
```powershell
# Get printer mappings
[Array]$PrinterMappings = Get-DMPrinterMappings -UserInfo $User -ComputerInfo $Computer

# Process each mapping
ForEach ($Mapping in $PrinterMappings) {
    Write-Host "Adding printer: $($Mapping.PrinterPath)"
    
    # Add printer
    Add-Printer -ConnectionName $Mapping.PrinterPath
    
    # Set as default if specified
    If ($Mapping.IsDefault) {
        $Printer = Get-CimInstance -ClassName Win32_Printer -Filter "ShareName='$($Mapping.PrinterPath)'"
        $Printer | Invoke-CimMethod -MethodName SetDefaultPrinter
    }
}
```

**Where Used:**
- `Invoke-PrinterMapper.psm1` - Apply printer mappings
- Workflow engine (via Printer Mapper step)

---

### 6. PST Mapping Object

**Created By:** `Get-DMPSTMappings` (in `DMMapperService.psm1`)

**VBScript Equivalent:** PST mapping array from mapper service

**Properties:**

```powershell
[PSCustomObject]@{
    Id              = [String]     # Unique mapping ID from backend
    PSTPath         = [String]     # Full path to PST file (e.g., "\\server\pst\user.pst")
    Description     = [String]     # PST file description
}
```

**Usage Example:**
```powershell
# Get PST mappings
[Array]$PSTMappings = Get-DMPSTMappings -UserInfo $User -ComputerInfo $Computer

# Process each PST
ForEach ($Mapping in $PSTMappings) {
    Write-Host "Adding PST: $($Mapping.PSTPath)"
    
    # Add to Outlook (via COM)
    # Implementation in Invoke-PersonalFolderMapper.psm1
}
```

**Where Used:**
- `Invoke-PersonalFolderMapper.psm1` - Apply PST mappings
- Workflow engine (via PST Mapper step)

---

## 📊 Inventory Objects

### 7. Mapped Drive Object

**Created By:** `Get-DMMappedDrives` (in `Invoke-DriveInventory.psm1`)

**VBScript Equivalent:** Current drive mapping collection

**Properties:**

```powershell
[PSCustomObject]@{
    DriveLetter     = [String]     # Drive letter (e.g., "H:", "U:")
    UncPath         = [String]     # Current UNC path
    DriveType       = [String]     # "Network", "Fixed", "Removable", etc.
    Status          = [String]     # "OK", "Disconnected", "Error"
}
```

**Usage Example:**
```powershell
# Get current drive mappings
[Array]$CurrentDrives = Get-DMMappedDrives -UserInfo $User

# Send to inventory service
$Result = Send-DMDriveInventory -UserInfo $User -ComputerInfo $Computer -Drives $CurrentDrives
```

**Where Used:**
- `Invoke-DMDriveInventory` - Collect and send drive inventory
- Workflow engine (via Drive Inventory step)

---

### 8. Network Printer Object

**Created By:** `Get-DMNetworkPrinters` (in `Invoke-PrinterInventory.psm1`)

**VBScript Equivalent:** Current printer collection

**Properties:**

```powershell
[PSCustomObject]@{
    PrinterName     = [String]     # Printer name
    PrinterPath     = [String]     # UNC path (e.g., "\\printserver\printer")
    IsDefault       = [Boolean]    # $True if default printer
    Status          = [String]     # "Ready", "Offline", "Error"
}
```

**Usage Example:**
```powershell
# Get current network printers
[Array]$CurrentPrinters = Get-DMNetworkPrinters

# Send to inventory service
$Result = Send-DMPrinterInventory -UserInfo $User -ComputerInfo $Computer -Printers $CurrentPrinters
```

**Where Used:**
- `Invoke-DMPrinterInventory` - Collect and send printer inventory
- Workflow engine (via Printer Inventory step)

---

### 9. Outlook PST Object

**Created By:** `Get-DMOutlookPSTFiles` (in `Invoke-PersonalFolderInventory.psm1`)

**VBScript Equivalent:** PST file collection from registry

**Properties:**

```powershell
[PSCustomObject]@{
    PSTPath         = [String]     # Full path to PST file
    Description     = [String]     # PST description/name
}
```

**Usage Example:**
```powershell
# Get current PST files
[Array]$CurrentPSTs = Get-DMOutlookPSTFiles

# Send to inventory service
$Result = Send-DMPersonalFolderInventory -UserInfo $User -ComputerInfo $Computer -PersonalFolders $CurrentPSTs
```

**Where Used:**
- `Invoke-DMPersonalFolderInventory` - Collect and send PST inventory
- Workflow engine (via PST Inventory step)

---

## 🔧 Utility Objects

### 10. Password Expiry Object

**Created By:** `Get-DMUserPasswordExpiry` (in `DMUser.psm1`)

**VBScript Equivalent:** Password expiry check in user class

**Properties:**

```powershell
[PSCustomObject]@{
    ExpiryDate          = [DateTime]   # When password expires
    DaysUntilExpiry     = [Int]        # Days remaining (can be negative)
    IsExpiring          = [Boolean]    # $True if expires within 14 days
    WarningThreshold    = [Int]        # Warning threshold in days (14)
}
```

**Usage Example:**
```powershell
# Get password expiry
$PasswordExpiry = Get-DMUserPasswordExpiry -DistinguishedName $User.DistinguishedName

# Check if expiring soon
If ($PasswordExpiry.IsExpiring) {
    $Message = "Your password will expire in $($PasswordExpiry.DaysUntilExpiry) days on $($PasswordExpiry.ExpiryDate.ToString('yyyy-MM-dd'))"
    [System.Windows.Forms.MessageBox]::Show($Message, "Password Expiry Warning", "OK", "Warning")
}
```

**Where Used:**
- `Show-PasswordExpiryNotification.psm1` - Display expiry warnings
- `Get-DMUserInfo` - Populate UserInfo.PasswordExpiry
- Workflow engine (via Password Notification step)

---

## 📋 Quick Reference: Object Creation Functions

### Framework Objects
```powershell
# Computer Information
$Computer = Get-DMComputerInfo
# Properties: Name, Domain, Site, CityCode, Groups, IPAddresses, IsVPNConnected, etc.

# User Information
$User = Get-DMUserInfo
# Properties: Name, Domain, Email, CityCode, Groups, IsTerminalSession, PasswordExpiry, etc.
```

### Service Response Objects
```powershell
# SOAP Response
$Response = Invoke-DMSOAPRequest -ServiceURL $URL -SoapRequest $Request
# Properties: Success, StatusCode, ResponseText, ResponseXML, ErrorMessage

# Drive Mappings (from service)
$DriveMappings = Get-DMDriveMappings -UserInfo $User -ComputerInfo $Computer
# Array of: Id, DriveLetter, UncPath, Description, IsPersistent

# Printer Mappings (from service)
$PrinterMappings = Get-DMPrinterMappings -UserInfo $User -ComputerInfo $Computer
# Array of: Id, PrinterPath, Description, IsDefault

# PST Mappings (from service)
$PSTMappings = Get-DMPSTMappings -UserInfo $User -ComputerInfo $Computer
# Array of: Id, PSTPath, Description
```

### Inventory Collection Objects
```powershell
# Current Drive Mappings
$CurrentDrives = Get-DMMappedDrives -UserInfo $User
# Array of: DriveLetter, UncPath, DriveType, Status

# Current Network Printers
$CurrentPrinters = Get-DMNetworkPrinters
# Array of: PrinterName, PrinterPath, IsDefault, Status

# Current PST Files
$CurrentPSTs = Get-DMOutlookPSTFiles
# Array of: PSTPath, Description
```

### Utility Objects
```powershell
# Password Expiry
$PasswordExpiry = Get-DMUserPasswordExpiry -DistinguishedName $User.DistinguishedName
# Properties: ExpiryDate, DaysUntilExpiry, IsExpiring, WarningThreshold
```

---

## 🎯 Common Usage Patterns

### Pattern 1: Workflow Context (All Entry Scripts)
```powershell
# Gather system information
$Computer = Get-DMComputerInfo
$User = Get-DMUserInfo

# Build workflow context
$Context = @{
    UserInfo = $User
    ComputerInfo = $Computer
    JobType = "Logon"
    ScriptVersion = "2.0.0"
}

# Execute workflow (passes objects to all steps)
Invoke-DMWorkflow -WorkflowFile $WorkflowFile -Context $Context
```

### Pattern 2: Mapper Workflow
```powershell
# In Invoke-DMDriveMapper.psm1
Function Invoke-DMDriveMapper {
    Param(
        [PSCustomObject]$UserInfo,      # Receives UserInfo object
        [PSCustomObject]$ComputerInfo   # Receives ComputerInfo object
    )
    
    # Get mappings from service
    $Mappings = Get-DMDriveMappings -UserInfo $UserInfo -ComputerInfo $ComputerInfo
    
    # Apply each mapping
    ForEach ($Mapping in $Mappings) {
        # Access properties
        $Drive = $Mapping.DriveLetter
        $Path = $Mapping.UncPath
        # Map drive...
    }
}
```

### Pattern 3: Inventory Workflow
```powershell
# In Invoke-DMDriveInventory.psm1
Function Invoke-DMDriveInventory {
    Param(
        [PSCustomObject]$UserInfo,
        [PSCustomObject]$ComputerInfo
    )
    
    # Collect current state
    $CurrentDrives = Get-DMMappedDrives -UserInfo $UserInfo
    
    # Send to backend
    $Result = Send-DMDriveInventory -UserInfo $UserInfo `
                                     -ComputerInfo $ComputerInfo `
                                     -Drives $CurrentDrives
}
```

---

## 🔍 Accessing Object Properties

### Dot Notation (Most Common)
```powershell
$ComputerName = $Computer.Name
$UserEmail = $User.Email
$DrivePath = $Mapping.UncPath
```

### String Interpolation
```powershell
Write-Host "Computer: $($Computer.Name) in $($Computer.Site)"
Write-DMLog "User $($User.Name) from $($User.CityCode)"
```

### Property Existence Check
```powershell
# Check if property exists and has value
If ($Null -ne $User.PasswordExpiry) {
    Write-Host "Password expires: $($User.PasswordExpiry.ExpiryDate)"
}

# Check array has items
If ($Computer.Groups.Count -gt 0) {
    Write-Host "Member of $($Computer.Groups.Count) groups"
}
```

### Array Membership Check
```powershell
# Check if group in array
If ($Computer.Groups -contains "GRP_LAPTOP_USERS") {
    Write-Host "This is a laptop"
}

# Check multiple groups
$RetailGroups = @("GRP_RETAIL_HKG", "GRP_RETAIL_TYO", "GRP_RETAIL_NYC")
$IsRetail = $User.Groups | Where-Object { $RetailGroups -contains $_ }
```

---

## 📝 Creating Custom Objects (For New Modules)

If you need to create your own objects for a new module:

```powershell
# Simple object
$MyObject = [PSCustomObject]@{
    Property1 = "Value1"
    Property2 = 123
    Property3 = $True
}

# Object with calculated properties
$MyObject = [PSCustomObject]@{
    Name = $User.Name
    FullPath = Join-Path $BasePath $SubPath
    IsEnabled = ($Status -eq "Active")
    Items = @("Item1", "Item2", "Item3")  # Array
}

# Return from function
Function Get-MyCustomData {
    Return [PSCustomObject]@{
        Data1 = "Value"
        Data2 = 100
    }
}

# Usage
$CustomData = Get-MyCustomData
Write-Host $CustomData.Data1
```

---

## 🎓 Tips for Maintainers

### 1. Always Check for Null
```powershell
# Good practice
If ($Null -ne $User.PasswordExpiry) {
    $Days = $User.PasswordExpiry.DaysUntilExpiry
}

# Bad practice (can cause errors)
$Days = $User.PasswordExpiry.DaysUntilExpiry  # Error if PasswordExpiry is $Null
```

### 2. Use Type Hints for Clarity
```powershell
# Declare parameter types
Function MyFunction {
    Param(
        [PSCustomObject]$UserInfo,         # Makes it clear what's expected
        [PSCustomObject]$ComputerInfo
    )
}
```

### 3. Access Array Count Safely
```powershell
# Good practice
If ($Computer.Groups.Count -gt 0) {
    ForEach ($Group in $Computer.Groups) {
        # Process
    }
}

# Also good (handles null arrays)
If ($Null -ne $Computer.Groups -and $Computer.Groups.Count -gt 0) {
    # Process
}
```

### 4. Document Custom Objects
```powershell
<#
.OUTPUTS
    PSCustomObject with properties:
    - Name: [String] Item name
    - Value: [Int] Item value
    - IsActive: [Boolean] Active status
#>
Function Get-MyData {
    # ...
}
```

---

## 📊 Summary Table

| Object Type | Created By | Key Properties | Used In |
|-------------|-----------|----------------|---------|
| **ComputerInfo** | Get-DMComputerInfo | Name, Domain, Site, Groups, IsVPNConnected | All modules |
| **UserInfo** | Get-DMUserInfo | Name, Domain, Email, Groups, IsTerminalSession | All modules |
| **SOAP Response** | Invoke-DMSOAPRequest | Success, ResponseXML, ErrorMessage | Service modules |
| **Drive Mapping** | Get-DMDriveMappings | DriveLetter, UncPath, IsPersistent | Drive Mapper |
| **Printer Mapping** | Get-DMPrinterMappings | PrinterPath, IsDefault | Printer Mapper |
| **PST Mapping** | Get-DMPSTMappings | PSTPath, Description | PST Mapper |
| **Mapped Drive** | Get-DMMappedDrives | DriveLetter, UncPath, Status | Drive Inventory |
| **Network Printer** | Get-DMNetworkPrinters | PrinterName, PrinterPath, IsDefault | Printer Inventory |
| **Outlook PST** | Get-DMOutlookPSTFiles | PSTPath, Description | PST Inventory |
| **Password Expiry** | Get-DMUserPasswordExpiry | ExpiryDate, DaysUntilExpiry, IsExpiring | Password Notification |

---

## 🔗 Related Documentation

- **HOW-TO-ADD-ACTIONS.md** - Guide for adding new workflow actions
- **WORKFLOW-ENGINE-GUIDE.md** - Workflow architecture details
- **DEPLOYMENT-GUIDE.md** - Deployment instructions
- Module source files for detailed implementation

---

**Last Updated:** 2025-10-13  
**Version:** 2.0.0  
**Maintainer:** Desktop Management Team

