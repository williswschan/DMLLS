# Test Drive Inventory Fix
# This script tests the fixed Drive Inventory functionality

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "DRIVE INVENTORY FIX TEST" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Import required modules
Try {
    Import-Module "..\Modules\Services\DMInventoryService.psm1" -Force
    Import-Module "..\Modules\Framework\DMLogger.psm1" -Force
    Import-Module "..\Modules\Framework\DMServiceCommon.psm1" -Force
    Write-Host "[SUCCESS] Modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "[ERROR] Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Initialize logging
Initialize-DMLog -LogPath ".\Test-DriveInventoryFix.log" -LogLevel Info

# Create test data
$TestUser = [PSCustomObject]@{
    Name = "TESTUSER"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=Test User,OU=Users,DC=TESTDOMAIN,DC=COM"
}

$TestComputer = [PSCustomObject]@{
    Name = "TESTPC01"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=TESTPC01,OU=Computers,DC=TESTDOMAIN,DC=COM"
    Site = "TestSite"
    CityCode = "TEST"
}

$TestDrives = @(
    [PSCustomObject]@{
        DriveLetter = "Z:"
        UncPath = "\\server\share"
        Description = "Test Drive"
    },
    [PSCustomObject]@{
        DriveLetter = "Y:"
        UncPath = "\\server2\share2"
        Description = "Test Drive 2"
    }
)

Write-Host ""
Write-Host "[TEST] Testing Drive Inventory with fixed namespace..." -ForegroundColor Yellow

Try {
    $Result = Send-DMDriveInventory -DriveInfo $TestDrives -UserInfo $TestUser -ComputerInfo $TestComputer
    Write-Host "[RESULT] Drive Inventory Result: $Result" -ForegroundColor $(If($Result) {"Green"} Else {"Red"})
}
Catch {
    Write-Host "[ERROR] Drive Inventory failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Test completed. Check the log file for detailed information." -ForegroundColor Cyan
Write-Host "Log file: .\Test-DriveInventoryFix.log" -ForegroundColor Cyan
