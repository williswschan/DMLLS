# Test Corrected Inventory Service
# This script tests the Inventory service with the correct VBScript-matching format

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "INVENTORY SERVICE CORRECTED TEST" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Import required modules
Try {
    Import-Module "..\Modules\Services\DMInventoryService.psm1" -Force
    Import-Module "..\Modules\Framework\DMLogger.psm1" -Force
    Import-Module "..\Modules\Framework\DMServiceCommon.psm1" -Force
    Write-Host "[SUCCESS] Modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "[ERROR] Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Initialize logging
Initialize-DMLog -LogPath ".\Test-InventoryCorrected.log" -LogLevel Info

# Create test data
$TestUser = [PSCustomObject]@{
    Name = "TESTUSER"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=Test User,OU=Users,DC=TESTDOMAIN,DC=COM"
}

$TestComputer = [PSCustomObject]@{
    Name = "TESTPC01"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=TESTPC01,OU=Computers,DC=TESTDOMAIN,DC=COM"
    Site = "TestSite"
    CityCode = "TEST"
}

$TestDrives = @(
    [PSCustomObject]@{
        DriveLetter = "Z:"
        UncPath = "\\server\share"
        Description = "Test Drive"
    }
)

Write-Host ""
Write-Host "[TEST 1] Testing Logon Inventory (VBScript format)..." -ForegroundColor Yellow
Try {
    $Result1 = Send-DMLogonInventory -UserInfo $TestUser -ComputerInfo $TestComputer
    Write-Host "[RESULT] Logon Inventory: $Result1" -ForegroundColor $(If($Result1) {"Green"} Else {"Red"})
}
Catch {
    Write-Host "[ERROR] Logon Inventory failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "[TEST 2] Testing Logoff Inventory (VBScript format)..." -ForegroundColor Yellow
Try {
    $Result2 = Send-DMLogoffInventory -UserInfo $TestUser -ComputerInfo $TestComputer
    Write-Host "[RESULT] Logoff Inventory: $Result2" -ForegroundColor $(If($Result2) {"Green"} Else {"Red"})
}
Catch {
    Write-Host "[ERROR] Logoff Inventory failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "[TEST 3] Testing Drive Inventory (VBScript format)..." -ForegroundColor Yellow
Try {
    $Result3 = Send-DMDriveInventory -DriveInfo $TestDrives -UserInfo $TestUser -ComputerInfo $TestComputer
    Write-Host "[RESULT] Drive Inventory: $Result3" -ForegroundColor $(If($Result3) {"Green"} Else {"Red"})
}
Catch {
    Write-Host "[ERROR] Drive Inventory failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Test completed. Check the log file for detailed information." -ForegroundColor Cyan
Write-Host "Log file: .\Test-InventoryCorrected.log" -ForegroundColor Cyan
