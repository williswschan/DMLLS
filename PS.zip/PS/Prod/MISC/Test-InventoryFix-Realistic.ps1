# Test-InventoryFix-Realistic.ps1
# Tests the Inventory service with realistic data like the main script uses

Write-Host "========================================" -ForegroundColor Green
Write-Host "TESTING INVENTORY SERVICE (REALISTIC DATA)" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Import required modules
Try {
    Import-Module ..\Modules\Services\DMInventoryService.psm1 -Force
    Import-Module ..\Modules\Services\DMServiceCommon.psm1 -Force
    Import-Module ..\Modules\Framework\DMLogger.psm1 -Force
    Write-Host "[SUCCESS] Modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "[ERROR] Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Create realistic test data (matching what the main script would create)
$TestUser = [PSCustomObject]@{
    Name = $env:USERNAME
    DistinguishedName = "CN=$($env:USERNAME),OU=Users,DC=test,DC=com"
    Domain = $env:USERDNSDOMAIN
    ShortDomain = $env:USERDOMAIN
    OUMapping = "test.com/Users/Individual"
    Groups = @()
}

$TestComputer = [PSCustomObject]@{
    Name = $env:COMPUTERNAME
    DistinguishedName = "CN=$($env:COMPUTERNAME),OU=Computers,DC=test,DC=com"
    Site = "Default-First-Site-Name"
    CityCode = "NYC"
    Domain = $env:USERDNSDOMAIN
    Groups = @()
}

Write-Host "[INFO] Testing User: $($TestUser.Name)" -ForegroundColor Yellow
Write-Host "[INFO] Testing Computer: $($TestComputer.Name)" -ForegroundColor Yellow
Write-Host "[INFO] User Domain: $($TestUser.Domain)" -ForegroundColor Yellow
Write-Host "[INFO] Computer Domain: $($TestComputer.Domain)" -ForegroundColor Yellow
Write-Host ""

# Test 1: Logon Inventory
Write-Host "[TEST 1] Testing InsertLogonInventory with realistic data..." -ForegroundColor Cyan
Try {
    $Result = Send-DMLogonInventory -UserInfo $TestUser -ComputerInfo $TestComputer
    If ($Result) {
        Write-Host "[SUCCESS] InsertLogonInventory completed" -ForegroundColor Green
    } Else {
        Write-Host "[WARNING] InsertLogonInventory returned False" -ForegroundColor Yellow
    }
}
Catch {
    Write-Host "[ERROR] InsertLogonInventory failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 2: Logoff Inventory
Write-Host "[TEST 2] Testing InsertLogoffInventory with realistic data..." -ForegroundColor Cyan
Try {
    $Result = Send-DMLogoffInventory -UserInfo $TestUser -ComputerInfo $TestComputer
    If ($Result) {
        Write-Host "[SUCCESS] InsertLogoffInventory completed" -ForegroundColor Green
    } Else {
        Write-Host "[WARNING] InsertLogoffInventory returned False" -ForegroundColor Yellow
    }
}
Catch {
    Write-Host "[ERROR] InsertLogoffInventory failed: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Green
Write-Host "REALISTIC INVENTORY TEST COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "This test uses realistic data similar to what the main script would use." -ForegroundColor Yellow
Write-Host "If this works but the simple test fails, the issue is with test data quality." -ForegroundColor Yellow
