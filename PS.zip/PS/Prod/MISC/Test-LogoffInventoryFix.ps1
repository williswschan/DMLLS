# Test Logoff Inventory Fix
# This script tests that Logoff Inventory now uses InsertLogonInventory method

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "LOGOFF INVENTORY FIX TEST" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Import required modules
Try {
    Import-Module "..\Modules\Services\DMInventoryService.psm1" -Force
    Import-Module "..\Modules\Framework\DMLogger.psm1" -Force
    Import-Module "..\Modules\Framework\DMServiceCommon.psm1" -Force
    Write-Host "[SUCCESS] Modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "[ERROR] Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Initialize logging
Initialize-DMLog -LogPath ".\Test-LogoffInventoryFix.log" -LogLevel Info

# Create test data
$TestUser = [PSCustomObject]@{
    Name = "TESTUSER"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=Test User,OU=Users,DC=TESTDOMAIN,DC=COM"
    OUMapping = "TESTDOMAIN.COM/Users/Test"
}

$TestComputer = [PSCustomObject]@{
    Name = "TESTPC01"
    Domain = "TESTDOMAIN.COM"
    DistinguishedName = "CN=TESTPC01,OU=Computers,DC=TESTDOMAIN,DC=COM"
    Site = "TestSite"
    CityCode = "TEST"
}

Write-Host ""
Write-Host "[TEST] Testing Logoff Inventory (now using InsertLogonInventory method)..." -ForegroundColor Yellow
Write-Host "[INFO] This should now work because VBScript Logoff also calls InsertLogonInventory" -ForegroundColor Cyan

Try {
    $Result = Send-DMLogoffInventory -UserInfo $TestUser -ComputerInfo $TestComputer
    Write-Host "[RESULT] Logoff Inventory: $Result" -ForegroundColor $(If($Result) {"Green"} Else {"Red"})
    
    If ($Result) {
        Write-Host "[SUCCESS] Logoff Inventory is now working!" -ForegroundColor Green
    } Else {
        Write-Host "[WARNING] Logoff Inventory still failing - check server logs" -ForegroundColor Yellow
    }
}
Catch {
    Write-Host "[ERROR] Logoff Inventory failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Test completed. Check the log file for detailed information." -ForegroundColor Cyan
Write-Host "Log file: .\Test-LogoffInventoryFix.log" -ForegroundColor Cyan
