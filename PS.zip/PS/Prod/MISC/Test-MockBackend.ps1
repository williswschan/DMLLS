<#
.SYNOPSIS
    Mock Backend Server Testing Script
    
.DESCRIPTION
    Tests if the mock backend server is running and responding correctly.
    Verifies DNS resolution and service endpoints.
    
.EXAMPLE
    .\Test-MockBackend.ps1
#>

[CmdletBinding()]
Param()

Function Write-TestResult {
    Param(
        [String]$Section,
        [String]$Message,
        [String]$Value = "",
        [String]$Color = "White"
    )
    
    If ($Value) {
        Write-Host "[$Section] $Message : " -NoNewline -ForegroundColor Cyan
        Write-Host $Value -ForegroundColor $Color
    } Else {
        Write-Host "[$Section] $Message" -ForegroundColor $Color
    }
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "MOCK BACKEND SERVER TEST" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

# Test 1: DNS Resolution
Write-TestResult "TEST 1" "DNS Resolution for gdpmappercb.nomura.com" -Color Yellow

Try {
    [Object]$DNSResult = Resolve-DnsName -Name "gdpmappercb.nomura.com" -ErrorAction Stop
    
    ForEach ($Record in $DNSResult) {
        If ($Record.Type -eq "A") {
            Write-TestResult "SUCCESS" "Resolved to IP" $Record.IPAddress -Color Green
            
            If ($Record.IPAddress -eq "127.0.0.1" -or $Record.IPAddress -match "^192\.168\." -or $Record.IPAddress -match "^10\.") {
                Write-TestResult "INFO" "This appears to be a local/mock server" -Color Yellow
            } Else {
                Write-TestResult "INFO" "This appears to be a production server" -Color Cyan
            }
        }
    }
} Catch {
    Write-TestResult "ERROR" "DNS resolution failed" $_.Exception.Message -Color Red
    Exit 1
}

# Test 2: HTTP Connectivity
Write-Host "`n" -NoNewline
Write-TestResult "TEST 2" "HTTP Connectivity Test" -Color Yellow

[String]$BaseURL = "http://gdpmappercb.nomura.com"
Write-TestResult "INFO" "Testing URL" $BaseURL

Try {
    [Object]$Response = Invoke-WebRequest -Uri $BaseURL -Method Get -UseBasicParsing -TimeoutSec 5
    
    Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
    Write-TestResult "SUCCESS" "Content Type" $Response.Headers["Content-Type"] -Color Green
    Write-TestResult "SUCCESS" "Content Length" "$($Response.Content.Length) bytes" -Color Green
    
    # Check if response indicates it's mock or real
    If ($Response.Content -match "Flask" -or $Response.Content -match "Mock" -or $Response.Content -match "Test") {
        Write-TestResult "INFO" "Backend Type" "MOCK SERVER DETECTED" -Color Yellow
    } ElseIf ($Response.Content -match "IIS" -or $Response.Content -match "ASP.NET") {
        Write-TestResult "INFO" "Backend Type" "IIS SERVER DETECTED" -Color Cyan
    }
    
    Write-Host "`n--- Response Preview (First 200 chars) ---" -ForegroundColor Cyan
    [String]$Preview = $Response.Content.Substring(0, [Math]::Min(200, $Response.Content.Length))
    Write-Host $Preview -ForegroundColor Gray
    
} Catch {
    Write-TestResult "ERROR" "HTTP request failed" $_.Exception.Message -Color Red
    Exit 1
}

# Test 3: Test Mapper Service Endpoint
Write-Host "`n" -NoNewline
Write-TestResult "TEST 3" "Testing Mapper Service Endpoint" -Color Yellow

[String]$MapperURL = "http://gdpmappercb.nomura.com/ClassicMapper.asmx"
Write-TestResult "INFO" "Service URL" $MapperURL

Try {
    [Object]$Response = Invoke-WebRequest -Uri $MapperURL -Method Get -UseBasicParsing -TimeoutSec 5
    
    Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
    
    # Check for WSDL or service description
    If ($Response.Content -match "wsdl" -or $Response.Content -match "WSDL") {
        Write-TestResult "SUCCESS" "Service Type" "WSDL Web Service" -Color Green
    }
    
    # Check for available methods
    If ($Response.Content -match "GetDriveMappings") {
        Write-TestResult "SUCCESS" "GetDriveMappings method" "Available" -Color Green
    } Else {
        Write-TestResult "WARNING" "GetDriveMappings method" "Not found in WSDL" -Color Yellow
    }
    
    If ($Response.Content -match "GetPrinterMappings") {
        Write-TestResult "SUCCESS" "GetPrinterMappings method" "Available" -Color Green
    } Else {
        Write-TestResult "WARNING" "GetPrinterMappings method" "Not found in WSDL" -Color Yellow
    }
    
    If ($Response.Content -match "GetPSTMappings") {
        Write-TestResult "SUCCESS" "GetPSTMappings method" "Available" -Color Green
    } Else {
        Write-TestResult "WARNING" "GetPSTMappings method" "Not found in WSDL" -Color Yellow
    }
    
} Catch {
    Write-TestResult "ERROR" "Service endpoint not accessible" $_.Exception.Message -Color Red
}

# Test 4: Test Inventory Service Endpoint
Write-Host "`n" -NoNewline
Write-TestResult "TEST 4" "Testing Inventory Service Endpoint" -Color Yellow

[String]$InventoryURL = "http://gdpmappercb.nomura.com/ClassicInventory.asmx"
Write-TestResult "INFO" "Service URL" $InventoryURL

Try {
    [Object]$Response = Invoke-WebRequest -Uri $InventoryURL -Method Get -UseBasicParsing -TimeoutSec 5
    
    Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
    
    # Check for available methods
    If ($Response.Content -match "InsertLogonInventory") {
        Write-TestResult "SUCCESS" "InsertLogonInventory method" "Available" -Color Green
    } Else {
        Write-TestResult "WARNING" "InsertLogonInventory method" "Not found in WSDL" -Color Yellow
    }
    
    If ($Response.Content -match "InsertLogoffInventory") {
        Write-TestResult "SUCCESS" "InsertLogoffInventory method" "Available" -Color Green
    } Else {
        Write-TestResult "WARNING" "InsertLogoffInventory method" "Not found in WSDL" -Color Yellow
    }
    
} Catch {
    Write-TestResult "ERROR" "Service endpoint not accessible" $_.Exception.Message -Color Red
}

# Test 5: Simple SOAP Request Test
Write-Host "`n" -NoNewline
Write-TestResult "TEST 5" "Sending Simple SOAP Request" -Color Yellow

[String]$SimpleSOAP = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>CN=TestUser,OU=Users,DC=TEST,DC=COM</tem:userDN>
            <tem:computerDN>CN=TestComputer,OU=Computers,DC=TEST,DC=COM</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@

[Hashtable]$SimpleHeaders = @{
    "Content-Type" = "text/xml; charset=utf-8"
    "SOAPAction" = "http://tempuri.org/GetDriveMappings"
}

Try {
    [Object]$Response = Invoke-WebRequest -Uri $MapperURL -Method Post -Body $SimpleSOAP -Headers $SimpleHeaders -TimeoutSec 5 -UseBasicParsing
    
    Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
    Write-TestResult "SUCCESS" "Response received" "$($Response.Content.Length) bytes" -Color Green
    
    Write-Host "`n--- Response (First 500 chars) ---" -ForegroundColor Green
    [String]$Preview = $Response.Content.Substring(0, [Math]::Min(500, $Response.Content.Length))
    Write-Host $Preview -ForegroundColor Gray
    
} Catch {
    [String]$StatusCode = "Unknown"
    [String]$StatusDesc = "Unknown"
    
    If ($Null -ne $_.Exception.Response) {
        $StatusCode = $_.Exception.Response.StatusCode.value__
        $StatusDesc = $_.Exception.Response.StatusDescription
    }
    
    Write-TestResult "FAILED" "HTTP Status" "$StatusCode - $StatusDesc" -Color Red
    
    # Common error explanations
    Switch ($StatusCode) {
        400 { Write-TestResult "HINT" "Bad Request" "Server cannot understand the request format" -Color Yellow }
        401 { Write-TestResult "HINT" "Unauthorized" "Authentication required or invalid credentials" -Color Yellow }
        404 { Write-TestResult "HINT" "Not Found" "Service endpoint does not exist" -Color Yellow }
        500 { Write-TestResult "HINT" "Internal Server Error" "Server-side error processing request" -Color Yellow }
    }
}

# Summary
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "RECOMMENDATION" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

Write-Host "Based on the test results above, you should:" -ForegroundColor Yellow
Write-Host "1. Identify which authentication method succeeded (HTTP 200)" -ForegroundColor White
Write-Host "2. Review the response XML structure" -ForegroundColor White
Write-Host "3. Update the PowerShell modules to match the working format" -ForegroundColor White
Write-Host "4. If all tests failed, check if mock backend is running" -ForegroundColor White
Write-Host "`n"

Write-Host "To check mock backend status:" -ForegroundColor Cyan
Write-Host "  netstat -an | findstr :80" -ForegroundColor Gray
Write-Host "`n"

