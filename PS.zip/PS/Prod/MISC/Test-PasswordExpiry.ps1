<#
.SYNOPSIS
    Detailed Password Expiry Diagnostic Script
    
.DESCRIPTION
    Tests password expiry detection with extensive logging to diagnose issues.
    Shows all intermediate values and code paths taken.
    
.PARAMETER Username
    Username to test (defaults to current user)
    
.PARAMETER Domain
    Domain name (defaults to current domain)
    
.EXAMPLE
    .\Test-PasswordExpiry.ps1
    .\Test-PasswordExpiry.ps1 -Username "WILLIS.CHAN" -Domain "MYMSNGROUP.COM"
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$False)]
    [String]$Username = $env:USERNAME,
    
    [Parameter(Mandatory=$False)]
    [String]$Domain = $env:USERDNSDOMAIN
)

Function Write-TestResult {
    Param(
        [String]$Section,
        [String]$Message,
        [String]$Value = "",
        [String]$Color = "White"
    )
    
    If ($Value) {
        Write-Host "[$Section] $Message : " -NoNewline -ForegroundColor Cyan
        Write-Host $Value -ForegroundColor $Color
    } Else {
        Write-Host "[$Section] $Message" -ForegroundColor $Color
    }
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "PASSWORD EXPIRY DIAGNOSTIC TEST" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

# Step 1: Get User DN
Write-TestResult "STEP 1" "Getting User Distinguished Name" -Color Yellow
Write-TestResult "INFO" "Username" $Username
Write-TestResult "INFO" "Domain" $Domain

Try {
    Add-Type -AssemblyName System.DirectoryServices
    
    [Object]$Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.Filter = "(&(objectClass=user)(samAccountName=$Username))"
    [Void]$Searcher.PropertiesToLoad.Add("distinguishedName")
    
    [Object]$UserResult = $Searcher.FindOne()
    
    If ($UserResult) {
        [String]$UserDN = $UserResult.Properties["distinguishedName"][0]
        Write-TestResult "SUCCESS" "User DN Retrieved" $UserDN -Color Green
    } Else {
        Write-TestResult "ERROR" "User not found in Active Directory" -Color Red
        Exit 1
    }
} Catch {
    Write-TestResult "ERROR" "Failed to get user DN" $_.Exception.Message -Color Red
    Exit 1
}

# Step 2: Bind to User Object via ADSI
Write-Host "`n" -NoNewline
Write-TestResult "STEP 2" "Binding to User Object via ADSI" -Color Yellow

[String]$LDAPPath = "LDAP://$Domain/$UserDN"
Write-TestResult "INFO" "LDAP Path" $LDAPPath

Try {
    [Object]$User = [ADSI]$LDAPPath
    
    If ($Null -eq $User -or $Null -eq $User.Path -or [String]::IsNullOrEmpty($User.Path)) {
        Write-TestResult "ERROR" "Failed to bind to user object" -Color Red
        Write-TestResult "INFO" "User.Path" $User.Path
        Exit 1
    }
    
    Write-TestResult "SUCCESS" "Bound to user object" $User.Path -Color Green
} Catch {
    Write-TestResult "ERROR" "ADSI binding failed" $_.Exception.Message -Color Red
    Exit 1
}

# Step 3: Check userAccountControl
Write-Host "`n" -NoNewline
Write-TestResult "STEP 3" "Checking userAccountControl Property" -Color Yellow

Try {
    If ($Null -eq $User.userAccountControl -or $User.userAccountControl.Count -eq 0) {
        Write-TestResult "ERROR" "userAccountControl property is not available" -Color Red
        Exit 1
    }
    
    [Int]$UserFlags = $User.userAccountControl[0]
    Write-TestResult "SUCCESS" "userAccountControl" $UserFlags -Color Green
    
    [Boolean]$PasswordNeverExpires = ($UserFlags -band 0x10000) -ne 0
    Write-TestResult "INFO" "Password Never Expires Flag (0x10000)" $PasswordNeverExpires -Color $(If ($PasswordNeverExpires) { "Yellow" } Else { "Green" })
    
    If ($PasswordNeverExpires) {
        Write-TestResult "RESULT" "User account has 'Password never expires' checkbox ENABLED in AD" -Color Yellow
        Write-Host "`nDIAGNOSIS: The user account is configured to never expire passwords." -ForegroundColor Yellow
        Write-Host "This is an AD configuration setting, not a script issue.`n" -ForegroundColor Yellow
        Exit 0
    }
} Catch {
    Write-TestResult "ERROR" "Failed to check userAccountControl" $_.Exception.Message -Color Red
    Exit 1
}

# Step 4: Get pwdLastSet
Write-Host "`n" -NoNewline
Write-TestResult "STEP 4" "Getting Password Last Set Date" -Color Yellow

Try {
    If ($Null -eq $User.pwdLastSet -or $User.pwdLastSet.Count -eq 0) {
        Write-TestResult "ERROR" "pwdLastSet property is not available" -Color Red
        Exit 1
    }
    
    [Object]$PwdLastSet = $User.ConvertLargeIntegerToInt64($User.pwdLastSet[0])
    Write-TestResult "SUCCESS" "pwdLastSet (FileTime)" $PwdLastSet -Color Green
    
    [DateTime]$PasswordLastChanged = [DateTime]::FromFileTime($PwdLastSet)
    Write-TestResult "SUCCESS" "Password Last Changed" $PasswordLastChanged.ToString("yyyy-MM-dd HH:mm:ss") -Color Green
} Catch {
    Write-TestResult "ERROR" "Failed to get pwdLastSet" $_.Exception.Message -Color Red
    Exit 1
}

# Step 5: Get Domain Password Policy
Write-Host "`n" -NoNewline
Write-TestResult "STEP 5" "Getting Domain Password Policy" -Color Yellow

[String]$DomainPath = "LDAP://$Domain"
Write-TestResult "INFO" "Domain Path" $DomainPath

Try {
    [Object]$DomainObj = [ADSI]$DomainPath
    
    If ($Null -eq $DomainObj.maxPwdAge -or $DomainObj.maxPwdAge.Count -eq 0) {
        Write-TestResult "ERROR" "maxPwdAge property is not available" -Color Red
        Exit 1
    }
    
    [Object]$MaxPwdAge = $DomainObj.ConvertLargeIntegerToInt64($DomainObj.maxPwdAge[0])
    Write-TestResult "SUCCESS" "maxPwdAge (Raw Value)" $MaxPwdAge -Color Green
    
    # Check for special values
    If ($MaxPwdAge -eq [Int64]::MinValue) {
        Write-TestResult "RESULT" "maxPwdAge is Int64.MinValue" "Domain passwords never expire" -Color Yellow
        Write-Host "`nDIAGNOSIS: Domain password policy is set to 'Passwords never expire'." -ForegroundColor Yellow
        Write-Host "This is a domain-level configuration, not a script issue.`n" -ForegroundColor Yellow
        Exit 0
    }
    
    If ($MaxPwdAge -eq 0) {
        Write-TestResult "RESULT" "maxPwdAge is 0" "Domain passwords never expire" -Color Yellow
        Write-Host "`nDIAGNOSIS: Domain password policy is set to 'Passwords never expire'." -ForegroundColor Yellow
        Write-Host "This is a domain-level configuration, not a script issue.`n" -ForegroundColor Yellow
        Exit 0
    }
    
    Write-TestResult "INFO" "maxPwdAge Sign" $(If ($MaxPwdAge -lt 0) { "Negative (normal)" } Else { "Positive (unusual)" }) -Color Green
    
} Catch {
    Write-TestResult "ERROR" "Failed to get domain password policy" $_.Exception.Message -Color Red
    Exit 1
}

# Step 6: Calculate Password Age TimeSpan
Write-Host "`n" -NoNewline
Write-TestResult "STEP 6" "Calculating Password Age TimeSpan" -Color Yellow

Try {
    If ($MaxPwdAge -lt 0) {
        [TimeSpan]$MaxAge = [TimeSpan]::FromTicks(-$MaxPwdAge)
        Write-TestResult "SUCCESS" "Used negative conversion (-MaxPwdAge)" -Color Green
    } Else {
        [TimeSpan]$MaxAge = [TimeSpan]::FromTicks($MaxPwdAge)
        Write-TestResult "SUCCESS" "Used positive value (MaxPwdAge)" -Color Green
    }
    
    Write-TestResult "SUCCESS" "Max Password Age (Days)" $MaxAge.TotalDays -Color Green
    Write-TestResult "SUCCESS" "Max Password Age (TimeSpan)" $MaxAge.ToString() -Color Green
} Catch {
    Write-TestResult "ERROR" "Failed to convert maxPwdAge to TimeSpan" $_.Exception.Message -Color Red
    Exit 1
}

# Step 7: Calculate Expiry Date
Write-Host "`n" -NoNewline
Write-TestResult "STEP 7" "Calculating Password Expiry Date" -Color Yellow

Try {
    [DateTime]$ExpiryDate = $PasswordLastChanged.Add($MaxAge)
    Write-TestResult "SUCCESS" "Password Expiry Date" $ExpiryDate.ToString("yyyy-MM-dd HH:mm:ss") -Color Green
} Catch {
    Write-TestResult "ERROR" "DateTime overflow when adding MaxAge" $_.Exception.Message -Color Red
    Write-TestResult "INFO" "PasswordLastChanged" $PasswordLastChanged.ToString("yyyy-MM-dd HH:mm:ss")
    Write-TestResult "INFO" "MaxAge.Ticks" $MaxAge.Ticks
    Write-Host "`nDIAGNOSIS: DateTime.MaxValue overflow - password age is too large." -ForegroundColor Yellow
    Write-Host "This would cause the script to treat password as never-expiring.`n" -ForegroundColor Yellow
    Exit 1
}

# Step 8: Calculate Days Until Expiry
Write-Host "`n" -NoNewline
Write-TestResult "STEP 8" "Calculating Days Until Expiry" -Color Yellow

Try {
    [DateTime]$Now = Get-Date
    [TimeSpan]$TimeUntilExpiry = $ExpiryDate - $Now
    [Int]$DaysLeft = [Int]$TimeUntilExpiry.TotalDays
    
    Write-TestResult "SUCCESS" "Current Date/Time" $Now.ToString("yyyy-MM-dd HH:mm:ss") -Color Green
    Write-TestResult "SUCCESS" "Days Until Expiry" $DaysLeft -Color $(If ($DaysLeft -lt 0) { "Red" } ElseIf ($DaysLeft -lt 14) { "Yellow" } Else { "Green" })
    
    If ($DaysLeft -lt 0) {
        Write-TestResult "RESULT" "PASSWORD HAS EXPIRED!" "Expired $([Math]::Abs($DaysLeft)) days ago" -Color Red
    } ElseIf ($DaysLeft -eq 0) {
        Write-TestResult "RESULT" "PASSWORD EXPIRES TODAY!" -Color Red
    } ElseIf ($DaysLeft -lt 14) {
        Write-TestResult "RESULT" "PASSWORD EXPIRING SOON!" "Notification SHOULD be shown" -Color Yellow
    } Else {
        Write-TestResult "RESULT" "Password is valid" "No notification needed" -Color Green
    }
} Catch {
    Write-TestResult "ERROR" "Failed to calculate days until expiry" $_.Exception.Message -Color Red
    Exit 1
}

# Summary
Write-Host "`n========================================" -ForegroundColor Green
Write-Host "TEST SUMMARY" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-TestResult "FINAL" "User DN" $UserDN
Write-TestResult "FINAL" "Password Last Changed" $PasswordLastChanged.ToString("yyyy-MM-dd HH:mm:ss")
Write-TestResult "FINAL" "Password Max Age (Days)" $MaxAge.TotalDays
Write-TestResult "FINAL" "Password Expiry Date" $ExpiryDate.ToString("yyyy-MM-dd HH:mm:ss")
Write-TestResult "FINAL" "Days Until Expiry" $DaysLeft -Color $(If ($DaysLeft -lt 0) { "Red" } ElseIf ($DaysLeft -lt 14) { "Yellow" } Else { "Green" })
Write-TestResult "FINAL" "Notification Needed?" $(If ($DaysLeft -ge 0 -and $DaysLeft -lt 14) { "YES" } Else { "NO" })
Write-Host ""

