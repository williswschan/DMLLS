# Desktop Management Suite - Phase 1 Module Testing Script
# Tests all Phase 1 framework modules without backend dependency

Param(
    [Switch]$Verbose
)

$ErrorActionPreference = 'Continue'

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Phase 1 Module Testing" -ForegroundColor Cyan
Write-Host "Desktop Management Suite v2.0" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

[Int]$TestsPassed = 0
[Int]$TestsFailed = 0
[String]$TestOutputPath = Join-Path $PSScriptRoot "Test-Results"

# Create output directory
If (-not (Test-Path $TestOutputPath)) {
    New-Item -ItemType Directory -Path $TestOutputPath -Force | Out-Null
}

Function Write-TestHeader {
    Param([String]$ModuleName)
    Write-Host ""
    Write-Host "=== Testing: $ModuleName ===" -ForegroundColor Yellow
}

Function Write-TestResult {
    Param(
        [String]$TestName,
        [Boolean]$Result,
        [String]$Details = ""
    )
    
    If ($Result) {
        Write-Host "  [PASS] $TestName" -ForegroundColor Green
        If ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
        $Script:TestsPassed++
    } Else {
        Write-Host "  [FAIL] $TestName" -ForegroundColor Red
        If ($Details) { Write-Host "         $Details" -ForegroundColor Red }
        $Script:TestsFailed++
    }
}

# ============================================================================
# Test 1: Configuration Files
# ============================================================================
Write-TestHeader "Configuration Files"

Try {
    $SettingsConfig = Import-PowerShellDataFile -Path ".\Config\Settings.psd1"
    Write-TestResult -TestName "Settings.psd1 loaded" -Result $True -Details "Version: $($SettingsConfig.Version)"
} Catch {
    Write-TestResult -TestName "Settings.psd1 loaded" -Result $False -Details $_.Exception.Message
}

Try {
    $RegionalConfig = Import-PowerShellDataFile -Path ".\Config\RegionalConfig.psd1"
    Write-TestResult -TestName "RegionalConfig.psd1 loaded" -Result $True -Details "$($RegionalConfig.LDAPServers.Count) regions configured"
} Catch {
    Write-TestResult -TestName "RegionalConfig.psd1 loaded" -Result $False -Details $_.Exception.Message
}

# Test workflow configurations
[Array]$WorkflowFiles = @('Logon', 'Logoff', 'TSLogon', 'TSLogoff')
ForEach ($WorkflowType in $WorkflowFiles) {
    Try {
        $WorkflowConfig = Import-PowerShellDataFile -Path ".\Config\Workflow-$WorkflowType.psd1"
        Write-TestResult -TestName "Workflow-$WorkflowType.psd1 loaded" -Result $True
    } Catch {
        Write-TestResult -TestName "Workflow-$WorkflowType.psd1 loaded" -Result $False -Details $_.Exception.Message
    }
}

# ============================================================================
# Test 2: DMLogger.psm1
# ============================================================================
Write-TestHeader "DMLogger.psm1"

Try {
    Import-Module .\Modules\Framework\DMLogger.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $InitResult = Initialize-DMLog -JobType "Phase1Test" -VerboseLogging:$Verbose
    Write-TestResult -TestName "Initialize-DMLog" -Result $InitResult
} Catch {
    Write-TestResult -TestName "Initialize-DMLog" -Result $False -Details $_.Exception.Message
}

Try {
    Write-DMLog "Test message - Info level"
    Write-DMLog "Test warning message" -Level Warning
    Write-DMLog "Test verbose message" -Level Verbose
    Write-TestResult -TestName "Write-DMLog (multiple levels)" -Result $True
} Catch {
    Write-TestResult -TestName "Write-DMLog (multiple levels)" -Result $False -Details $_.Exception.Message
}

Try {
    Set-DMLogError -ErrorLevel 1 -ErrorDescription "Test warning"
    $ErrorInfo = Get-DMLogError
    [Boolean]$Success = ($ErrorInfo.ErrorLevel -eq 1)
    Write-TestResult -TestName "Set/Get-DMLogError" -Result $Success -Details "ErrorLevel: $($ErrorInfo.ErrorLevel)"
} Catch {
    Write-TestResult -TestName "Set/Get-DMLogError" -Result $False -Details $_.Exception.Message
}

Try {
    $LogPath = Get-DMLogPath
    [Boolean]$Success = (-not [String]::IsNullOrEmpty($LogPath))
    Write-TestResult -TestName "Get-DMLogPath" -Result $Success -Details $LogPath
} Catch {
    Write-TestResult -TestName "Get-DMLogPath" -Result $False -Details $_.Exception.Message
}

Try {
    $ExportResult = Export-DMLog
    Write-TestResult -TestName "Export-DMLog" -Result $ExportResult
} Catch {
    Write-TestResult -TestName "Export-DMLog" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 3: DMCommon.psm1
# ============================================================================
Write-TestHeader "DMCommon.psm1"

Try {
    Import-Module .\Modules\Framework\DMCommon.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $Result = ConvertTo-DMXMLSafeText "Test & <value> 'quoted'"
    [Boolean]$Success = ($Result -like "*&amp;*" -and $Result -like "*&lt;*")
    Write-TestResult -TestName "ConvertTo-DMXMLSafeText" -Result $Success -Details $Result
} Catch {
    Write-TestResult -TestName "ConvertTo-DMXMLSafeText" -Result $False -Details $_.Exception.Message
}

Try {
    $Pattern = ConvertTo-DMRegexPattern "\\server\*\data"
    # Should convert * to .* and escape backslashes
    [Boolean]$Success = ($Pattern -match '\\\\\.\*\\')
    Write-TestResult -TestName "ConvertTo-DMRegexPattern" -Result $Success -Details $Pattern
} Catch {
    Write-TestResult -TestName "ConvertTo-DMRegexPattern" -Result $False -Details $_.Exception.Message
}

Try {
    $Matches = Test-DMWildcardMatch -Text "\\server\share\data" -Pattern "\\server\*"
    Write-TestResult -TestName "Test-DMWildcardMatch" -Result $Matches
} Catch {
    Write-TestResult -TestName "Test-DMWildcardMatch" -Result $False -Details $_.Exception.Message
}

Try {
    $Expanded = Expand-DMEnvironmentPath "%COMPUTERNAME%\test"
    [Boolean]$Success = ($Expanded -notlike "*%COMPUTERNAME%*")
    Write-TestResult -TestName "Expand-DMEnvironmentPath" -Result $Success -Details $Expanded
} Catch {
    Write-TestResult -TestName "Expand-DMEnvironmentPath" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 4: DMRegistry.psm1
# ============================================================================
Write-TestHeader "DMRegistry.psm1"

Try {
    Import-Module .\Modules\Framework\DMRegistry.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $TestPath = "HKCU:\Software\Nomura\GDP\Test"
    $SetResult = Set-DMRegistryValue -Path $TestPath -Name "TestValue" -Value "Phase1Test" -Type String
    Write-TestResult -TestName "Set-DMRegistryValue" -Result $SetResult
} Catch {
    Write-TestResult -TestName "Set-DMRegistryValue" -Result $False -Details $_.Exception.Message
}

Try {
    $Value = Get-DMRegistryValue -Path $TestPath -Name "TestValue" -DefaultValue "NotFound"
    [Boolean]$Success = ($Value -eq "Phase1Test")
    Write-TestResult -TestName "Get-DMRegistryValue" -Result $Success -Details "Value: $Value"
} Catch {
    Write-TestResult -TestName "Get-DMRegistryValue" -Result $False -Details $_.Exception.Message
}

Try {
    $SetResult = Set-DMExecutionMetadata -JobType "Phase1Test" -Version "2.0.0"
    Write-TestResult -TestName "Set-DMExecutionMetadata" -Result $SetResult
} Catch {
    Write-TestResult -TestName "Set-DMExecutionMetadata" -Result $False -Details $_.Exception.Message
}

Try {
    $Metadata = Get-DMExecutionMetadata -JobType "Phase1Test"
    [Boolean]$Success = ($Null -ne $Metadata -and $Metadata.Version -eq "2.0.0")
    Write-TestResult -TestName "Get-DMExecutionMetadata" -Result $Success -Details "Version: $($Metadata.Version)"
} Catch {
    Write-TestResult -TestName "Get-DMExecutionMetadata" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 5: Test-Environment.psm1
# ============================================================================
Write-TestHeader "Test-Environment.psm1"

Try {
    Import-Module .\Modules\Utilities\Test-Environment.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $VPNStatus = Test-DMVPNConnection
    Write-TestResult -TestName "Test-DMVPNConnection" -Result $True -Details "VPN Connected: $VPNStatus"
} Catch {
    Write-TestResult -TestName "Test-DMVPNConnection" -Result $False -Details $_.Exception.Message
}

Try {
    $SessionInfo = Test-DMTerminalSession
    [Boolean]$Success = ($Null -ne $SessionInfo)
    Write-TestResult -TestName "Test-DMTerminalSession" -Result $Success -Details "Type: $($SessionInfo.SessionType)"
} Catch {
    Write-TestResult -TestName "Test-DMTerminalSession" -Result $False -Details $_.Exception.Message
}

Try {
    $VMInfo = Test-DMVirtualMachine
    [Boolean]$Success = ($Null -ne $VMInfo)
    Write-TestResult -TestName "Test-DMVirtualMachine" -Result $Success -Details "Platform: $($VMInfo.Platform)"
} Catch {
    Write-TestResult -TestName "Test-DMVirtualMachine" -Result $False -Details $_.Exception.Message
}

Try {
    $IsServer = Test-DMServerOS
    Write-TestResult -TestName "Test-DMServerOS" -Result $True -Details "Is Server: $IsServer"
} Catch {
    Write-TestResult -TestName "Test-DMServerOS" -Result $False -Details $_.Exception.Message
}

Try {
    $Locale = Get-DMSystemLocale
    [Boolean]$Success = (-not [String]::IsNullOrEmpty($Locale))
    Write-TestResult -TestName "Get-DMSystemLocale" -Result $Success -Details "Locale: $Locale"
} Catch {
    Write-TestResult -TestName "Get-DMSystemLocale" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 6: DMComputer.psm1 (Requires Domain)
# ============================================================================
Write-TestHeader "DMComputer.psm1 (Requires Domain-Joined Computer)"

Try {
    Import-Module .\Modules\Framework\DMComputer.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    Write-Host "  [INFO] Collecting computer information (may take a few seconds)..." -ForegroundColor Gray
    $Computer = Get-DMComputerInfo
    
    If ($Null -ne $Computer) {
        Write-TestResult -TestName "Get-DMComputerInfo" -Result $True -Details "Name: $($Computer.Name)"
        
        # Save to file for inspection
        $Computer | ConvertTo-Json | Out-File -FilePath (Join-Path $TestOutputPath "ComputerInfo.json")
        
        # Display key properties
        Write-Host "    Computer: $($Computer.Name)" -ForegroundColor Cyan
        Write-Host "    Domain: $($Computer.Domain)" -ForegroundColor Cyan
        Write-Host "    Site: $($Computer.Site)" -ForegroundColor Cyan
        Write-Host "    City Code: $($Computer.CityCode)" -ForegroundColor Cyan
        Write-Host "    Groups: $($Computer.Groups.Count)" -ForegroundColor Cyan
        Write-Host "    VPN Connected: $($Computer.IsVPNConnected)" -ForegroundColor Cyan
    } Else {
        Write-TestResult -TestName "Get-DMComputerInfo" -Result $False -Details "Returned NULL (not domain-joined?)"
    }
} Catch {
    Write-TestResult -TestName "Get-DMComputerInfo" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 7: DMUser.psm1 (Requires Domain)
# ============================================================================
Write-TestHeader "DMUser.psm1 (Requires Domain-Joined Computer)"

Try {
    Import-Module .\Modules\Framework\DMUser.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    Write-Host "  [INFO] Collecting user information (may take a few seconds)..." -ForegroundColor Gray
    $User = Get-DMUserInfo
    
    If ($Null -ne $User) {
        Write-TestResult -TestName "Get-DMUserInfo" -Result $True -Details "Name: $($User.Name)"
        
        # Save to file for inspection
        $User | ConvertTo-Json | Out-File -FilePath (Join-Path $TestOutputPath "UserInfo.json")
        
        # Display key properties
        Write-Host "    User: $($User.Name)" -ForegroundColor Cyan
        Write-Host "    Domain: $($User.Domain)" -ForegroundColor Cyan
        Write-Host "    City Code: $($User.CityCode)" -ForegroundColor Cyan
        Write-Host "    Groups: $($User.Groups.Count)" -ForegroundColor Cyan
        Write-Host "    Terminal Session: $($User.IsTerminalSession)" -ForegroundColor Cyan
    } Else {
        Write-TestResult -TestName "Get-DMUserInfo" -Result $False -Details "Returned NULL (not domain-joined?)"
    }
} Catch {
    Write-TestResult -TestName "Get-DMUserInfo" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Summary
# ============================================================================
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Passed: $TestsPassed" -ForegroundColor Green
Write-Host "Total Failed: $TestsFailed" -ForegroundColor $(If ($TestsFailed -gt 0) { "Red" } Else { "Green" })
Write-Host ""

If ($TestsFailed -eq 0) {
    Write-Host "[SUCCESS] All Phase 1 tests passed!" -ForegroundColor Green
} Else {
    Write-Host "[WARNING] Some tests failed. Review details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Test artifacts saved to: $TestOutputPath" -ForegroundColor Cyan
Write-Host "  - ComputerInfo.json (if domain-joined)" -ForegroundColor Gray
Write-Host "  - UserInfo.json (if domain-joined)" -ForegroundColor Gray
Write-Host ""
Write-Host "Log file location: $(Get-DMLogPath)" -ForegroundColor Cyan
Write-Host ""

