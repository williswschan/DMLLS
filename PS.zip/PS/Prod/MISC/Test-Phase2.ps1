# Desktop Management Suite - Phase 2 Services Testing Script
# Tests all Phase 2 service modules with mock backend
# REQUIRES: Mock backend server running at gdpmappercb.nomura.com

Param(
    [Switch]$Verbose
)

$ErrorActionPreference = 'Continue'

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Phase 2 Services Testing" -ForegroundColor Cyan
Write-Host "Desktop Management Suite v2.0" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

[Int]$TestsPassed = 0
[Int]$TestsFailed = 0

Function Write-TestHeader {
    Param([String]$ModuleName)
    Write-Host ""
    Write-Host "=== Testing: $ModuleName ===" -ForegroundColor Yellow
}

Function Write-TestResult {
    Param(
        [String]$TestName,
        [Boolean]$Result,
        [String]$Details = ""
    )
    
    If ($Result) {
        Write-Host "  [PASS] $TestName" -ForegroundColor Green
        If ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
        $Script:TestsPassed++
    } Else {
        Write-Host "  [FAIL] $TestName" -ForegroundColor Red
        If ($Details) { Write-Host "         $Details" -ForegroundColor Red }
        $Script:TestsFailed++
    }
}

# ============================================================================
# Pre-Test: Check Mock Backend
# ============================================================================
Write-Host "Checking Mock Backend Availability..." -ForegroundColor Yellow

Try {
    $TestConnection = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/" -TimeoutSec 5 -ErrorAction Stop
    Write-Host "  [OK] Mock backend is accessible" -ForegroundColor Green
} Catch {
    Write-Host "  [ERROR] Mock backend is NOT accessible!" -ForegroundColor Red
    Write-Host "  Please start the mock backend server first:" -ForegroundColor Yellow
    Write-Host "    cd C:\Temp\Script\DMLLS\WEB" -ForegroundColor Yellow
    Write-Host "    python mock_backend.py" -ForegroundColor Yellow
    Write-Host "" -ForegroundColor Yellow
    Exit 1
}

# Import required modules
Import-Module .\Modules\Framework\DMLogger.psm1 -Force
Import-Module .\Modules\Utilities\Test-Environment.psm1 -Force
Import-Module .\Modules\Framework\DMComputer.psm1 -Force
Import-Module .\Modules\Framework\DMUser.psm1 -Force

# Initialize logging
Initialize-DMLog -JobType "Phase2Test" -VerboseLogging:$Verbose

# Get computer and user info
$Computer = Get-DMComputerInfo
$User = Get-DMUserInfo

Write-DMLog "Starting Phase 2 tests with Computer: $($Computer.Name), User: $($User.Name)"

# ============================================================================
# Test 1: DMServiceCommon.psm1
# ============================================================================
Write-TestHeader "DMServiceCommon.psm1"

Try {
    Import-Module .\Modules\Services\DMServiceCommon.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $Server = Get-DMServiceServer -ServiceName "ClassicMapper.asmx"
    [Boolean]$Success = ($Null -ne $Server)
    Write-TestResult -TestName "Get-DMServiceServer" -Result $Success -Details "Server: $($Server.ServerName)"
} Catch {
    Write-TestResult -TestName "Get-DMServiceServer" -Result $False -Details $_.Exception.Message
}

Try {
    [Boolean]$IsHealthy = Test-DMServiceHealth -ServiceURL "http://gdpmappercb.nomura.com/ClassicMapper.asmx"
    Write-TestResult -TestName "Test-DMServiceHealth (Mapper)" -Result $IsHealthy
} Catch {
    Write-TestResult -TestName "Test-DMServiceHealth (Mapper)" -Result $False -Details $_.Exception.Message
}

Try {
    [Boolean]$IsHealthy = Test-DMServiceHealth -ServiceURL "http://gdpmappercb.nomura.com/ClassicInventory.asmx"
    Write-TestResult -TestName "Test-DMServiceHealth (Inventory)" -Result $IsHealthy
} Catch {
    Write-TestResult -TestName "Test-DMServiceHealth (Inventory)" -Result $False -Details $_.Exception.Message
}

Try {
    $Soap = New-DMSOAPEnvelope -MethodName "TestMethod" -MethodBody "<Param1>Value1</Param1>"
    [Boolean]$Success = ($Soap -like "*TestMethod*" -and $Soap -like "*Param1*")
    Write-TestResult -TestName "New-DMSOAPEnvelope" -Result $Success
} Catch {
    Write-TestResult -TestName "New-DMSOAPEnvelope" -Result $False -Details $_.Exception.Message
}

Try {
    $XML = New-DMXMLElement -ElementName "UserName" -Content "testuser"
    [Boolean]$Success = ($XML -like "*UserName*" -and $XML -like "*testuser*")
    Write-TestResult -TestName "New-DMXMLElement" -Result $Success
} Catch {
    Write-TestResult -TestName "New-DMXMLElement" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 2: DMInventoryService.psm1
# ============================================================================
Write-TestHeader "DMInventoryService.psm1"

Try {
    Import-Module .\Modules\Services\DMInventoryService.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $InventoryServer = Get-DMInventoryServer
    [Boolean]$Success = ($Null -ne $InventoryServer)
    Write-TestResult -TestName "Get-DMInventoryServer" -Result $Success -Details "Server: $($InventoryServer.ServerName)"
} Catch {
    Write-TestResult -TestName "Get-DMInventoryServer" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Send-DMLogonInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Send-DMLogonInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Send-DMLogonInventory" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Send-DMLogoffInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Send-DMLogoffInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Send-DMLogoffInventory" -Result $False -Details $_.Exception.Message
}

Try {
    # Create test drive inventory
    $TestDrives = @(
        [PSCustomObject]@{
            DriveLetter = "H:"
            UncPath = "\\fileserver\home\testuser"
            Description = "Home Drive"
        }
    )
    
    $Success = Send-DMDriveInventory -DriveInfo $TestDrives -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Send-DMDriveInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Send-DMDriveInventory" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 3: DMMapperService.psm1
# ============================================================================
Write-TestHeader "DMMapperService.psm1"

Try {
    Import-Module .\Modules\Services\DMMapperService.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $MapperServer = Get-DMMapperServer
    [Boolean]$Success = ($Null -ne $MapperServer)
    Write-TestResult -TestName "Get-DMMapperServer" -Result $Success -Details "Server: $($MapperServer.ServerName)"
} Catch {
    Write-TestResult -TestName "Get-DMMapperServer" -Result $False -Details $_.Exception.Message
}

Try {
    # Create test user with name "testuser" to match mock data
    $TestUser = [PSCustomObject]@{
        Name = "testuser"
        Domain = "ASIAPAC.NOM"
        ShortDomain = "ASIAPAC"
        OUMapping = "RESOURCES/HKG/USERS"
        CityCode = "HKG"
        Groups = @()
    }
    
    $Drives = Get-DMDriveMappings -UserInfo $TestUser -ComputerInfo $Computer
    [Boolean]$Success = ($Null -ne $Drives)
    Write-TestResult -TestName "Get-DMDriveMappings" -Result $Success -Details "Found: $($Drives.Count) drive(s)"
    
    If ($Drives.Count -gt 0) {
        Write-Host "    Drives returned:" -ForegroundColor Cyan
        ForEach ($Drive in $Drives) {
            Write-Host "      $($Drive.DriveLetter) -> $($Drive.UncPath) [$($Drive.Description)]" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMDriveMappings" -Result $False -Details $_.Exception.Message
}

Try {
    # Create test computer matching mock data
    $TestComputer = [PSCustomObject]@{
        Name = "WKS001"
        Domain = "ASIAPAC.NOM"
        ShortDomain = "ASIAPAC"
        CityCode = "HKG"
        Groups = @()
    }
    
    $Printers = Get-DMPrinterMappings -ComputerInfo $TestComputer
    [Boolean]$Success = ($Null -ne $Printers)
    Write-TestResult -TestName "Get-DMPrinterMappings" -Result $Success -Details "Found: $($Printers.Count) printer(s)"
    
    If ($Printers.Count -gt 0) {
        Write-Host "    Printers returned:" -ForegroundColor Cyan
        ForEach ($Printer in $Printers) {
            Write-Host "      $($Printer.UncPath) $(If ($Printer.IsDefault) {'[DEFAULT]'})" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMPrinterMappings" -Result $False -Details $_.Exception.Message
}

Try {
    $TestUser = [PSCustomObject]@{
        Name = "testuser"
        Domain = "ASIAPAC.NOM"
        OUMapping = "RESOURCES/HKG/USERS"
    }
    
    $PSTs = Get-DMPSTMappings -UserInfo $TestUser
    [Boolean]$Success = ($Null -ne $PSTs)
    Write-TestResult -TestName "Get-DMPSTMappings" -Result $Success -Details "Found: $($PSTs.Count) PST(s)"
    
    If ($PSTs.Count -gt 0) {
        Write-Host "    PSTs returned:" -ForegroundColor Cyan
        ForEach ($PST in $PSTs) {
            Write-Host "      $($PST.UncPath)" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMPSTMappings" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Summary
# ============================================================================
Export-DMLog

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Passed: $TestsPassed" -ForegroundColor Green
Write-Host "Total Failed: $TestsFailed" -ForegroundColor $(If ($TestsFailed -gt 0) { "Red" } Else { "Green" })
Write-Host ""

If ($TestsFailed -eq 0) {
    Write-Host "[SUCCESS] All Phase 2 tests passed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Check mock backend CSV files for collected data:" -ForegroundColor Cyan
    Write-Host "  - WEB\Data\sessions.csv (logon/logoff events)" -ForegroundColor Gray
    Write-Host "  - WEB\Data\inventory_drives.csv (drive inventory)" -ForegroundColor Gray
} Else {
    Write-Host "[WARNING] Some tests failed. Review details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Log file location: $(Get-DMLogPath)" -ForegroundColor Cyan
Write-Host ""

