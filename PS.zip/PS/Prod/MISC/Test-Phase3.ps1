# Desktop Management Suite - Phase 3 Inventory Testing Script
# Tests all Phase 3 inventory modules
# REQUIRES: Mock backend server running at gdpmappercb.nomura.com

Param(
    [Switch]$Verbose
)

$ErrorActionPreference = 'Continue'

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Phase 3 Inventory Testing" -ForegroundColor Cyan
Write-Host "Desktop Management Suite v2.0" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

[Int]$TestsPassed = 0
[Int]$TestsFailed = 0

Function Write-TestHeader {
    Param([String]$ModuleName)
    Write-Host ""
    Write-Host "=== Testing: $ModuleName ===" -ForegroundColor Yellow
}

Function Write-TestResult {
    Param(
        [String]$TestName,
        [Boolean]$Result,
        [String]$Details = ""
    )
    
    If ($Result) {
        Write-Host "  [PASS] $TestName" -ForegroundColor Green
        If ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
        $Script:TestsPassed++
    } Else {
        Write-Host "  [FAIL] $TestName" -ForegroundColor Red
        If ($Details) { Write-Host "         $Details" -ForegroundColor Red }
        $Script:TestsFailed++
    }
}

# ============================================================================
# Pre-Test: Check Mock Backend
# ============================================================================
Write-Host "Checking Mock Backend Availability..." -ForegroundColor Yellow

Try {
    $TestConnection = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/" -TimeoutSec 5 -ErrorAction Stop
    Write-Host "  [OK] Mock backend is accessible" -ForegroundColor Green
} Catch {
    Write-Host "  [ERROR] Mock backend is NOT accessible!" -ForegroundColor Red
    Write-Host "  Please start the mock backend server first" -ForegroundColor Yellow
    Exit 1
}

# Import required modules
Import-Module .\Modules\Framework\DMLogger.psm1 -Force
Import-Module .\Modules\Utilities\Test-Environment.psm1 -Force
Import-Module .\Modules\Framework\DMComputer.psm1 -Force
Import-Module .\Modules\Framework\DMUser.psm1 -Force
Import-Module .\Modules\Services\DMServiceCommon.psm1 -Force
Import-Module .\Modules\Services\DMInventoryService.psm1 -Force

# Initialize logging
Initialize-DMLog -JobType "Phase3Test" -VerboseLogging:$Verbose

# Get computer and user info
$Computer = Get-DMComputerInfo
$User = Get-DMUserInfo

Write-DMLog "Starting Phase 3 tests with Computer: $($Computer.Name), User: $($User.Name)"

# ============================================================================
# Test 1: Invoke-UserSessionInventory.psm1
# ============================================================================
Write-TestHeader "Invoke-UserSessionInventory.psm1"

Try {
    Import-Module .\Modules\Inventory\Invoke-UserSessionInventory.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Invoke-DMUserSessionLogonInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Invoke-DMUserSessionLogonInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Invoke-DMUserSessionLogonInventory" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Invoke-DMUserSessionLogoffInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Invoke-DMUserSessionLogoffInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Invoke-DMUserSessionLogoffInventory" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 2: Invoke-DriveInventory.psm1
# ============================================================================
Write-TestHeader "Invoke-DriveInventory.psm1"

Try {
    Import-Module .\Modules\Inventory\Invoke-DriveInventory.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $MappedDrives = Get-DMMappedDrives
    # Success even if 0 drives (valid result)
    [Boolean]$Success = $True
    Write-TestResult -TestName "Get-DMMappedDrives" -Result $Success -Details "Found: $($MappedDrives.Count) drive(s)"
    
    If ($MappedDrives.Count -gt 0) {
        Write-Host "    Mapped drives found:" -ForegroundColor Cyan
        ForEach ($Drive in $MappedDrives) {
            Write-Host "      $($Drive.DriveLetter) -> $($Drive.UncPath) [$($Drive.Description)]" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMMappedDrives" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Invoke-DMDriveInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Invoke-DMDriveInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Invoke-DMDriveInventory" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 3: Invoke-PrinterInventory.psm1
# ============================================================================
Write-TestHeader "Invoke-PrinterInventory.psm1"

Try {
    Import-Module .\Modules\Inventory\Invoke-PrinterInventory.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $NetworkPrinters = Get-DMNetworkPrinters
    # Success even if 0 printers (valid result for non-domain workstation)
    [Boolean]$Success = $True
    Write-TestResult -TestName "Get-DMNetworkPrinters" -Result $Success -Details "Found: $($NetworkPrinters.Count) printer(s)"
    
    If ($NetworkPrinters.Count -gt 0) {
        Write-Host "    Network printers found:" -ForegroundColor Cyan
        ForEach ($Printer in $NetworkPrinters) {
            Write-Host "      $($Printer.UncPath) $(If ($Printer.IsDefault) {'[DEFAULT]'})" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMNetworkPrinters" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Invoke-DMPrinterInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Invoke-DMPrinterInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Invoke-DMPrinterInventory" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Test 4: Invoke-PersonalFolderInventory.psm1
# ============================================================================
Write-TestHeader "Invoke-PersonalFolderInventory.psm1"

Try {
    Import-Module .\Modules\Inventory\Invoke-PersonalFolderInventory.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $DefaultProfile = Get-DMOutlookDefaultProfile
    [Boolean]$HasOutlook = (-not [String]::IsNullOrEmpty($DefaultProfile))
    Write-TestResult -TestName "Get-DMOutlookDefaultProfile" -Result $True -Details "Profile: $(If ($HasOutlook) {$DefaultProfile} Else {'None'})"
} Catch {
    Write-TestResult -TestName "Get-DMOutlookDefaultProfile" -Result $False -Details $_.Exception.Message
}

Try {
    $PSTFiles = Get-DMOutlookPSTFiles
    # Success even if 0 PST files (valid if Outlook not configured with PSTs)
    [Boolean]$Success = $True
    Write-TestResult -TestName "Get-DMOutlookPSTFiles" -Result $Success -Details "Found: $($PSTFiles.Count) PST file(s)"
    
    If ($PSTFiles.Count -gt 0) {
        Write-Host "    PST files found:" -ForegroundColor Cyan
        ForEach ($PST in $PSTFiles) {
            Write-Host "      $($PST.Path) [$($PST.Size) bytes]" -ForegroundColor Gray
        }
    }
} Catch {
    Write-TestResult -TestName "Get-DMOutlookPSTFiles" -Result $False -Details $_.Exception.Message
}

Try {
    $Success = Invoke-DMPersonalFolderInventory -UserInfo $User -ComputerInfo $Computer
    Write-TestResult -TestName "Invoke-DMPersonalFolderInventory" -Result $Success
} Catch {
    Write-TestResult -TestName "Invoke-DMPersonalFolderInventory" -Result $False -Details $_.Exception.Message
}

# ============================================================================
# Summary
# ============================================================================
Export-DMLog

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Passed: $TestsPassed" -ForegroundColor Green
Write-Host "Total Failed: $TestsFailed" -ForegroundColor $(If ($TestsFailed -gt 0) { "Red" } Else { "Green" })
Write-Host ""

If ($TestsFailed -eq 0) {
    Write-Host "[SUCCESS] All Phase 3 tests passed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Check mock backend CSV files for collected inventory data:" -ForegroundColor Cyan
    Write-Host "  - WEB\Data\sessions.csv (logon/logoff events)" -ForegroundColor Gray
    Write-Host "  - WEB\Data\inventory_drives.csv (drive inventory)" -ForegroundColor Gray
    Write-Host "  - WEB\Data\inventory_printers.csv (printer inventory)" -ForegroundColor Gray
    Write-Host "  - WEB\Data\inventory_pst.csv (PST file inventory)" -ForegroundColor Gray
} Else {
    Write-Host "[WARNING] Some tests failed. Review details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Log file location: $(Get-DMLogPath)" -ForegroundColor Cyan
Write-Host ""

