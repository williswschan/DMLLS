# Desktop Management Suite - Phase 4 Mapper Testing Script
# Tests all Phase 4 mapper modules
# REQUIRES: Mock backend server running at gdpmappercb.nomura.com
# WARNING: This script will actually MAP/UNMAP drives, printers, and PSTs on your system!

Param(
    [Switch]$Verbose,
    [Switch]$DryRun  # If specified, tests functions but skips actual mapping operations
)

$ErrorActionPreference = 'Continue'

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Phase 4 Mapper Testing" -ForegroundColor Cyan
Write-Host "Desktop Management Suite v2.0" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

If ($DryRun) {
    Write-Host "[DRY RUN MODE] Actual mapping operations will be skipped" -ForegroundColor Yellow
    Write-Host ""
}

[Int]$TestsPassed = 0
[Int]$TestsFailed = 0

Function Write-TestHeader {
    Param([String]$ModuleName)
    Write-Host ""
    Write-Host "=== Testing: $ModuleName ===" -ForegroundColor Yellow
}

Function Write-TestResult {
    Param(
        [String]$TestName,
        [Boolean]$Result,
        [String]$Details = ""
    )
    
    If ($Result) {
        Write-Host "  [PASS] $TestName" -ForegroundColor Green
        If ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
        $Script:TestsPassed++
    } Else {
        Write-Host "  [FAIL] $TestName" -ForegroundColor Red
        If ($Details) { Write-Host "         $Details" -ForegroundColor Red }
        $Script:TestsFailed++
    }
}

# ============================================================================
# Pre-Test: Check Mock Backend
# ============================================================================
Write-Host "Checking Mock Backend Availability..." -ForegroundColor Yellow

Try {
    $TestConnection = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/" -TimeoutSec 5 -ErrorAction Stop
    Write-Host "  [OK] Mock backend is accessible" -ForegroundColor Green
} Catch {
    Write-Host "  [ERROR] Mock backend is NOT accessible!" -ForegroundColor Red
    Write-Host "  Please start the mock backend server first" -ForegroundColor Yellow
    Exit 1
}

# Import required modules
Import-Module .\Modules\Framework\DMLogger.psm1 -Force
Import-Module .\Modules\Utilities\Test-Environment.psm1 -Force
Import-Module .\Modules\Framework\DMComputer.psm1 -Force
Import-Module .\Modules\Framework\DMUser.psm1 -Force
Import-Module .\Modules\Framework\DMCommon.psm1 -Force
Import-Module .\Modules\Services\DMServiceCommon.psm1 -Force
Import-Module .\Modules\Services\DMMapperService.psm1 -Force
Import-Module .\Modules\Inventory\Invoke-DriveInventory.psm1 -Force

# Initialize logging
Initialize-DMLog -JobType "Phase4Test" -VerboseLogging:$Verbose

# Get computer and user info
$Computer = Get-DMComputerInfo
$User = Get-DMUserInfo

Write-DMLog "Starting Phase 4 tests with Computer: $($Computer.Name), User: $($User.Name)"

# ============================================================================
# Test 1: Invoke-DriveMapper.psm1
# ============================================================================
Write-TestHeader "Invoke-DriveMapper.psm1"

Try {
    Import-Module .\Modules\Mapper\Invoke-DriveMapper.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

# Test with mock user that has mappings in backend
$TestUser = [PSCustomObject]@{
    Name = "testuser"
    Domain = "ASIAPAC.NOM"
    ShortDomain = "ASIAPAC"
    OUMapping = "RESOURCES/HKG/USERS"
    CityCode = "HKG"
    DistinguishedName = "CN=testuser,OU=USERS,OU=RESOURCES,OU=HKG,DC=asiapac,DC=nom"
    Groups = @()
}

If (-not $DryRun) {
    Try {
        Write-Host "  [INFO] This will attempt to map drives from the backend..." -ForegroundColor Yellow
        Write-Host "  [INFO] Press Ctrl+C within 3 seconds to cancel..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
        
        $Success = Invoke-DMDriveMapper -UserInfo $TestUser -ComputerInfo $Computer
        Write-TestResult -TestName "Invoke-DMDriveMapper (with real mappings)" -Result $Success
    } Catch {
        Write-TestResult -TestName "Invoke-DMDriveMapper (with real mappings)" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Invoke-DMDriveMapper (DryRun mode)" -ForegroundColor Yellow
}

# ============================================================================
# Test 2: Invoke-PrinterMapper.psm1
# ============================================================================
Write-TestHeader "Invoke-PrinterMapper.psm1"

Try {
    Import-Module .\Modules\Mapper\Invoke-PrinterMapper.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

Try {
    $InstalledPrinters = Get-DMInstalledPrinters
    [Boolean]$Success = $True
    Write-TestResult -TestName "Get-DMInstalledPrinters" -Result $Success -Details "Found: $($InstalledPrinters.Count) printer(s)"
} Catch {
    Write-TestResult -TestName "Get-DMInstalledPrinters" -Result $False -Details $_.Exception.Message
}

$TestComputer = [PSCustomObject]@{
    Name = "WKS001"
    Domain = "ASIAPAC.NOM"
    ShortDomain = "ASIAPAC"
    CityCode = "HKG"
    DistinguishedName = "CN=WKS001,OU=DEVICES,OU=RESOURCES,OU=HKG,DC=asiapac,DC=nom"
    OSCaption = "Microsoft Windows 10 Pro"
    Groups = @()
}

If (-not $DryRun) {
    Try {
        Write-Host "  [INFO] This will attempt to map printers from the backend..." -ForegroundColor Yellow
        Write-Host "  [INFO] Press Ctrl+C within 3 seconds to cancel..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
        
        $Success = Invoke-DMPrinterMapper -UserInfo $TestUser -ComputerInfo $TestComputer
        Write-TestResult -TestName "Invoke-DMPrinterMapper (with real mappings)" -Result $Success
    } Catch {
        Write-TestResult -TestName "Invoke-DMPrinterMapper (with real mappings)" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Invoke-DMPrinterMapper (DryRun mode)" -ForegroundColor Yellow
}

# ============================================================================
# Test 3: Invoke-PersonalFolderMapper.psm1
# ============================================================================
Write-TestHeader "Invoke-PersonalFolderMapper.psm1"

Try {
    Import-Module .\Modules\Mapper\Invoke-PersonalFolderMapper.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

If (-not $DryRun) {
    Try {
        Write-Host "  [INFO] This will attempt to map PST files from the backend..." -ForegroundColor Yellow
        Write-Host "  [INFO] Press Ctrl+C within 3 seconds to cancel..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
        
        $Success = Invoke-DMPersonalFolderMapper -UserInfo $TestUser -ComputerInfo $TestComputer
        Write-TestResult -TestName "Invoke-DMPersonalFolderMapper (with real mappings)" -Result $Success
    } Catch {
        Write-TestResult -TestName "Invoke-DMPersonalFolderMapper (with real mappings)" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Invoke-DMPersonalFolderMapper (DryRun mode)" -ForegroundColor Yellow
}

# ============================================================================
# Summary
# ============================================================================
Export-DMLog

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Passed: $TestsPassed" -ForegroundColor Green
Write-Host "Total Failed: $TestsFailed" -ForegroundColor $(If ($TestsFailed -gt 0) { "Red" } Else { "Green" })
Write-Host ""

If ($DryRun) {
    Write-Host "[DRY RUN] To test actual mapping operations, run without -DryRun" -ForegroundColor Yellow
}

If ($TestsFailed -eq 0) {
    Write-Host "[SUCCESS] All Phase 4 tests passed!" -ForegroundColor Green
} Else {
    Write-Host "[WARNING] Some tests failed. Review details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Log file location: $(Get-DMLogPath)" -ForegroundColor Cyan
Write-Host ""

If (-not $DryRun) {
    Write-Host "========================================" -ForegroundColor Yellow
    Write-Host "IMPORTANT: Check if any drives/printers were mapped!" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Yellow
    Write-Host "To view mapped drives:" -ForegroundColor Cyan
    Write-Host "  net use" -ForegroundColor Gray
    Write-Host ""
    Write-Host "To remove test mappings:" -ForegroundColor Cyan
    Write-Host "  net use H: /delete" -ForegroundColor Gray
    Write-Host "  net use P: /delete" -ForegroundColor Gray
    Write-Host "  net use F: /delete" -ForegroundColor Gray
    Write-Host ""
}

