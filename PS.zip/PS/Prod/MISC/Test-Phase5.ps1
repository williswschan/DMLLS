# Desktop Management Suite - Phase 5 Utilities Testing Script
# Tests all Phase 5 utility modules
#
# *** WARNING: DO NOT RUN THIS SCRIPT UNLESS YOU UNDERSTAND WHAT IT DOES! ***
# This script will:
# - Change your monitor timeout settings (PowerCFG)
# - Show password expiry popup (if applicable)
# - Change V: drive label (if Retail user)
# - Import IE zone registry settings (if enabled)
#
# Some of these changes may affect your system configuration!

Param(
    [Switch]$Verbose,
    [Switch]$SkipPowerCFG,
    [Switch]$SkipPasswordNotification,
    [Switch]$SkipRetailLabel,
    [Switch]$SkipIEZones
)

$ErrorActionPreference = 'Continue'

Write-Host "========================================" -ForegroundColor Red
Write-Host "Phase 5 Utilities Testing" -ForegroundColor Red
Write-Host "*** WARNING: SYSTEM CONFIGURATION ***" -ForegroundColor Red
Write-Host "========================================" -ForegroundColor Red
Write-Host ""
Write-Host "This test will modify system settings!" -ForegroundColor Yellow
Write-Host ""
Write-Host "Skip options available:" -ForegroundColor Cyan
Write-Host "  -SkipPowerCFG               (skip monitor timeout changes)" -ForegroundColor Gray
Write-Host "  -SkipPasswordNotification   (skip password popup)" -ForegroundColor Gray
Write-Host "  -SkipRetailLabel            (skip V: drive label)" -ForegroundColor Gray
Write-Host "  -SkipIEZones                (skip IE zone import)" -ForegroundColor Gray
Write-Host ""
Write-Host "Press Ctrl+C within 5 seconds to cancel..." -ForegroundColor Yellow
Start-Sleep -Seconds 5
Write-Host ""

[Int]$TestsPassed = 0
[Int]$TestsFailed = 0

Function Write-TestHeader {
    Param([String]$ModuleName)
    Write-Host ""
    Write-Host "=== Testing: $ModuleName ===" -ForegroundColor Yellow
}

Function Write-TestResult {
    Param(
        [String]$TestName,
        [Boolean]$Result,
        [String]$Details = ""
    )
    
    If ($Result) {
        Write-Host "  [PASS] $TestName" -ForegroundColor Green
        If ($Details) { Write-Host "         $Details" -ForegroundColor Gray }
        $Script:TestsPassed++
    } Else {
        Write-Host "  [FAIL] $TestName" -ForegroundColor Red
        If ($Details) { Write-Host "         $Details" -ForegroundColor Red }
        $Script:TestsFailed++
    }
}

# Import required modules
Import-Module .\Modules\Framework\DMLogger.psm1 -Force
Import-Module .\Modules\Utilities\Test-Environment.psm1 -Force
Import-Module .\Modules\Framework\DMComputer.psm1 -Force
Import-Module .\Modules\Framework\DMUser.psm1 -Force
Import-Module .\Modules\Services\DMServiceCommon.psm1 -Force

# Initialize logging
Initialize-DMLog -JobType "Phase5Test" -VerboseLogging:$Verbose

# Get computer and user info
$Computer = Get-DMComputerInfo
$User = Get-DMUserInfo

Write-DMLog "Starting Phase 5 tests with Computer: $($Computer.Name), User: $($User.Name)"

# ============================================================================
# Test 1: Set-PowerConfiguration.psm1
# ============================================================================
Write-TestHeader "Set-PowerConfiguration.psm1"

Try {
    Import-Module .\Modules\Utilities\Set-PowerConfiguration.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

If (-not $SkipPowerCFG) {
    Write-Host "  [WARNING] This will change monitor timeout settings!" -ForegroundColor Yellow
    Write-Host "  [INFO] Press Ctrl+C within 3 seconds to skip..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    
    Try {
        $Success = Set-DMPowerConfiguration -JobType "Logon"
        Write-TestResult -TestName "Set-DMPowerConfiguration (Logon)" -Result $Success
    } Catch {
        Write-TestResult -TestName "Set-DMPowerConfiguration (Logon)" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Set-DMPowerConfiguration (SkipPowerCFG flag)" -ForegroundColor Yellow
}

# ============================================================================
# Test 2: Show-PasswordExpiryNotification.psm1
# ============================================================================
Write-TestHeader "Show-PasswordExpiryNotification.psm1"

Try {
    Import-Module .\Modules\Utilities\Show-PasswordExpiryNotification.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

If (-not $SkipPasswordNotification) {
    Write-Host "  [WARNING] This may show a password expiry popup!" -ForegroundColor Yellow
    Write-Host "  [INFO] Press Ctrl+C within 3 seconds to skip..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    
    Try {
        $Success = Show-DMPasswordExpiryNotification -UserInfo $User
        Write-TestResult -TestName "Show-DMPasswordExpiryNotification" -Result $Success
    } Catch {
        Write-TestResult -TestName "Show-DMPasswordExpiryNotification" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Show-DMPasswordExpiryNotification (SkipPasswordNotification flag)" -ForegroundColor Yellow
}

# ============================================================================
# Test 3: Set-RetailHomeDriveLabel.psm1
# ============================================================================
Write-TestHeader "Set-RetailHomeDriveLabel.psm1"

Try {
    Import-Module .\Modules\Utilities\Set-RetailHomeDriveLabel.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

If (-not $SkipRetailLabel) {
    Write-Host "  [WARNING] This will change V: drive label if you're a Retail user!" -ForegroundColor Yellow
    Write-Host "  [INFO] Press Ctrl+C within 3 seconds to skip..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    
    Try {
        $Success = Set-DMRetailHomeDriveLabel -UserInfo $User
        Write-TestResult -TestName "Set-DMRetailHomeDriveLabel" -Result $Success
    } Catch {
        Write-TestResult -TestName "Set-DMRetailHomeDriveLabel" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Set-DMRetailHomeDriveLabel (SkipRetailLabel flag)" -ForegroundColor Yellow
}

# ============================================================================
# Test 4: Import-IEZoneConfiguration.psm1 (LEGACY - Usually Disabled)
# ============================================================================
Write-TestHeader "Import-IEZoneConfiguration.psm1 (LEGACY)"

Try {
    Import-Module .\Modules\Utilities\Import-IEZoneConfiguration.psm1 -Force
    Write-TestResult -TestName "Module imported" -Result $True
} Catch {
    Write-TestResult -TestName "Module imported" -Result $False -Details $_.Exception.Message
}

If (-not $SkipIEZones) {
    Write-Host "  [WARNING] This will import IE zone registry settings!" -ForegroundColor Yellow
    Write-Host "  [INFO] This is LEGACY functionality (IE is deprecated)" -ForegroundColor Yellow
    Write-Host "  [INFO] Press Ctrl+C within 3 seconds to skip..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    
    Try {
        $Success = Import-DMIEZoneConfiguration -JobType "Logon" -UserInfo $User
        # Note: Returns True if domain is empty (expected for non-domain workstations)
        Write-TestResult -TestName "Import-DMIEZoneConfiguration" -Result $Success
    } Catch {
        Write-TestResult -TestName "Import-DMIEZoneConfiguration" -Result $False -Details $_.Exception.Message
    }
} Else {
    Write-Host "  [SKIP] Import-DMIEZoneConfiguration (SkipIEZones flag)" -ForegroundColor Yellow
}

# ============================================================================
# Summary
# ============================================================================
Export-DMLog

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total Passed: $TestsPassed" -ForegroundColor Green
Write-Host "Total Failed: $TestsFailed" -ForegroundColor $(If ($TestsFailed -gt 0) { "Red" } Else { "Green" })
Write-Host ""

If ($TestsFailed -eq 0) {
    Write-Host "[SUCCESS] All Phase 5 tests passed!" -ForegroundColor Green
} Else {
    Write-Host "[WARNING] Some tests failed. Review details above." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Log file location: $(Get-DMLogPath)" -ForegroundColor Cyan
Write-Host ""

Write-Host "========================================" -ForegroundColor Yellow
Write-Host "POST-TEST RECOMMENDATIONS" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "If PowerCFG was tested:" -ForegroundColor Cyan
Write-Host "  Check current monitor timeout:" -ForegroundColor Gray
Write-Host "    powercfg /q" -ForegroundColor Gray
Write-Host ""
Write-Host "To restore default monitor timeout:" -ForegroundColor Cyan
Write-Host "    powercfg -change -monitor-timeout-ac 20" -ForegroundColor Gray
Write-Host ""

