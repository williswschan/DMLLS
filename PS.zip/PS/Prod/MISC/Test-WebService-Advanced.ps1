<#
.SYNOPSIS
    Advanced Web Service Testing with Multiple Authentication Methods
    
.DESCRIPTION
    Tests various SOAP formats, authentication methods, and service endpoints.
    Compares responses to identify what the backend expects.
    
.EXAMPLE
    .\Test-WebService-Advanced.ps1
#>

[CmdletBinding()]
Param()

Function Write-TestResult {
    Param(
        [String]$Section,
        [String]$Message,
        [String]$Value = "",
        [String]$Color = "White"
    )
    
    If ($Value) {
        Write-Host "[$Section] $Message : " -NoNewline -ForegroundColor Cyan
        Write-Host $Value -ForegroundColor $Color
    } Else {
        Write-Host "[$Section] $Message" -ForegroundColor $Color
    }
}

Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "ADVANCED WEB SERVICE AUTHENTICATION TEST" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

# Get current user info
[String]$Username = $env:USERNAME
[String]$ComputerName = $env:COMPUTERNAME

Write-TestResult "INFO" "Testing User" $Username
Write-TestResult "INFO" "Testing Computer" $ComputerName
Write-TestResult "INFO" "Server" "gdpmappercb.nomura.com"

# Test different authentication combinations
[Array]$TestCases = @(
    @{
        Name = "HTTP Basic Auth + SOAP Header Auth (Current Method)"
        UseBasicAuth = $True
        UseSOAPAuth = $True
        UseWindowsAuth = $False
    },
    @{
        Name = "HTTP Basic Auth Only (No SOAP Header)"
        UseBasicAuth = $True
        UseSOAPAuth = $False
        UseWindowsAuth = $False
    },
    @{
        Name = "SOAP Header Auth Only (No HTTP Basic)"
        UseBasicAuth = $False
        UseSOAPAuth = $True
        UseWindowsAuth = $False
    },
    @{
        Name = "Windows Authentication (Default Credentials)"
        UseBasicAuth = $False
        UseSOAPAuth = $False
        UseWindowsAuth = $True
    },
    @{
        Name = "No Authentication"
        UseBasicAuth = $False
        UseSOAPAuth = $False
        UseWindowsAuth = $False
    }
)

[Int]$TestNumber = 1
ForEach ($TestCase in $TestCases) {
    Write-Host "`n========================================" -ForegroundColor Cyan
    Write-Host "TEST $TestNumber : $($TestCase.Name)" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    
    # Build SOAP Body
    If ($TestCase.UseSOAPAuth) {
        [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$Username</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>CN=TestUser,OU=Users,DC=TEST,DC=COM</tem:userDN>
            <tem:computerDN>CN=TestComputer,OU=Computers,DC=TEST,DC=COM</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@
    } Else {
        [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>CN=TestUser,OU=Users,DC=TEST,DC=COM</tem:userDN>
            <tem:computerDN>CN=TestComputer,OU=Computers,DC=TEST,DC=COM</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@
    }
    
    # Build Headers
    [Hashtable]$Headers = @{
        "Content-Type" = "text/xml; charset=utf-8"
        "SOAPAction" = "http://tempuri.org/GetDriveMappings"
    }
    
    If ($TestCase.UseBasicAuth) {
        $Headers["Authorization"] = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$Username`:placeholder"))
    }
    
    # Build Invoke-WebRequest parameters
    [Hashtable]$RequestParams = @{
        Uri = "http://gdpmappercb.nomura.com/ClassicMapper.asmx"
        Method = "Post"
        Body = $SOAPBody
        Headers = $Headers
        TimeoutSec = 10
        UseBasicParsing = $True
    }
    
    If ($TestCase.UseWindowsAuth) {
        $RequestParams["UseDefaultCredentials"] = $True
    }
    
    Try {
        [Object]$Response = Invoke-WebRequest @RequestParams
        
        Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
        Write-TestResult "SUCCESS" "Content Type" $Response.Headers["Content-Type"] -Color Green
        Write-TestResult "SUCCESS" "Content Length" "$($Response.Content.Length) bytes" -Color Green
        
        # Check if response contains expected elements
        If ($Response.Content -match "GetDriveMappingsResult") {
            Write-TestResult "SUCCESS" "Response contains expected element" "GetDriveMappingsResult found" -Color Green
        } ElseIf ($Response.Content -match "Fault") {
            Write-TestResult "WARNING" "SOAP Fault received" -Color Yellow
        } Else {
            Write-TestResult "WARNING" "Unexpected response format" -Color Yellow
        }
        
        # Show first 500 chars of response
        [String]$Preview = $Response.Content.Substring(0, [Math]::Min(500, $Response.Content.Length))
        Write-Host "`n--- Response Preview ---" -ForegroundColor Green
        Write-Host $Preview -ForegroundColor Gray
        If ($Response.Content.Length -gt 500) {
            Write-Host "... (truncated)" -ForegroundColor Gray
        }
        
    } Catch {
        [Int]$StatusCode = 0
        [String]$StatusDesc = "Unknown"
        
        If ($Null -ne $_.Exception.Response) {
            $StatusCode = [Int]$_.Exception.Response.StatusCode.value__
            $StatusDesc = $_.Exception.Response.StatusDescription
        }
        
        Write-TestResult "FAILED" "HTTP Status" "$StatusCode - $StatusDesc" -Color Red
        
        # Try to get error response
        Try {
            [Object]$ErrorStream = $_.Exception.Response.GetResponseStream()
            [Object]$Reader = New-Object System.IO.StreamReader($ErrorStream)
            [String]$ErrorBody = $Reader.ReadToEnd()
            
            If ($ErrorBody.Length -gt 0) {
                Write-Host "`n--- Error Response ---" -ForegroundColor Red
                [String]$ErrorPreview = $ErrorBody.Substring(0, [Math]::Min(500, $ErrorBody.Length))
                Write-Host $ErrorPreview -ForegroundColor Gray
                If ($ErrorBody.Length -gt 500) {
                    Write-Host "... (truncated)" -ForegroundColor Gray
                }
            }
        } Catch {
            # Could not read error body
        }
    }
    
    $TestNumber++
}

# Summary
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "TEST SUMMARY" -ForegroundColor Magenta
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "`nREVIEW THE RESULTS ABOVE TO IDENTIFY:" -ForegroundColor Yellow
Write-Host "1. Which authentication method returns HTTP 200 (success)" -ForegroundColor White
Write-Host "2. What the SOAP response structure looks like" -ForegroundColor White
Write-Host "3. If the server requires both HTTP and SOAP auth, or just one" -ForegroundColor White
Write-Host "4. Any SOAP Fault messages that explain what's wrong" -ForegroundColor White
Write-Host "`n"

