<#
.SYNOPSIS
    Detailed Web Service Communication Diagnostic Script
    
.DESCRIPTION
    Tests SOAP web service communication with extensive logging to diagnose issues.
    Tests both Mapper and Inventory services with step-by-step validation.
    
.PARAMETER ServiceType
    Type of service to test: Mapper, Inventory, or Both (default)
    
.PARAMETER Username
    Username for authentication (defaults to current user)
    
.PARAMETER UserDN
    User Distinguished Name (auto-detected if not provided)
    
.PARAMETER ComputerDN
    Computer Distinguished Name (auto-detected if not provided)
    
.EXAMPLE
    .\Test-WebService.ps1
    .\Test-WebService.ps1 -ServiceType Mapper
    .\Test-WebService.ps1 -Username "WILLIS.CHAN" -UserDN "CN=Willis Chan,OU=Individual,OU=Users,OU=HK,DC=MYMSNGROUP,DC=COM"
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$False)]
    [ValidateSet("Mapper", "Inventory", "Both")]
    [String]$ServiceType = "Both",
    
    [Parameter(Mandatory=$False)]
    [String]$Username = $env:USERNAME,
    
    [Parameter(Mandatory=$False)]
    [String]$UserDN = "",
    
    [Parameter(Mandatory=$False)]
    [String]$ComputerDN = ""
)

Function Write-TestResult {
    Param(
        [String]$Section,
        [String]$Message,
        [String]$Value = "",
        [String]$Color = "White"
    )
    
    If ($Value) {
        Write-Host "[$Section] $Message : " -NoNewline -ForegroundColor Cyan
        Write-Host $Value -ForegroundColor $Color
    } Else {
        Write-Host "[$Section] $Message" -ForegroundColor $Color
    }
}

Function Show-XMLFormatted {
    Param([String]$XML)
    
    Try {
        [Xml]$XmlDoc = $XML
        [System.IO.StringWriter]$StringWriter = New-Object System.IO.StringWriter
        [System.Xml.XmlTextWriter]$XmlWriter = New-Object System.Xml.XmlTextWriter($StringWriter)
        $XmlWriter.Formatting = "Indented"
        $XmlWriter.Indentation = 2
        $XmlDoc.WriteContentTo($XmlWriter)
        $XmlWriter.Flush()
        $StringWriter.Flush()
        Return $StringWriter.ToString()
    } Catch {
        Return $XML
    }
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "WEB SERVICE DIAGNOSTIC TEST" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

# Step 1: Get DNs if not provided
If ([String]::IsNullOrEmpty($UserDN) -or [String]::IsNullOrEmpty($ComputerDN)) {
    Write-TestResult "STEP 1" "Auto-detecting Distinguished Names" -Color Yellow
    
    Try {
        Add-Type -AssemblyName System.DirectoryServices
        
        If ([String]::IsNullOrEmpty($UserDN)) {
            [Object]$UserSearcher = New-Object System.DirectoryServices.DirectorySearcher
            $UserSearcher.Filter = "(&(objectClass=user)(samAccountName=$Username))"
            [Void]$UserSearcher.PropertiesToLoad.Add("distinguishedName")
            [Object]$UserResult = $UserSearcher.FindOne()
            
            If ($UserResult) {
                $UserDN = $UserResult.Properties["distinguishedName"][0]
                Write-TestResult "SUCCESS" "User DN" $UserDN -Color Green
            } Else {
                Write-TestResult "ERROR" "User not found in AD" -Color Red
                Exit 1
            }
        }
        
        If ([String]::IsNullOrEmpty($ComputerDN)) {
            [Object]$ComputerSearcher = New-Object System.DirectoryServices.DirectorySearcher
            $ComputerSearcher.Filter = "(&(objectClass=computer)(name=$env:COMPUTERNAME))"
            [Void]$ComputerSearcher.PropertiesToLoad.Add("distinguishedName")
            [Object]$ComputerResult = $ComputerSearcher.FindOne()
            
            If ($ComputerResult) {
                $ComputerDN = $ComputerResult.Properties["distinguishedName"][0]
                Write-TestResult "SUCCESS" "Computer DN" $ComputerDN -Color Green
            } Else {
                Write-TestResult "WARNING" "Computer not found in AD" "Using empty DN" -Color Yellow
                $ComputerDN = ""
            }
        }
    } Catch {
        Write-TestResult "ERROR" "Failed to get DNs" $_.Exception.Message -Color Red
        Exit 1
    }
}

# Step 2: Test Basic Connectivity
Write-Host "`n" -NoNewline
Write-TestResult "STEP 2" "Testing Basic Web Service Connectivity" -Color Yellow

[String]$ServerURL = "http://gdpmappercb.nomura.com"
Write-TestResult "INFO" "Server URL" $ServerURL

Try {
    [Object]$Response = Invoke-WebRequest -Uri $ServerURL -Method Get -UseBasicParsing -TimeoutSec 10
    Write-TestResult "SUCCESS" "Server reachable" "Status: $($Response.StatusCode)" -Color Green
} Catch {
    Write-TestResult "ERROR" "Server not reachable" $_.Exception.Message -Color Red
    Write-TestResult "INFO" "Check DNS resolution: nslookup gdpmappercb.nomura.com" -Color Yellow
    Exit 1
}

# Step 3: Test Mapper Service - GetDriveMappings
If ($ServiceType -eq "Mapper" -or $ServiceType -eq "Both") {
    Write-Host "`n" -NoNewline
    Write-TestResult "STEP 3" "Testing Mapper Service - GetDriveMappings" -Color Yellow
    
    [String]$MapperURL = "http://gdpmappercb.nomura.com/ClassicMapper.asmx"
    Write-TestResult "INFO" "Service URL" $MapperURL
    Write-TestResult "INFO" "User DN" $UserDN
    Write-TestResult "INFO" "Computer DN" $ComputerDN
    
    # Build SOAP request
    [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$Username</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>$UserDN</tem:userDN>
            <tem:computerDN>$ComputerDN</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@
    
    Write-Host "`n--- SOAP Request ---" -ForegroundColor Cyan
    Write-Host (Show-XMLFormatted -XML $SOAPBody) -ForegroundColor Gray
    
    # Build headers
    [Hashtable]$Headers = @{
        "Content-Type" = "text/xml; charset=utf-8"
        "SOAPAction" = "http://tempuri.org/GetDriveMappings"
        "Authorization" = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Username + ":placeholder"))
    }
    
    Write-Host "`n--- HTTP Headers ---" -ForegroundColor Cyan
    $Headers.GetEnumerator() | ForEach-Object {
        If ($_.Key -eq "Authorization") {
            Write-Host "  $($_.Key): Basic ***REDACTED***" -ForegroundColor Gray
        } Else {
            Write-Host "  $($_.Key): $($_.Value)" -ForegroundColor Gray
        }
    }
    
    Try {
        Write-Host "`n--- Sending Request ---" -ForegroundColor Cyan
        [Object]$Response = Invoke-WebRequest -Uri $MapperURL -Method Post -Body $SOAPBody -Headers $Headers -TimeoutSec 10 -UseBasicParsing
        
        Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
        Write-TestResult "SUCCESS" "Content Length" "$($Response.Content.Length) bytes" -Color Green
        
        Write-Host "`n--- SOAP Response ---" -ForegroundColor Cyan
        Write-Host (Show-XMLFormatted -XML $Response.Content) -ForegroundColor Gray
        
        # Parse response
        Try {
            [Xml]$ResponseXML = $Response.Content
            [Object]$Drives = $ResponseXML.SelectNodes("//*[local-name()='Drive']")
            
            Write-Host "`n--- Parsed Results ---" -ForegroundColor Cyan
            Write-TestResult "INFO" "Drive Mappings Found" $Drives.Count -Color $(If ($Drives.Count -gt 0) { "Green" } Else { "Yellow" })
            
            If ($Drives.Count -gt 0) {
                ForEach ($Drive in $Drives) {
                    [String]$Letter = $Drive.SelectSingleNode("*[local-name()='DriveLetter']").InnerText
                    [String]$Path = $Drive.SelectSingleNode("*[local-name()='UncPath']").InnerText
                    [String]$Desc = $Drive.SelectSingleNode("*[local-name()='Description']").InnerText
                    Write-Host "  Drive $Letter : $Path [$Desc]" -ForegroundColor Green
                }
            }
        } Catch {
            Write-TestResult "ERROR" "Failed to parse XML response" $_.Exception.Message -Color Red
        }
        
    } Catch {
        Write-TestResult "ERROR" "HTTP Request Failed" -Color Red
        Write-TestResult "ERROR" "Status Code" $_.Exception.Response.StatusCode.value__ -Color Red
        Write-TestResult "ERROR" "Status Description" $_.Exception.Response.StatusDescription -Color Red
        Write-TestResult "ERROR" "Exception" $_.Exception.Message -Color Red
        
        # Try to get response body
        Try {
            [Object]$ErrorStream = $_.Exception.Response.GetResponseStream()
            [Object]$Reader = New-Object System.IO.StreamReader($ErrorStream)
            [String]$ErrorBody = $Reader.ReadToEnd()
            
            Write-Host "`n--- Error Response Body ---" -ForegroundColor Red
            Write-Host $ErrorBody -ForegroundColor Gray
        } Catch {
            Write-TestResult "INFO" "Could not read error response body" -Color Yellow
        }
    }
}

# Step 4: Test Inventory Service - InsertLogonInventory
If ($ServiceType -eq "Inventory" -or $ServiceType -eq "Both") {
    Write-Host "`n" -NoNewline
    Write-TestResult "STEP 4" "Testing Inventory Service - InsertLogonInventory" -Color Yellow
    
    [String]$InventoryURL = "http://gdpmappercb.nomura.com/ClassicInventory.asmx"
    Write-TestResult "INFO" "Service URL" $InventoryURL
    
    # Build SOAP request
    [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$Username</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:InsertLogonInventory>
            <tem:userDN>$UserDN</tem:userDN>
            <tem:computerDN>$ComputerDN</tem:computerDN>
            <tem:siteName></tem:siteName>
            <tem:city>HK</tem:city>
        </tem:InsertLogonInventory>
    </soap:Body>
</soap:Envelope>
"@
    
    Write-Host "`n--- SOAP Request ---" -ForegroundColor Cyan
    Write-Host (Show-XMLFormatted -XML $SOAPBody) -ForegroundColor Gray
    
    # Build headers
    [Hashtable]$Headers = @{
        "Content-Type" = "text/xml; charset=utf-8"
        "SOAPAction" = "http://tempuri.org/InsertLogonInventory"
        "Authorization" = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Username + ":placeholder"))
    }
    
    Try {
        Write-Host "`n--- Sending Request ---" -ForegroundColor Cyan
        [Object]$Response = Invoke-WebRequest -Uri $InventoryURL -Method Post -Body $SOAPBody -Headers $Headers -TimeoutSec 10 -UseBasicParsing
        
        Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
        Write-TestResult "SUCCESS" "Content Length" "$($Response.Content.Length) bytes" -Color Green
        
        Write-Host "`n--- SOAP Response ---" -ForegroundColor Cyan
        Write-Host (Show-XMLFormatted -XML $Response.Content) -ForegroundColor Gray
        
        # Parse response
        Try {
            [Xml]$ResponseXML = $Response.Content
            [Object]$Result = $ResponseXML.SelectSingleNode("//*[local-name()='InsertLogonInventoryResult']")
            
            If ($Result) {
                Write-TestResult "SUCCESS" "Inventory Insert Result" $Result.InnerText -Color Green
            }
        } Catch {
            Write-TestResult "ERROR" "Failed to parse XML response" $_.Exception.Message -Color Red
        }
        
    } Catch {
        Write-TestResult "ERROR" "HTTP Request Failed" -Color Red
        Write-TestResult "ERROR" "Status Code" $_.Exception.Response.StatusCode.value__ -Color Red
        Write-TestResult "ERROR" "Status Description" $_.Exception.Response.StatusDescription -Color Red
        Write-TestResult "ERROR" "Exception" $_.Exception.Message -Color Red
        
        # Try to get response body
        Try {
            [Object]$ErrorStream = $_.Exception.Response.GetResponseStream()
            [Object]$Reader = New-Object System.IO.StreamReader($ErrorStream)
            [String]$ErrorBody = $Reader.ReadToEnd()
            
            Write-Host "`n--- Error Response Body ---" -ForegroundColor Red
            Write-Host $ErrorBody -ForegroundColor Gray
            
            # Try to parse error as XML
            Try {
                [Xml]$ErrorXML = $ErrorBody
                Write-Host "`n--- Parsed Error (Formatted) ---" -ForegroundColor Red
                Write-Host (Show-XMLFormatted -XML $ErrorBody) -ForegroundColor Gray
            } Catch {
                # Not XML, just text
            }
        } Catch {
            Write-TestResult "INFO" "Could not read error response body" -Color Yellow
        }
    }
}

# Step 5: Test Alternative SOAP Format (Without Header Auth)
Write-Host "`n" -NoNewline
Write-TestResult "STEP 5" "Testing Alternative Format (No SOAP Header Auth)" -Color Yellow

[String]$AlternativeSOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>$UserDN</tem:userDN>
            <tem:computerDN>$ComputerDN</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@

Write-Host "`n--- Alternative SOAP Request (HTTP Auth Only) ---" -ForegroundColor Cyan
Write-Host (Show-XMLFormatted -XML $AlternativeSOAPBody) -ForegroundColor Gray

[Hashtable]$AltHeaders = @{
    "Content-Type" = "text/xml; charset=utf-8"
    "SOAPAction" = "http://tempuri.org/GetDriveMappings"
    "Authorization" = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Username + ":placeholder"))
}

Try {
    Write-Host "`n--- Sending Alternative Request ---" -ForegroundColor Cyan
    [Object]$AltResponse = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/ClassicMapper.asmx" -Method Post -Body $AlternativeSOAPBody -Headers $AltHeaders -TimeoutSec 10 -UseBasicParsing
    
    Write-TestResult "SUCCESS" "HTTP Status" $AltResponse.StatusCode -Color Green
    
    Write-Host "`n--- Alternative Response ---" -ForegroundColor Cyan
    Write-Host (Show-XMLFormatted -XML $AltResponse.Content) -ForegroundColor Gray
    
} Catch {
    Write-TestResult "ERROR" "Alternative format also failed" -Color Red
    Write-TestResult "ERROR" "Status" "$($_.Exception.Response.StatusCode.value__) - $($_.Exception.Response.StatusDescription)" -Color Red
}

# Step 6: Test with PSCredential
Write-Host "`n" -NoNewline
Write-TestResult "STEP 6" "Testing with PSCredential (Windows Auth)" -Color Yellow

Try {
    # Try without explicit auth (use Windows auth)
    [Hashtable]$WinAuthHeaders = @{
        "Content-Type" = "text/xml; charset=utf-8"
        "SOAPAction" = "http://tempuri.org/GetDriveMappings"
    }
    
    Write-Host "`n--- Trying Windows Authentication ---" -ForegroundColor Cyan
    [Object]$WinResponse = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/ClassicMapper.asmx" -Method Post -Body $AlternativeSOAPBody -Headers $WinAuthHeaders -TimeoutSec 10 -UseBasicParsing -UseDefaultCredentials
    
    Write-TestResult "SUCCESS" "HTTP Status (Windows Auth)" $WinResponse.StatusCode -Color Green
    
    Write-Host "`n--- Windows Auth Response ---" -ForegroundColor Cyan
    Write-Host (Show-XMLFormatted -XML $WinResponse.Content) -ForegroundColor Gray
    
} Catch {
    Write-TestResult "ERROR" "Windows Auth failed" -Color Red
    Write-TestResult "ERROR" "Status" "$($_.Exception.Response.StatusCode.value__) - $($_.Exception.Response.StatusDescription)" -Color Red
}

# Summary
Write-Host "`n========================================" -ForegroundColor Green
Write-Host "DIAGNOSTIC COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "`nNEXT STEPS:" -ForegroundColor Yellow
Write-Host "1. Check which format returned HTTP 200" -ForegroundColor White
Write-Host "2. Review the SOAP response XML structure" -ForegroundColor White
Write-Host "3. Verify the XPath used to parse responses" -ForegroundColor White
Write-Host "4. Check if authentication is working" -ForegroundColor White
Write-Host "`n"

