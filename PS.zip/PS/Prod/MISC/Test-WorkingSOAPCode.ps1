<#
.SYNOPSIS
    Test Using the User-Provided Working PowerShell Code
    
.DESCRIPTION
    This script uses the EXACT SOAP format from the working PowerShell code
    you provided earlier to verify it works, then compares with our implementation.
    
.NOTES
    This will help identify any subtle differences between working and non-working code.
    
.EXAMPLE
    .\Test-WorkingSOAPCode.ps1
#>

[CmdletBinding()]
Param()

Function Write-TestResult {
    Param(
        [String]$Section,
        [String]$Message,
        [String]$Value = "",
        [String]$Color = "White"
    )
    
    If ($Value) {
        Write-Host "[$Section] $Message : " -NoNewline -ForegroundColor Cyan
        Write-Host $Value -ForegroundColor $Color
    } Else {
        Write-Host "[$Section] $Message" -ForegroundColor $Color
    }
}

Write-Host "`n========================================" -ForegroundColor Green
Write-Host "TESTING USER-PROVIDED WORKING CODE" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

# Get user info
[String]$Username = $env:USERNAME
Write-TestResult "INFO" "Testing as user" $Username

# Get DNs
Try {
    Add-Type -AssemblyName System.DirectoryServices
    
    [Object]$UserSearcher = New-Object System.DirectoryServices.DirectorySearcher
    $UserSearcher.Filter = "(&(objectClass=user)(samAccountName=$Username))"
    [Void]$UserSearcher.PropertiesToLoad.Add("distinguishedName")
    [Object]$UserResult = $UserSearcher.FindOne()
    
    [String]$UserDN = ""
    If ($UserResult) {
        $UserDN = $UserResult.Properties["distinguishedName"][0]
        Write-TestResult "SUCCESS" "User DN" $UserDN -Color Green
    } Else {
        Write-TestResult "WARNING" "User DN not found" "Using test DN" -Color Yellow
        $UserDN = "CN=TestUser,OU=Users,DC=TEST,DC=COM"
    }
    
    [Object]$CompSearcher = New-Object System.DirectoryServices.DirectorySearcher
    $CompSearcher.Filter = "(&(objectClass=computer)(name=$env:COMPUTERNAME))"
    [Void]$CompSearcher.PropertiesToLoad.Add("distinguishedName")
    [Object]$CompResult = $CompSearcher.FindOne()
    
    [String]$ComputerDN = ""
    If ($CompResult) {
        $ComputerDN = $CompResult.Properties["distinguishedName"][0]
        Write-TestResult "SUCCESS" "Computer DN" $ComputerDN -Color Green
    } Else {
        Write-TestResult "WARNING" "Computer DN not found" "Using test DN" -Color Yellow
        $ComputerDN = "CN=TestPC,OU=Computers,DC=TEST,DC=COM"
    }
} Catch {
    Write-TestResult "ERROR" "Failed to get DNs" $_.Exception.Message -Color Red
    $UserDN = "CN=TestUser,OU=Users,DC=TEST,DC=COM"
    $ComputerDN = "CN=TestPC,OU=Computers,DC=TEST,DC=COM"
}

# Test 1: Exact format from working code
Write-Host "`n" -NoNewline
Write-TestResult "TEST 1" "Using EXACT Format from Working Code" -Color Yellow

Write-Host @"

NOTE: This uses the EXACT code structure you provided that works in your environment.
If this test SUCCEEDS, we know the format is correct.
If this test FAILS, there might be network/DNS issues.

"@ -ForegroundColor Cyan

[String]$WorkingSOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$Username</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:GetDriveMappings>
            <tem:userDN>$UserDN</tem:userDN>
            <tem:computerDN>$ComputerDN</tem:computerDN>
        </tem:GetDriveMappings>
    </soap:Body>
</soap:Envelope>
"@

[Hashtable]$WorkingHeaders = @{
    "Content-Type" = "text/xml; charset=utf-8"
    "SOAPAction" = "http://tempuri.org/GetDriveMappings"
    "Authorization" = "Basic " + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Username + ":placeholder"))
}

Write-Host "Request Details:" -ForegroundColor White
Write-Host "  URL: http://gdpmappercb.nomura.com/ClassicMapper.asmx" -ForegroundColor Gray
Write-Host "  Method: POST" -ForegroundColor Gray
Write-Host "  Headers:" -ForegroundColor Gray
$WorkingHeaders.GetEnumerator() | ForEach-Object {
    If ($_.Key -eq "Authorization") {
        Write-Host "    $($_.Key): Basic ***" -ForegroundColor Gray
    } Else {
        Write-Host "    $($_.Key): $($_.Value)" -ForegroundColor Gray
    }
}

Try {
    Write-Host "`nSending request..." -ForegroundColor White
    [Object]$Response = Invoke-WebRequest -Uri "http://gdpmappercb.nomura.com/ClassicMapper.asmx" -Method Post -Body $WorkingSOAPBody -Headers $WorkingHeaders -TimeoutSec 10 -UseBasicParsing
    
    Write-Host "`n" -NoNewline
    Write-TestResult "SUCCESS" "HTTP Status" $Response.StatusCode -Color Green
    Write-TestResult "SUCCESS" "Content Type" $Response.Headers["Content-Type"] -Color Green
    Write-TestResult "SUCCESS" "Content Length" "$($Response.Content.Length) bytes" -Color Green
    
    Write-Host "`n--- SOAP Response (First 1000 chars) ---" -ForegroundColor Green
    [String]$Preview = $Response.Content.Substring(0, [Math]::Min(1000, $Response.Content.Length))
    Write-Host $Preview -ForegroundColor Gray
    
    If ($Response.Content.Length -gt 1000) {
        Write-Host "... (response truncated, full length: $($Response.Content.Length) bytes)" -ForegroundColor Gray
    }
    
    # Try to parse and extract drives
    Write-Host "`n--- Parsing Response ---" -ForegroundColor Green
    Try {
        [Xml]$ResponseXML = $Response.Content
        
        # Show namespaces
        Write-Host "`nNamespaces in response:" -ForegroundColor White
        If ($ResponseXML.DocumentElement.NamespaceURI) {
            Write-Host "  Default: $($ResponseXML.DocumentElement.NamespaceURI)" -ForegroundColor Gray
        }
        $ResponseXML.DocumentElement.Attributes | Where-Object { $_.Name -like "xmlns:*" } | ForEach-Object {
            Write-Host "  $($_.Name): $($_.Value)" -ForegroundColor Gray
        }
        
        # Try different XPath queries
        Write-Host "`nTrying different XPath queries:" -ForegroundColor White
        
        [Array]$XPathQueries = @(
            "//*[local-name()='GetDriveMappingsResult']",
            "//*[local-name()='Drive']",
            "//*[local-name()='Drives']/*[local-name()='Drive']",
            "//Drive",
            "//GetDriveMappingsResult"
        )
        
        ForEach ($XPath in $XPathQueries) {
            [Object]$Nodes = $ResponseXML.SelectNodes($XPath)
            If ($Nodes.Count -gt 0) {
                Write-Host "  $XPath : " -NoNewline -ForegroundColor Gray
                Write-Host "Found $($Nodes.Count) node(s)" -ForegroundColor Green
            } Else {
                Write-Host "  $XPath : " -NoNewline -ForegroundColor Gray
                Write-Host "No matches" -ForegroundColor DarkGray
            }
        }
        
    } Catch {
        Write-TestResult "ERROR" "Failed to parse response" $_.Exception.Message -Color Red
    }
    
} Catch {
    Write-Host "`n" -NoNewline
    Write-TestResult "FAILED" "HTTP Request Failed" -Color Red
    
    [Int]$StatusCode = 0
    [String]$StatusDesc = "Unknown"
    
    If ($Null -ne $_.Exception.Response) {
        $StatusCode = [Int]$_.Exception.Response.StatusCode.value__
        $StatusDesc = $_.Exception.Response.StatusDescription
        
        Write-TestResult "ERROR" "HTTP Status" "$StatusCode - $StatusDesc" -Color Red
        
        # Get error response body
        Try {
            [Object]$ErrorStream = $_.Exception.Response.GetResponseStream()
            [Object]$Reader = New-Object System.IO.StreamReader($ErrorStream)
            [String]$ErrorBody = $Reader.ReadToEnd()
            
            Write-Host "`n--- Error Response Body ---" -ForegroundColor Red
            Write-Host $ErrorBody -ForegroundColor Gray
            
            # If it's XML, try to parse it
            Try {
                [Xml]$ErrorXML = $ErrorBody
                [Object]$FaultString = $ErrorXML.SelectSingleNode("//*[local-name()='faultstring']")
                [Object]$FaultDetail = $ErrorXML.SelectSingleNode("//*[local-name()='detail']")
                
                If ($FaultString) {
                    Write-Host "`n--- SOAP Fault Details ---" -ForegroundColor Red
                    Write-Host "Fault String: $($FaultString.InnerText)" -ForegroundColor Yellow
                }
                
                If ($FaultDetail) {
                    Write-Host "Fault Detail: $($FaultDetail.InnerText)" -ForegroundColor Yellow
                }
            } Catch {
                # Not a SOAP fault
            }
            
        } Catch {
            Write-TestResult "INFO" "Could not read error response body" -Color Yellow
        }
    } Else {
        Write-TestResult "ERROR" "Exception Message" $_.Exception.Message -Color Red
    }
}

# Summary
Write-Host "`n========================================" -ForegroundColor Magenta
Write-Host "ANALYSIS GUIDE" -ForegroundColor Magenta
Write-Host "========================================`n" -ForegroundColor Magenta

Write-Host "If TEST 1 SUCCEEDED (HTTP 200):" -ForegroundColor Green
Write-Host "  - Our current format is CORRECT" -ForegroundColor White
Write-Host "  - Review the XPath queries that found nodes" -ForegroundColor White
Write-Host "  - Update parsing code in DMMapperService.psm1" -ForegroundColor White

Write-Host "`nIf TEST 1 FAILED with 400 Bad Request:" -ForegroundColor Red
Write-Host "  - Review error response for clues" -ForegroundColor White
Write-Host "  - Check parameter names (case sensitive?)" -ForegroundColor White
Write-Host "  - Try different namespace prefixes" -ForegroundColor White
Write-Host "  - Compare with WSDL at: http://gdpmappercb.nomura.com/ClassicMapper.asmx?WSDL" -ForegroundColor White

Write-Host "`nIf TEST 1 FAILED with 401 Unauthorized:" -ForegroundColor Red
Write-Host "  - Authentication method incorrect" -ForegroundColor White
Write-Host "  - Try Test-WebService-Advanced.ps1 to test different auth methods" -ForegroundColor White

Write-Host "`nIf TEST 1 FAILED with 500 Internal Server Error:" -ForegroundColor Red
Write-Host "  - Server received request but processing failed" -ForegroundColor White
Write-Host "  - Check error response for SOAP fault details" -ForegroundColor White
Write-Host "  - May be issue with DN format or database backend" -ForegroundColor White

Write-Host "`n"

