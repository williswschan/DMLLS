<#
.SYNOPSIS
    Desktop Management Computer Information Module
    
.DESCRIPTION
    Collects comprehensive computer information including AD properties, groups, site, IP addresses.
    Replacement for VBScript ComputerObject class.
    
.NOTES
    Version: 2.0.0
    Author: Desktop Management Team
    Replacement for: VB/Source/Main/Computer.vbs
#>

# Import required modules
Using Module .\DMCommon.psm1

<#
.SYNOPSIS
    Gets comprehensive computer information.
    
.DESCRIPTION
    Collects all computer properties needed for Desktop Management operations.
    Returns PSCustomObject with computer details.
    
.OUTPUTS
    PSCustomObject with computer properties
    
.EXAMPLE
    $Computer = Get-DMComputerInfo
    Write-Host "Computer: $($Computer.Name) in site $($Computer.Site)"
#>
Function Get-DMComputerInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        # Get basic computer name
        [String]$Name = $env:COMPUTERNAME
        
        # Get AD information using .NET DirectoryServices
        [Object]$ADInfo = Get-DMComputerADInfo
        
        # Check if we're domain-joined using robust detection
        If (-not $ADInfo.IsDomainJoined) {
            Write-Verbose "Computer is not domain-joined or AD information unavailable"
            
            # Return minimal info for non-domain computers
            Return [PSCustomObject]@{
                PSTypeName = 'DM.ComputerInfo'
                Name = $Name
                DistinguishedName = ""
                Domain = $env:USERDOMAIN
                ShortDomain = $env:USERDOMAIN
                Site = ""
                Groups = @()
                CityCode = "unknown"
                OUMapping = ""
                IPAddresses = Get-DMIPAddresses
                OSCaption = (Get-DMOSInfo).Caption
                IsDesktop = (Get-DMOSInfo).IsDesktop
                IsServer = (Get-DMOSInfo).IsServer
                DomainRole = (Get-DMOSInfo).DomainRole
                IsVPNConnected = Test-DMVPNConnection
            }
        }
        
        # Get group memberships (only if we have a valid DN)
        [Array]$Groups = @()
        If (-not [String]::IsNullOrEmpty($ADInfo.DistinguishedName)) {
            $Groups = Get-DMComputerGroups -DistinguishedName $ADInfo.DistinguishedName
        }
        
        # Extract city code from DN (only if we have a valid DN)
        [String]$CityCode = "unknown"
        If (-not [String]::IsNullOrEmpty($ADInfo.DistinguishedName)) {
            $CityCode = Get-DMCityCode -DistinguishedName $ADInfo.DistinguishedName -IsComputer $True
        }
        
        # Get OU mapping (only if we have a valid DN)
        [String]$OUMapping = ""
        If (-not [String]::IsNullOrEmpty($ADInfo.DistinguishedName)) {
            $OUMapping = Get-DMOUPath -DistinguishedName $ADInfo.DistinguishedName
        }
        
        # Get IP addresses
        [Array]$IPAddresses = Get-DMIPAddresses
        
        # Get OS information
        [Object]$OSInfo = Get-DMOSInfo
        
        # Check if VPN connected
        [Boolean]$IsVPNConnected = Test-DMVPNConnection
        
        # Build computer info object
        [PSCustomObject]$ComputerInfo = [PSCustomObject]@{
            PSTypeName = 'DM.ComputerInfo'
            Name = $Name
            DistinguishedName = $ADInfo.DistinguishedName
            Domain = $ADInfo.DomainDNS
            ShortDomain = $ADInfo.DomainShort
            Site = $ADInfo.Site
            Groups = $Groups
            CityCode = $CityCode
            OUMapping = $OUMapping
            IPAddresses = $IPAddresses
            OSCaption = $OSInfo.Caption
            IsDesktop = $OSInfo.IsDesktop
            IsServer = $OSInfo.IsServer
            DomainRole = $OSInfo.DomainRole
            IsVPNConnected = $IsVPNConnected
        }
        
        Return $ComputerInfo
    }
    Catch {
        Write-Error "Failed to get computer information: $($_.Exception.Message)"
        Return $Null
    }
}

<#
.SYNOPSIS
    Gets Active Directory information for the computer.
    
.DESCRIPTION
    Uses .NET DirectoryServices to retrieve AD properties.
    
.OUTPUTS
    PSCustomObject with DN, Domain, Site
    
.EXAMPLE
    $ADInfo = Get-DMComputerADInfo
#>
Function Get-DMComputerADInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        # Load .NET DirectoryServices
        Add-Type -AssemblyName System.DirectoryServices
        
        # Get current domain information
        [Object]$Domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        [String]$DomainDNS = $Domain.Name
        [String]$DomainShort = $Domain.Name.Split('.')[0]
        
        # Create DirectorySearcher for computer
        [Object]$Searcher = New-Object System.DirectoryServices.DirectorySearcher
        $Searcher.Filter = "(&(objectClass=computer)(name=$env:COMPUTERNAME))"
        $Searcher.PropertiesToLoad.AddRange(@("distinguishedName", "location", "description"))
        
        [Object]$ComputerResult = $Searcher.FindOne()
        
        If ($ComputerResult) {
            [String]$ComputerDN = $ComputerResult.Properties["distinguishedName"][0]
            
            # Get site information using subnet-based method (Method A)
            [String]$Site = ""
            Try {
                # Get computer's IP addresses
                [Array]$ComputerIPs = Get-DMIPAddresses
                
                # Query Sites container for subnets
                [Object]$SubnetSearcher = New-Object System.DirectoryServices.DirectorySearcher
                $SubnetSearcher.Filter = "(&(objectClass=subnet)(objectCategory=Subnet))"
                $SubnetSearcher.SearchRoot = "LDAP://CN=Subnets,CN=Sites,CN=Configuration,$($Domain.GetDirectoryEntry().distinguishedName[0])"
                $SubnetSearcher.PropertiesToLoad.AddRange(@("cn", "siteObject"))
                
                [Object]$SubnetResults = $SubnetSearcher.FindAll()
                
                # Check each computer IP against subnet ranges
                ForEach ($IP in $ComputerIPs) {
                    # Skip IPv6 addresses (they start with fe80::, 2001:, etc.)
                    If ($IP -notmatch "^fe80::" -and $IP -notmatch "^2001:" -and $IP -notmatch "^::1$") {
                        # Convert IP to long integer for range checking
                        Try {
                            [IPAddress]$IPAddr = $IP
                            [UInt32]$IPLong = [BitConverter]::ToUInt32($IPAddr.GetAddressBytes(), 0)
                            
                            ForEach ($SubnetResult in $SubnetResults) {
                                [String]$SubnetCIDR = $SubnetResult.Properties["cn"][0]  # e.g., "192.168.1.0/24"
                                
                                # Parse subnet (e.g., "192.168.1.0/24" -> IP: 192.168.1.0, Mask: /24)
                                If ($SubnetCIDR -match "^(\d+\.\d+\.\d+\.\d+)/(\d+)$") {
                                    [String]$SubnetIP = $Matches[1]
                                    [Int]$SubnetMask = [Int]$Matches[2]
                                    
                                    # Convert subnet IP to long integer
                                    [IPAddress]$SubnetAddr = $SubnetIP
                                    [UInt32]$SubnetLong = [BitConverter]::ToUInt32($SubnetAddr.GetAddressBytes(), 0)
                                    
                                    # Calculate network mask
                                    [UInt32]$Mask = [UInt32]::MaxValue -shl (32 - $SubnetMask)
                                    
                                    # Check if IP is in this subnet range
                                    If (($IPLong -band $Mask) -eq ($SubnetLong -band $Mask)) {
                                        # Get site name from siteObject DN
                                        [String]$SiteDN = $SubnetResult.Properties["siteObject"][0]
                                        $Site = ($SiteDN -split ",")[0] -replace "CN=", ""
                                        Write-Verbose "Found site '$Site' for IP '$IP' in subnet '$SubnetCIDR'"
                                        Break
                                    }
                                }
                            }
                            
                            # If we found a site, stop checking other IPs
                            If (-not [String]::IsNullOrEmpty($Site)) {
                                Break
                            }
                        } Catch {
                            Write-Verbose "Error processing IP '$IP': $($_.Exception.Message)"
                        }
                    }
                }
                
                # Fallback: If no subnet match found, try to get site from computer object location
                If ([String]::IsNullOrEmpty($Site)) {
                    If ($ComputerResult.Properties["location"].Count -gt 0) {
                        $Site = $ComputerResult.Properties["location"][0]
                        Write-Verbose "Using computer location attribute for site: '$Site'"
                    }
                }
                
            } Catch {
                Write-Verbose "Failed to retrieve site using subnet method: $($_.Exception.Message)"
                
                # Final fallback: Try domain controller location
                Try {
                    [Object]$DCSearcher = New-Object System.DirectoryServices.DirectorySearcher
                    $DCSearcher.Filter = "(&(objectClass=computer)(userAccountControl:1.2.840.113556.1.4.803:=8192))"
                    $DCSearcher.PropertiesToLoad.Add("location")
                    [Object]$DCResult = $DCSearcher.FindOne()
                    If ($DCResult -and $DCResult.Properties["location"].Count -gt 0) {
                        $Site = $DCResult.Properties["location"][0]
                        Write-Verbose "Using domain controller location for site: '$Site'"
                    }
                } Catch {
                    Write-Verbose "Failed to get site from domain controller: $($_.Exception.Message)"
                }
            }
            
            Return [PSCustomObject]@{
                DistinguishedName = $ComputerDN
                DomainDNS = $DomainDNS
                DomainShort = $DomainShort
                Site = $Site
                IsDomainJoined = $True
            }
        } Else {
            Write-Verbose "Computer not found in Active Directory"
            Return [PSCustomObject]@{
                DistinguishedName = ""
                DomainDNS = $DomainDNS
                DomainShort = $DomainShort
                Site = ""
                IsDomainJoined = $False
            }
        }
    }
    Catch {
        Write-Verbose "Failed to get AD computer information using .NET DirectoryServices: $($_.Exception.Message)"
        
        # Fallback to basic domain detection
        Try {
            [Object]$ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
            If ($ComputerSystem -and $ComputerSystem.PartOfDomain) {
                Return [PSCustomObject]@{
                    DistinguishedName = ""
                    DomainDNS = $ComputerSystem.Domain
                    DomainShort = $ComputerSystem.Domain.Split('.')[0]
                    Site = ""
                    IsDomainJoined = $True
                }
            }
        } Catch {
            Write-Verbose "Fallback domain detection also failed: $($_.Exception.Message)"
        }
        
        # Final fallback to environment variables
        [String]$DomainDNS = $env:USERDNSDOMAIN
        [String]$DomainShort = $env:USERDOMAIN
        [Boolean]$IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN "" -DomainDNS $DomainDNS -DomainShort $DomainShort
        
        Return [PSCustomObject]@{
            DistinguishedName = ""
            DomainDNS = $DomainDNS
            DomainShort = $DomainShort
            Site = ""
            IsDomainJoined = $IsDomainJoined
        }
    }
}

<#
.SYNOPSIS
    Tests if computer is domain-joined using multiple detection methods.
    
.DESCRIPTION
    Uses multiple methods to determine if computer is domain-joined:
    1. .NET DirectoryServices results
    2. Environment variables
    3. WMI ComputerSystem.DomainRole
    4. Registry domain information
    
.PARAMETER ComputerDN
    Computer Distinguished Name from .NET DirectoryServices
    
.PARAMETER DomainDNS
    Domain DNS name from .NET DirectoryServices or environment
    
.PARAMETER DomainShort
    Domain short name from .NET DirectoryServices or environment
    
.OUTPUTS
    Boolean - true if domain-joined
    
.EXAMPLE
    $IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN $DN -DomainDNS $DomainDNS -DomainShort $DomainShort
#>
Function Test-DMComputerDomainJoined {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False)]
        [String]$ComputerDN,
        
        [Parameter(Mandatory=$False)]
        [String]$DomainDNS,
        
        [Parameter(Mandatory=$False)]
        [String]$DomainShort
    )
    
    Try {
        # Method 1: Check if we have valid .NET DirectoryServices results
        If (-not [String]::IsNullOrEmpty($ComputerDN) -and -not [String]::IsNullOrEmpty($DomainDNS)) {
            Return $True
        }
        
        # Method 2: Check environment variables for domain info
        If (-not [String]::IsNullOrEmpty($env:USERDNSDOMAIN) -and $env:USERDNSDOMAIN -ne $env:COMPUTERNAME) {
            Return $True
        }
        
        # Method 3: Check WMI ComputerSystem.DomainRole
        [Object]$ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
        If ($ComputerSystem -and $ComputerSystem.DomainRole -ge 2) {
            Return $True
        }
        
        # Method 4: Check if LOGONSERVER is a domain controller (not local machine)
        If (-not [String]::IsNullOrEmpty($env:LOGONSERVER) -and $env:LOGONSERVER -ne "\\$($env:COMPUTERNAME)") {
            Return $True
        }
        
        Return $False
    }
    Catch {
        Write-Verbose "Error checking domain membership: $($_.Exception.Message)"
        Return $False
    }
}

<#
.SYNOPSIS
    Gets computer group memberships across the forest.
    
.DESCRIPTION
    Queries all domains in the forest for groups containing the computer.
    Returns array of group objects with DN and Name.
    
.PARAMETER DistinguishedName
    Computer's distinguished name
    
.OUTPUTS
    Array of PSCustomObject with GroupDN and GroupName properties
    
.EXAMPLE
    $Groups = Get-DMComputerGroups -DistinguishedName $Computer.DistinguishedName
#>
Function Get-DMComputerGroups {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return @()
    }
    
    Try {
        # Load .NET DirectoryServices
        Add-Type -AssemblyName System.DirectoryServices
        
        [Array]$AllGroups = @()
        
        # Create DirectorySearcher for groups that have this computer as a member
        [Object]$Searcher = New-Object System.DirectoryServices.DirectorySearcher
        $Searcher.Filter = "(&(objectClass=group)(member=$([System.Text.RegularExpressions.Regex]::Escape($DistinguishedName))))"
        $Searcher.PropertiesToLoad.AddRange(@("distinguishedName", "name"))
        
        [Object]$GroupResults = $Searcher.FindAll()
        
        ForEach ($GroupResult in $GroupResults) {
            [String]$GroupDN = $GroupResult.Properties["distinguishedName"][0]
            [String]$GroupName = $GroupResult.Properties["name"][0]
            
            $AllGroups += [PSCustomObject]@{
                PSTypeName = 'DM.GroupInfo'
                DistinguishedName = $GroupDN
                Name = $GroupName
            }
        }
        
        Return $AllGroups
    }
    Catch {
        Write-Verbose "Failed to get computer groups using .NET DirectoryServices: $($_.Exception.Message)"
        Return @()
    }
}

<#
.SYNOPSIS
    Extracts city code from distinguished name.
    
.DESCRIPTION
    Parses DN to extract city code from OU structure.
    Patterns: OU=DEVICES,OU=RESOURCES,OU=<CITY> or OU=USERS,OU=RESOURCES,OU=<CITY>
    Special handling for UAT: OU=RESOURCESUAT
    
.PARAMETER DistinguishedName
    LDAP DN to parse
    
.PARAMETER IsComputer
    True for computer DN, False for user DN
    
.OUTPUTS
    String - city code or "unknown"
    
.EXAMPLE
    $CityCode = Get-DMCityCode -DistinguishedName $DN -IsComputer $True
#>
Function Get-DMCityCode {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName,
        
        [Parameter(Mandatory=$False)]
        [Boolean]$IsComputer = $True
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return "unknown"
    }
    
    Try {
        [String]$DNUpper = $DistinguishedName.ToUpper()
        [Array]$Parts = $DistinguishedName -split ','
        
        # Determine OU type based on Computer or User
        [String]$OUType = If ($IsComputer) { "OU=DEVICES" } Else { "OU=USERS" }
        
        # Check for UAT environment first
        If ($DNUpper -match "OU=DEVICES,OU=RESOURCESUAT,OU=" -or $DNUpper -match "OU=USERS,OU=RESOURCESUAT,OU=") {
            For ([Int]$i = 0; $i -lt $Parts.Length; $i++) {
                If ($Parts[$i] -like "*OU=RESOURCESUAT*") {
                    If ($i + 1 -lt $Parts.Length) {
                        [String]$CityOU = $Parts[$i + 1]
                        Return $CityOU.Replace("OU=", "").Replace("ou=", "").Trim()
                    }
                }
            }
        }
        # Check for standard RESOURCES pattern
        ElseIf ($DNUpper -match "$OUType,OU=RESOURCES,OU=") {
            For ([Int]$i = 0; $i -lt $Parts.Length; $i++) {
                If ($Parts[$i] -like "*OU=RESOURCES*" -and $Parts[$i] -notlike "*RESOURCESUAT*") {
                    If ($i + 1 -lt $Parts.Length) {
                        [String]$CityOU = $Parts[$i + 1]
                        Return $CityOU.Replace("OU=", "").Replace("ou=", "").Trim()
                    }
                }
            }
        }
        
        Return "unknown"
    }
    Catch {
        Return "unknown"
    }
}

<#
.SYNOPSIS
    Gets the full OU path in canonical format.
    
.DESCRIPTION
    Converts DN to readable OU path format.
    
.PARAMETER DistinguishedName
    LDAP DN
    
.OUTPUTS
    String - canonical OU path
    
.EXAMPLE
    $OUPath = Get-DMOUPath -DistinguishedName $DN
#>
Function Get-DMOUPath {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return ""
    }
    
    Try {
        # Extract only OU components
        [Array]$Parts = $DistinguishedName -split ','
        [Array]$OUParts = @()
        
        ForEach ($Part in $Parts) {
            If ($Part -like "OU=*") {
                $OUParts += $Part.Replace("OU=", "").Replace("ou=", "").Trim()
            }
        }
        
        # Reverse for canonical order
        [Array]::Reverse($OUParts)
        
        Return ($OUParts -join '/')
    }
    Catch {
        Return ""
    }
}

<#
.SYNOPSIS
    Gets all IP addresses for the computer.
    
.DESCRIPTION
    Retrieves IP addresses from all enabled network adapters.
    
.OUTPUTS
    Array of IP address strings
    
.EXAMPLE
    $IPs = Get-DMIPAddresses
#>
Function Get-DMIPAddresses {
    [CmdletBinding()]
    Param()
    
    Try {
        [Array]$IPAddresses = @()
        
        # Use CIM instead of WMI for better performance
        [Array]$Configs = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled = TRUE"
        
        ForEach ($Config in $Configs) {
            If ($Null -ne $Config.IPAddress) {
                ForEach ($IP in $Config.IPAddress) {
                    $IPAddresses += $IP
                }
            }
        }
        
        Return $IPAddresses
    }
    Catch {
        Return @()
    }
}

<#
.SYNOPSIS
    Gets operating system information.
    
.DESCRIPTION
    Retrieves OS caption, determines if desktop or server.
    
.OUTPUTS
    PSCustomObject with OS properties
    
.EXAMPLE
    $OSInfo = Get-DMOSInfo
#>
Function Get-DMOSInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        [Object]$OS = Get-CimInstance -ClassName Win32_OperatingSystem
        [Object]$Computer = Get-CimInstance -ClassName Win32_ComputerSystem
        
        [String]$Caption = $OS.Caption
        [Boolean]$IsServer = $Caption -like "*Server*" -or $Computer.DomainRole -ge 3
        [Boolean]$IsDesktop = -not $IsServer
        
        Return [PSCustomObject]@{
            PSTypeName = 'DM.OSInfo'
            Caption = $Caption
            IsDesktop = $IsDesktop
            IsServer = $IsServer
            DomainRole = $Computer.DomainRole
        }
    }
    Catch {
        Return [PSCustomObject]@{
            PSTypeName = 'DM.OSInfo'
            Caption = "Unknown"
            IsDesktop = $True
            IsServer = $False
            DomainRole = 0
        }
    }
}

<#
.SYNOPSIS
    Tests if computer is member of a specific group.
    
.DESCRIPTION
    Checks if computer is member of a group (supports nested groups).
    
.PARAMETER ComputerInfo
    Computer info object from Get-DMComputerInfo
    
.PARAMETER GroupName
    Group name to check
    
.OUTPUTS
    Boolean - true if member
    
.EXAMPLE
    $IsMember = Test-DMComputerGroupMembership -ComputerInfo $Computer -GroupName "Pilot Desktop Management Script"
#>
Function Test-DMComputerGroupMembership {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo,
        
        [Parameter(Mandatory=$True)]
        [String]$GroupName
    )
    
    If ($Null -eq $ComputerInfo.Groups -or $ComputerInfo.Groups.Count -eq 0) {
        Return $False
    }
    
    ForEach ($Group in $ComputerInfo.Groups) {
        If ($Group.GroupName -eq $GroupName -or $Group.GroupName -like "*$GroupName*") {
            Return $True
        }
    }
    
    Return $False
}

# Export module members
Export-ModuleMember -Function @(
    'Get-DMComputerInfo',
    'Get-DMComputerADInfo',
    'Test-DMComputerDomainJoined',
    'Get-DMComputerGroups',
    'Get-DMCityCode',
    'Get-DMOUPath',
    'Get-DMIPAddresses',
    'Get-DMOSInfo',
    'Test-DMComputerGroupMembership'
)

