<#
.SYNOPSIS
    Desktop Management Computer Information Module
    
.DESCRIPTION
    Collects comprehensive computer information including AD properties, groups, site, IP addresses.
    Replacement for VBScript ComputerObject class.
    
.NOTES
    Version: 2.0.0
    Author: Desktop Management Team
    Replacement for: VB/Source/Main/Computer.vbs
#>

# Import required modules
Using Module .\DMCommon.psm1

<#
.SYNOPSIS
    Gets comprehensive computer information.
    
.DESCRIPTION
    Collects all computer properties needed for Desktop Management operations.
    Returns PSCustomObject with computer details.
    
.OUTPUTS
    PSCustomObject with computer properties
    
.EXAMPLE
    $Computer = Get-DMComputerInfo
    Write-Host "Computer: $($Computer.Name) in site $($Computer.Site)"
#>
Function Get-DMComputerInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        # Get basic computer name
        [String]$Name = $env:COMPUTERNAME
        
        # Get AD information using ADSystemInfo COM
        [Object]$ADInfo = Get-DMComputerADInfo
        
        # Check if we're domain-joined using robust detection
        If (-not $ADInfo.IsDomainJoined) {
            Write-Verbose "Computer is not domain-joined or AD information unavailable"
            
            # Return minimal info for non-domain computers
            Return [PSCustomObject]@{
                PSTypeName = 'DM.ComputerInfo'
                Name = $Name
                DistinguishedName = ""
                Domain = $env:USERDOMAIN
                ShortDomain = $env:USERDOMAIN
                Site = ""
                Groups = @()
                CityCode = "unknown"
                OUMapping = ""
                IPAddresses = Get-DMIPAddresses
                OSCaption = (Get-DMOSInfo).Caption
                IsDesktop = (Get-DMOSInfo).IsDesktop
                IsServer = (Get-DMOSInfo).IsServer
                DomainRole = (Get-DMOSInfo).DomainRole
                IsVPNConnected = Test-DMVPNConnection
            }
        }
        
        # Get group memberships
        [Array]$Groups = Get-DMComputerGroups -DistinguishedName $ADInfo.DistinguishedName
        
        # Extract city code from DN
        [String]$CityCode = Get-DMCityCode -DistinguishedName $ADInfo.DistinguishedName -IsComputer $True
        
        # Get OU mapping (full OU path)
        [String]$OUMapping = Get-DMOUPath -DistinguishedName $ADInfo.DistinguishedName
        
        # Get IP addresses
        [Array]$IPAddresses = Get-DMIPAddresses
        
        # Get OS information
        [Object]$OSInfo = Get-DMOSInfo
        
        # Check if VPN connected
        [Boolean]$IsVPNConnected = Test-DMVPNConnection
        
        # Build computer info object
        [PSCustomObject]$ComputerInfo = [PSCustomObject]@{
            PSTypeName = 'DM.ComputerInfo'
            Name = $Name
            DistinguishedName = $ADInfo.DistinguishedName
            Domain = $ADInfo.DomainDNS
            ShortDomain = $ADInfo.DomainShort
            Site = $ADInfo.Site
            Groups = $Groups
            CityCode = $CityCode
            OUMapping = $OUMapping
            IPAddresses = $IPAddresses
            OSCaption = $OSInfo.Caption
            IsDesktop = $OSInfo.IsDesktop
            IsServer = $OSInfo.IsServer
            DomainRole = $OSInfo.DomainRole
            IsVPNConnected = $IsVPNConnected
        }
        
        Return $ComputerInfo
    }
    Catch {
        Write-Error "Failed to get computer information: $($_.Exception.Message)"
        Return $Null
    }
}

<#
.SYNOPSIS
    Gets Active Directory information for the computer.
    
.DESCRIPTION
    Uses ADSystemInfo COM object to retrieve AD properties.
    
.OUTPUTS
    PSCustomObject with DN, Domain, Site
    
.EXAMPLE
    $ADInfo = Get-DMComputerADInfo
#>
Function Get-DMComputerADInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        # Create ADSystemInfo COM object
        [Object]$ADSysInfo = New-Object -ComObject ADSystemInfo
        
        [String]$ComputerDN = $ADSysInfo.ComputerName
        [String]$DomainDNS = $ADSysInfo.DomainDNSName
        [String]$DomainShort = $ADSysInfo.DomainShortName
        [String]$Site = $ADSysInfo.SiteName
        
        # Check if we're actually domain-joined using multiple methods
        [Boolean]$IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN $ComputerDN -DomainDNS $DomainDNS -DomainShort $DomainShort
        
        If (-not $IsDomainJoined) {
            Write-Verbose "Computer appears to be workgroup-joined or ADSystemInfo unavailable"
        }
        
        Return [PSCustomObject]@{
            DistinguishedName = $ComputerDN
            DomainDNS = $DomainDNS
            DomainShort = $DomainShort
            Site = $Site
            IsDomainJoined = $IsDomainJoined
        }
    }
    Catch {
        Write-Warning "Failed to get AD information: $($_.Exception.Message)"
        
        # Fallback to environment variables
        [String]$DomainDNS = $env:USERDNSDOMAIN
        [String]$DomainShort = $env:USERDOMAIN
        [Boolean]$IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN "" -DomainDNS $DomainDNS -DomainShort $DomainShort
        
        Return [PSCustomObject]@{
            DistinguishedName = ""
            DomainDNS = $DomainDNS
            DomainShort = $DomainShort
            Site = ""
            IsDomainJoined = $IsDomainJoined
        }
    }
}

<#
.SYNOPSIS
    Tests if computer is domain-joined using multiple detection methods.
    
.DESCRIPTION
    Uses multiple methods to determine if computer is domain-joined:
    1. ADSystemInfo COM object results
    2. Environment variables
    3. WMI ComputerSystem.DomainRole
    4. Registry domain information
    
.PARAMETER ComputerDN
    Computer Distinguished Name from ADSystemInfo
    
.PARAMETER DomainDNS
    Domain DNS name from ADSystemInfo or environment
    
.PARAMETER DomainShort
    Domain short name from ADSystemInfo or environment
    
.OUTPUTS
    Boolean - true if domain-joined
    
.EXAMPLE
    $IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN $DN -DomainDNS $DomainDNS -DomainShort $DomainShort
#>
Function Test-DMComputerDomainJoined {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False)]
        [String]$ComputerDN,
        
        [Parameter(Mandatory=$False)]
        [String]$DomainDNS,
        
        [Parameter(Mandatory=$False)]
        [String]$DomainShort
    )
    
    Try {
        # Method 1: Check if we have valid ADSystemInfo results
        If (-not [String]::IsNullOrEmpty($ComputerDN) -and -not [String]::IsNullOrEmpty($DomainDNS)) {
            Return $True
        }
        
        # Method 2: Check environment variables for domain info
        If (-not [String]::IsNullOrEmpty($env:USERDNSDOMAIN) -and $env:USERDNSDOMAIN -ne $env:COMPUTERNAME) {
            Return $True
        }
        
        # Method 3: Check WMI ComputerSystem.DomainRole
        [Object]$ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
        If ($ComputerSystem -and $ComputerSystem.DomainRole -ge 2) {
            Return $True
        }
        
        # Method 4: Check if LOGONSERVER is a domain controller (not local machine)
        If (-not [String]::IsNullOrEmpty($env:LOGONSERVER) -and $env:LOGONSERVER -ne "\\$($env:COMPUTERNAME)") {
            Return $True
        }
        
        Return $False
    }
    Catch {
        Write-Verbose "Error checking domain membership: $($_.Exception.Message)"
        Return $False
    }
}

<#
.SYNOPSIS
    Gets computer group memberships across the forest.
    
.DESCRIPTION
    Queries all domains in the forest for groups containing the computer.
    Returns array of group objects with DN and Name.
    
.PARAMETER DistinguishedName
    Computer's distinguished name
    
.OUTPUTS
    Array of PSCustomObject with GroupDN and GroupName properties
    
.EXAMPLE
    $Groups = Get-DMComputerGroups -DistinguishedName $Computer.DistinguishedName
#>
Function Get-DMComputerGroups {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return @()
    }
    
    Try {
        [Array]$AllGroups = @()
        
        # Get forest domains
        [Object]$ADSysInfo = New-Object -ComObject ADSystemInfo
        [Array]$ForestDomains = $ADSysInfo.GetTrees()
        
        # Query each domain
        ForEach ($Domain in $ForestDomains) {
            Try {
                # Build LDAP query
                [String]$LDAPFilter = "(&(objectClass=group)(member=$DistinguishedName))"
                [String]$LDAPQuery = "<LDAP://$Domain>;$LDAPFilter;distinguishedName,name;subtree"
                
                # Create ADODB connection
                [Object]$Connection = New-Object -ComObject ADODB.Connection
                $Connection.Open("Provider=ADsDSOObject;")
                
                # Create and execute command
                [Object]$Command = New-Object -ComObject ADODB.Command
                $Command.ActiveConnection = $Connection
                $Command.CommandText = $LDAPQuery
                
                [Object]$RecordSet = $Command.Execute()
                
                # Process results
                If ($RecordSet.State -eq 1 -and $RecordSet.RecordCount -gt 0) {
                    $RecordSet.MoveFirst()
                    
                    While (-not $RecordSet.EOF) {
                        [String]$GroupDN = $RecordSet.Fields.Item("distinguishedName").Value
                        [String]$GroupName = $RecordSet.Fields.Item("name").Value
                        
                        $AllGroups += [PSCustomObject]@{
                            PSTypeName = 'DM.GroupInfo'
                            GroupDN = $GroupDN
                            GroupName = $GroupName
                        }
                        
                        $RecordSet.MoveNext()
                    }
                }
                
                $Connection.Close()
            }
            Catch {
                Write-Verbose "Failed to query domain $Domain : $($_.Exception.Message)"
            }
        }
        
        Return $AllGroups
    }
    Catch {
        Write-Warning "Failed to get computer groups: $($_.Exception.Message)"
        Return @()
    }
}

<#
.SYNOPSIS
    Extracts city code from distinguished name.
    
.DESCRIPTION
    Parses DN to extract city code from OU structure.
    Patterns: OU=DEVICES,OU=RESOURCES,OU=<CITY> or OU=USERS,OU=RESOURCES,OU=<CITY>
    Special handling for UAT: OU=RESOURCESUAT
    
.PARAMETER DistinguishedName
    LDAP DN to parse
    
.PARAMETER IsComputer
    True for computer DN, False for user DN
    
.OUTPUTS
    String - city code or "unknown"
    
.EXAMPLE
    $CityCode = Get-DMCityCode -DistinguishedName $DN -IsComputer $True
#>
Function Get-DMCityCode {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName,
        
        [Parameter(Mandatory=$False)]
        [Boolean]$IsComputer = $True
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return "unknown"
    }
    
    Try {
        [String]$DNUpper = $DistinguishedName.ToUpper()
        [Array]$Parts = $DistinguishedName -split ','
        
        # Determine OU type based on Computer or User
        [String]$OUType = If ($IsComputer) { "OU=DEVICES" } Else { "OU=USERS" }
        
        # Check for UAT environment first
        If ($DNUpper -match "OU=DEVICES,OU=RESOURCESUAT,OU=" -or $DNUpper -match "OU=USERS,OU=RESOURCESUAT,OU=") {
            For ([Int]$i = 0; $i -lt $Parts.Length; $i++) {
                If ($Parts[$i] -like "*OU=RESOURCESUAT*") {
                    If ($i + 1 -lt $Parts.Length) {
                        [String]$CityOU = $Parts[$i + 1]
                        Return $CityOU.Replace("OU=", "").Replace("ou=", "").Trim()
                    }
                }
            }
        }
        # Check for standard RESOURCES pattern
        ElseIf ($DNUpper -match "$OUType,OU=RESOURCES,OU=") {
            For ([Int]$i = 0; $i -lt $Parts.Length; $i++) {
                If ($Parts[$i] -like "*OU=RESOURCES*" -and $Parts[$i] -notlike "*RESOURCESUAT*") {
                    If ($i + 1 -lt $Parts.Length) {
                        [String]$CityOU = $Parts[$i + 1]
                        Return $CityOU.Replace("OU=", "").Replace("ou=", "").Trim()
                    }
                }
            }
        }
        
        Return "unknown"
    }
    Catch {
        Return "unknown"
    }
}

<#
.SYNOPSIS
    Gets the full OU path in canonical format.
    
.DESCRIPTION
    Converts DN to readable OU path format.
    
.PARAMETER DistinguishedName
    LDAP DN
    
.OUTPUTS
    String - canonical OU path
    
.EXAMPLE
    $OUPath = Get-DMOUPath -DistinguishedName $DN
#>
Function Get-DMOUPath {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [String]$DistinguishedName
    )
    
    If ([String]::IsNullOrEmpty($DistinguishedName)) {
        Return ""
    }
    
    Try {
        # Extract only OU components
        [Array]$Parts = $DistinguishedName -split ','
        [Array]$OUParts = @()
        
        ForEach ($Part in $Parts) {
            If ($Part -like "OU=*") {
                $OUParts += $Part.Replace("OU=", "").Replace("ou=", "").Trim()
            }
        }
        
        # Reverse for canonical order
        [Array]::Reverse($OUParts)
        
        Return ($OUParts -join '/')
    }
    Catch {
        Return ""
    }
}

<#
.SYNOPSIS
    Gets all IP addresses for the computer.
    
.DESCRIPTION
    Retrieves IP addresses from all enabled network adapters.
    
.OUTPUTS
    Array of IP address strings
    
.EXAMPLE
    $IPs = Get-DMIPAddresses
#>
Function Get-DMIPAddresses {
    [CmdletBinding()]
    Param()
    
    Try {
        [Array]$IPAddresses = @()
        
        # Use CIM instead of WMI for better performance
        [Array]$Configs = Get-CimInstance -ClassName Win32_NetworkAdapterConfiguration -Filter "IPEnabled = TRUE"
        
        ForEach ($Config in $Configs) {
            If ($Null -ne $Config.IPAddress) {
                ForEach ($IP in $Config.IPAddress) {
                    $IPAddresses += $IP
                }
            }
        }
        
        Return $IPAddresses
    }
    Catch {
        Return @()
    }
}

<#
.SYNOPSIS
    Gets operating system information.
    
.DESCRIPTION
    Retrieves OS caption, determines if desktop or server.
    
.OUTPUTS
    PSCustomObject with OS properties
    
.EXAMPLE
    $OSInfo = Get-DMOSInfo
#>
Function Get-DMOSInfo {
    [CmdletBinding()]
    Param()
    
    Try {
        [Object]$OS = Get-CimInstance -ClassName Win32_OperatingSystem
        [Object]$Computer = Get-CimInstance -ClassName Win32_ComputerSystem
        
        [String]$Caption = $OS.Caption
        [Boolean]$IsServer = $Caption -like "*Server*" -or $Computer.DomainRole -ge 3
        [Boolean]$IsDesktop = -not $IsServer
        
        Return [PSCustomObject]@{
            PSTypeName = 'DM.OSInfo'
            Caption = $Caption
            IsDesktop = $IsDesktop
            IsServer = $IsServer
            DomainRole = $Computer.DomainRole
        }
    }
    Catch {
        Return [PSCustomObject]@{
            PSTypeName = 'DM.OSInfo'
            Caption = "Unknown"
            IsDesktop = $True
            IsServer = $False
            DomainRole = 0
        }
    }
}

<#
.SYNOPSIS
    Tests if computer is member of a specific group.
    
.DESCRIPTION
    Checks if computer is member of a group (supports nested groups).
    
.PARAMETER ComputerInfo
    Computer info object from Get-DMComputerInfo
    
.PARAMETER GroupName
    Group name to check
    
.OUTPUTS
    Boolean - true if member
    
.EXAMPLE
    $IsMember = Test-DMComputerGroupMembership -ComputerInfo $Computer -GroupName "Pilot Desktop Management Script"
#>
Function Test-DMComputerGroupMembership {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo,
        
        [Parameter(Mandatory=$True)]
        [String]$GroupName
    )
    
    If ($Null -eq $ComputerInfo.Groups -or $ComputerInfo.Groups.Count -eq 0) {
        Return $False
    }
    
    ForEach ($Group in $ComputerInfo.Groups) {
        If ($Group.GroupName -eq $GroupName -or $Group.GroupName -like "*$GroupName*") {
            Return $True
        }
    }
    
    Return $False
}

# Export module members
Export-ModuleMember -Function @(
    'Get-DMComputerInfo',
    'Get-DMComputerADInfo',
    'Test-DMComputerDomainJoined',
    'Get-DMComputerGroups',
    'Get-DMCityCode',
    'Get-DMOUPath',
    'Get-DMIPAddresses',
    'Get-DMOSInfo',
    'Test-DMComputerGroupMembership'
)

