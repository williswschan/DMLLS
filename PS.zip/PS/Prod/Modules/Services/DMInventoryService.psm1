<#
.SYNOPSIS
    Desktop Management Inventory Service Module
    
.DESCRIPTION
    Handles sending inventory data TO the backend service.
    Supports logon/logoff tracking, drive inventory, printer inventory, PST inventory.
    
.NOTES
    Version: 2.0.0
    Author: Desktop Management Team
    Replacement for: Inventory*_W10.vbs modules
#>

# Import required modules
Using Module .\DMServiceCommon.psm1
Using Module ..\Framework\DMLogger.psm1

<#
.SYNOPSIS
    Sends user session logon inventory to backend.
    
.DESCRIPTION
    Records user logon event with computer and user information.
    
.PARAMETER UserInfo
    User information object
    
.PARAMETER ComputerInfo
    Computer information object
    
.PARAMETER Server
    Optional server object (if not provided, will discover automatically)
    
.OUTPUTS
    Boolean - true if successful
    
.EXAMPLE
    $Success = Send-DMLogonInventory -UserInfo $User -ComputerInfo $Computer
#>
Function Send-DMLogonInventory {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo,
        
        [Parameter(Mandatory=$False)]
        [PSCustomObject]$Server = $Null
    )
    
    Try {
        Write-DMLog "Inventory Logon: Preparing to insert user session data" -Level Verbose
        
        # Get server if not provided
        If ($Null -eq $Server) {
            $Server = Get-DMServiceServer -ServiceName "ClassicInventory.asmx" -Domain $ComputerInfo.Domain
        }
        
        If ($Null -eq $Server -or -not $Server.ServiceAvailable) {
            Write-DMLog "Inventory Logon: No available inventory service found" -Level Warning
            Return $False
        }
        
        Write-DMLog "Inventory Logon: Using service: $($Server.ServiceURL)" -Level Verbose
        
        # Build SOAP request using proven pattern from working code
        [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$($UserInfo.Name)</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:InsertLogonInventory>
            <tem:userDN>$($UserInfo.DistinguishedName)</tem:userDN>
            <tem:computerDN>$($ComputerInfo.DistinguishedName)</tem:computerDN>
            <tem:siteName>$($ComputerInfo.Site)</tem:siteName>
            <tem:city>$($ComputerInfo.CityCode)</tem:city>
        </tem:InsertLogonInventory>
    </soap:Body>
</soap:Envelope>
"@
        
        Write-DMLog "Inventory Logon: Sending data - User: $($UserInfo.Name), Computer: $($ComputerInfo.Name)" -Level Verbose
        
        # Send request using proven authentication pattern
        [Object]$Response = Send-DMSOAPRequestWithAuth -ServerUrl $Server.ServiceURL -SOAPBody $SOAPBody -SOAPAction "http://tempuri.org/InsertLogonInventory" -Username $UserInfo.Name -Password "placeholder" -Timeout $Server.Timeout
        
        If ($Response.Success) {
            Write-DMLog "Inventory Logon: Successfully sent session data" -Level Verbose
            Return $True
        } Else {
            Write-DMLog "Inventory Logon: Failed to send session data (Status: $($Response.StatusCode))" -Level Warning
            Return $False
        }
    }
    Catch {
        Write-DMLog "Inventory Logon: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

<#
.SYNOPSIS
    Sends user session logoff inventory to backend.
    
.DESCRIPTION
    Records user logoff event.
    
.PARAMETER UserInfo
    User information object
    
.PARAMETER ComputerInfo
    Computer information object
    
.PARAMETER Server
    Optional server object
    
.OUTPUTS
    Boolean - true if successful
    
.EXAMPLE
    $Success = Send-DMLogoffInventory -UserInfo $User -ComputerInfo $Computer
#>
Function Send-DMLogoffInventory {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo,
        
        [Parameter(Mandatory=$False)]
        [PSCustomObject]$Server = $Null
    )
    
    Try {
        Write-DMLog "Inventory Logoff: Preparing to insert user session data" -Level Verbose
        
        # Get server if not provided
        If ($Null -eq $Server) {
            $Server = Get-DMServiceServer -ServiceName "ClassicInventory.asmx" -Domain $ComputerInfo.Domain
        }
        
        If ($Null -eq $Server -or -not $Server.ServiceAvailable) {
            Write-DMLog "Inventory Logoff: No available inventory service found" -Level Warning
            Return $False
        }
        
        # Build SOAP request using proven pattern from working code
        [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$($UserInfo.Name)</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:InsertLogoffInventory>
            <tem:userDN>$($UserInfo.DistinguishedName)</tem:userDN>
            <tem:computerDN>$($ComputerInfo.DistinguishedName)</tem:computerDN>
            <tem:siteName>$($ComputerInfo.Site)</tem:siteName>
            <tem:city>$($ComputerInfo.CityCode)</tem:city>
        </tem:InsertLogoffInventory>
    </soap:Body>
</soap:Envelope>
"@
        
        Write-DMLog "Inventory Logoff: Sending data - User: $($UserInfo.Name), Computer: $($ComputerInfo.Name)" -Level Verbose
        
        # Send request using proven authentication pattern
        [Object]$Response = Send-DMSOAPRequestWithAuth -ServerUrl $Server.ServiceURL -SOAPBody $SOAPBody -SOAPAction "http://tempuri.org/InsertLogoffInventory" -Username $UserInfo.Name -Password "placeholder" -Timeout $Server.Timeout
        
        If ($Response.Success) {
            Write-DMLog "Inventory Logoff: Successfully sent session data" -Level Verbose
            Return $True
        } Else {
            Write-DMLog "Inventory Logoff: Failed to send session data (Status: $($Response.StatusCode))" -Level Warning
            Return $False
        }
    }
    Catch {
        Write-DMLog "Inventory Logoff: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

<#
.SYNOPSIS
    Sends drive mapping inventory to backend.
    
.DESCRIPTION
    Records current drive mappings for the user.
    
.PARAMETER DriveInfo
    Drive mapping information (array of drive objects)
    
.PARAMETER UserInfo
    User information
    
.PARAMETER ComputerInfo
    Computer information
    
.PARAMETER Server
    Optional server object
    
.OUTPUTS
    Boolean - true if successful
    
.EXAMPLE
    $Success = Send-DMDriveInventory -DriveInfo $Drives -UserInfo $User -ComputerInfo $Computer
#>
Function Send-DMDriveInventory {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$True)]
        [Array]$DriveInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$UserInfo,
        
        [Parameter(Mandatory=$True)]
        [PSCustomObject]$ComputerInfo,
        
        [Parameter(Mandatory=$False)]
        [PSCustomObject]$Server = $Null
    )
    
    Try {
        If ($DriveInfo.Count -eq 0) {
            Write-DMLog "Drive Inventory: No drives to send" -Level Verbose
            Return $True
        }
        
        # Get server if not provided
        If ($Null -eq $Server) {
            $Server = Get-DMServiceServer -ServiceName "ClassicInventory.asmx" -Domain $ComputerInfo.Domain
        }
        
        If ($Null -eq $Server -or -not $Server.ServiceAvailable) {
            Write-DMLog "Drive Inventory: No available inventory service found" -Level Warning
            Return $False
        }
        
        [Int]$SuccessCount = 0
        
        ForEach ($Drive in $DriveInfo) {
            # Build SOAP request using proven pattern from working code
            [String]$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
    <soap:Header>
        <tem:AuthHeader>
            <tem:Username>$($UserInfo.Name)</tem:Username>
            <tem:Password>placeholder</tem:Password>
        </tem:AuthHeader>
    </soap:Header>
    <soap:Body>
        <tem:InsertActiveDriveMappingsFromInventory>
            <tem:userDN>$($UserInfo.DistinguishedName)</tem:userDN>
            <tem:computerDN>$($ComputerInfo.DistinguishedName)</tem:computerDN>
            <tem:drive>$($Drive.DriveLetter)</tem:drive>
            <tem:uncPath>$($Drive.UncPath)</tem:uncPath>
            <tem:description>$($Drive.Description)</tem:description>
            <tem:siteName>$($ComputerInfo.Site)</tem:siteName>
            <tem:city>$($ComputerInfo.CityCode)</tem:city>
        </tem:InsertActiveDriveMappingsFromInventory>
    </soap:Body>
</soap:Envelope>
"@
            
            [Object]$Response = Send-DMSOAPRequestWithAuth -ServerUrl $Server.ServiceURL -SOAPBody $SOAPBody -SOAPAction "http://tempuri.org/InsertActiveDriveMappingsFromInventory" -Username $UserInfo.Name -Password "placeholder" -Timeout $Server.Timeout
            
            If ($Response.Success) {
                $SuccessCount++
            }
        }
        
        Write-DMLog "Drive Inventory: Sent $SuccessCount of $($DriveInfo.Count) drives" -Level Verbose
        Return ($SuccessCount -eq $DriveInfo.Count)
    }
    Catch {
        Write-DMLog "Drive Inventory: Error - $($_.Exception.Message)" -Level Error
        Return $False
    }
}

<#
.SYNOPSIS
    Gets inventory service server.
    
.DESCRIPTION
    Discovers and returns the inventory service server.
    
.PARAMETER Domain
    Domain name
    
.OUTPUTS
    PSCustomObject - server information
    
.EXAMPLE
    $Server = Get-DMInventoryServer -Domain $Computer.Domain
#>
Function Get-DMInventoryServer {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$False)]
        [String]$Domain = ""
    )
    
    Return Get-DMServiceServer -ServiceName "ClassicInventory.asmx" -Domain $Domain
}

# Export module members
Export-ModuleMember -Function @(
    'Send-DMLogonInventory',
    'Send-DMLogoffInventory',
    'Send-DMDriveInventory',
    'Get-DMInventoryServer'
)

