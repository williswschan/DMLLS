<#
.SYNOPSIS
    Domain Detection Diagnostic Script
    
.DESCRIPTION
    Tests domain detection methods to help diagnose issues on domain-joined machines.
    Run this on your real domain-joined machine to verify domain detection is working correctly.
    
.EXAMPLE
    .\Test-DomainDetection.ps1
#>

# Import required modules in correct order
Import-Module "$PSScriptRoot\Modules\Framework\DMCommon.psm1" -Force
Import-Module "$PSScriptRoot\Modules\Framework\DMLogger.psm1" -Force
Import-Module "$PSScriptRoot\Modules\Utilities\Test-Environment.psm1" -Force
Import-Module "$PSScriptRoot\Modules\Framework\DMComputer.psm1" -Force
Import-Module "$PSScriptRoot\Modules\Framework\DMUser.psm1" -Force

Write-Host "🔍 DOMAIN DETECTION DIAGNOSTIC" -ForegroundColor Yellow
Write-Host "=============================" -ForegroundColor Cyan
Write-Host ""

# Test 1: Environment Variables
Write-Host "1. Environment Variables:" -ForegroundColor Green
Write-Host "   USERDOMAIN: $env:USERDOMAIN" -ForegroundColor White
Write-Host "   USERDNSDOMAIN: $env:USERDNSDOMAIN" -ForegroundColor White
Write-Host "   LOGONSERVER: $env:LOGONSERVER" -ForegroundColor White
Write-Host "   COMPUTERNAME: $env:COMPUTERNAME" -ForegroundColor White
Write-Host ""

# Test 2: ADSystemInfo COM Object
Write-Host "2. ADSystemInfo COM Object:" -ForegroundColor Green
Try {
    $ADSysInfo = New-Object -ComObject ADSystemInfo
    Write-Host "   ComputerName: $($ADSysInfo.ComputerName)" -ForegroundColor White
    Write-Host "   UserName: $($ADSysInfo.UserName)" -ForegroundColor White
    Write-Host "   DomainDNSName: $($ADSysInfo.DomainDNSName)" -ForegroundColor White
    Write-Host "   DomainShortName: $($ADSysInfo.DomainShortName)" -ForegroundColor White
    Write-Host "   SiteName: $($ADSysInfo.SiteName)" -ForegroundColor White
} Catch {
    Write-Host "   ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 3: WMI ComputerSystem
Write-Host "3. WMI ComputerSystem:" -ForegroundColor Green
Try {
    $ComputerSystem = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction SilentlyContinue
    If ($ComputerSystem) {
        Write-Host "   Domain: $($ComputerSystem.Domain)" -ForegroundColor White
        Write-Host "   DomainRole: $($ComputerSystem.DomainRole)" -ForegroundColor White
        Write-Host "   PartOfDomain: $($ComputerSystem.PartOfDomain)" -ForegroundColor White
    } Else {
        Write-Host "   ERROR: Could not retrieve ComputerSystem info" -ForegroundColor Red
    }
} Catch {
    Write-Host "   ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 4: PowerShell Domain Detection Function
Write-Host "4. PowerShell Domain Detection:" -ForegroundColor Green
Try {
    $IsDomainJoined = Test-DMComputerDomainJoined -ComputerDN $ADSysInfo.ComputerName -DomainDNS $ADSysInfo.DomainDNSName -DomainShort $ADSysInfo.DomainShortName
    Write-Host "   IsDomainJoined: $IsDomainJoined" -ForegroundColor White
} Catch {
    Write-Host "   ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 5: Get-DMComputerInfo
Write-Host "5. Get-DMComputerInfo Function:" -ForegroundColor Green
Try {
    $Computer = Get-DMComputerInfo
    Write-Host "   Name: $($Computer.Name)" -ForegroundColor White
    Write-Host "   Domain: $($Computer.Domain)" -ForegroundColor White
    Write-Host "   DistinguishedName: $($Computer.DistinguishedName)" -ForegroundColor White
    Write-Host "   Site: $($Computer.Site)" -ForegroundColor White
} Catch {
    Write-Host "   ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 6: Get-DMUserInfo
Write-Host "6. Get-DMUserInfo Function:" -ForegroundColor Green
Try {
    $User = Get-DMUserInfo
    Write-Host "   Name: $($User.Name)" -ForegroundColor White
    Write-Host "   Domain: $($User.Domain)" -ForegroundColor White
    Write-Host "   DistinguishedName: $($User.DistinguishedName)" -ForegroundColor White
    Write-Host "   LogonServer: $($User.LogonServer)" -ForegroundColor White
} Catch {
    Write-Host "   ERROR: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# Test 7: Domain-Joined Verification
Write-Host "7. Domain-Joined Verification:" -ForegroundColor Green
$DomainIndicators = @()

# Check USERDNSDOMAIN
If (-not [String]::IsNullOrEmpty($env:USERDNSDOMAIN)) {
    $DomainIndicators += "USERDNSDOMAIN: $env:USERDNSDOMAIN"
}

# Check LOGONSERVER
If (-not [String]::IsNullOrEmpty($env:LOGONSERVER) -and $env:LOGONSERVER -ne "\\$($env:COMPUTERNAME)") {
    $DomainIndicators += "LOGONSERVER: $env:LOGONSERVER"
}

# Check ADSystemInfo
If (-not [String]::IsNullOrEmpty($ADSysInfo.DomainDNSName)) {
    $DomainIndicators += "ADSystemInfo.DomainDNSName: $($ADSysInfo.DomainDNSName)"
}

# Check WMI
If ($ComputerSystem -and $ComputerSystem.PartOfDomain) {
    $DomainIndicators += "WMI.PartOfDomain: $($ComputerSystem.PartOfDomain)"
}

If ($DomainIndicators.Count -gt 0) {
    Write-Host "   ✅ DOMAIN-JOINED DETECTED:" -ForegroundColor Green
    ForEach ($Indicator in $DomainIndicators) {
        Write-Host "      $Indicator" -ForegroundColor White
    }
} Else {
    Write-Host "   ❌ NOT DOMAIN-JOINED (Workgroup)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "Diagnostic Complete" -ForegroundColor Yellow
Write-Host "=========================================" -ForegroundColor Cyan
