<#
.SYNOPSIS
    Detailed diagnostic script to see exactly what's being parsed from XML
#>

# Import modules
Try {
    Import-Module ".\Modules\Services\DMServiceCommon.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Framework\DMLogger.psm1" -Force -ErrorAction Stop
    Write-Host "All modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Test parameters
$UserId = "chanwilw"
$Domain = "MYMSNGROUP"
$OuMapping = "MYMSNGROUP.COM/HK/Users/Individual"
$AdGroups = ""
$Site = "HK"

Write-Host "`n=== Testing Detailed XML Parsing ===" -ForegroundColor Cyan

# Build SOAP request
$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 <soap:Header>
  <tem:AuthHeader xmlns:tem="http://webtools.japan.nom">
   <tem:Username>$UserId</tem:Username>
   <tem:Password>placeholder</tem:Password>
  </tem:AuthHeader>
 </soap:Header>
 <soap:Body>
  <GetUserDrives xmlns="http://webtools.japan.nom">
   <UserId xsi:type="xsd:string">$UserId</UserId>
   <Domain xsi:type="xsd:string">$Domain</Domain>
   <OuMapping xsi:type="xsd:string">$OuMapping</OuMapping>
   <AdGroups xsi:type="xsd:string">$AdGroups</AdGroups>
   <Site xsi:type="xsd:string">$Site</Site>
  </GetUserDrives>
 </soap:Body>
</soap:Envelope>
"@

$ServerUrl = "https://gdpmappercb.nomura.com/ClassicMapper.asmx"
$SOAPAction = "http://webtools.japan.nom/GetUserDrives"

Try {
    Write-Host "Making SOAP request..." -ForegroundColor Yellow
    $Response = Send-DMSOAPRequestWithAuth -ServerUrl $ServerUrl -SOAPBody $SOAPBody -SOAPAction $SOAPAction -Username $UserId -Password "placeholder"
    
    If ($Response.Success) {
        Write-Host "SOAP request successful" -ForegroundColor Green
        
        # Parse XML
        $XmlDoc = [Xml]$Response.Content
        $ResultNode = $XmlDoc.SelectSingleNode("//*[local-name()='GetUserDrivesResult']")
        
        If ($ResultNode) {
            Write-Host "Found GetUserDrivesResult node" -ForegroundColor Green
            $DriveNodes = $ResultNode.SelectNodes(".//*[local-name()='MapperDrive']")
            Write-Host "Found $($DriveNodes.Count) MapperDrive elements" -ForegroundColor Green
            
            For ($i = 0; $i -lt $DriveNodes.Count; $i++) {
                $DriveNode = $DriveNodes[$i]
                Write-Host "`n--- MapperDrive $($i + 1) ---" -ForegroundColor Yellow
                
                # Test different ways to get DriveLetter
                Write-Host "Testing different parsing methods:" -ForegroundColor White
                
                # Method 1: local-name()
                $Method1 = $DriveNode.SelectSingleNode("*[local-name()='DriveLetter']")
                Write-Host "Method 1 (local-name): $($Method1.InnerText)" -ForegroundColor White
                
                # Method 2: Direct property access
                $Method2 = $DriveNode.DriveLetter
                Write-Host "Method 2 (property): $($Method2.InnerText)" -ForegroundColor White
                
                # Method 3: ChildNodes iteration
                $Method3 = $DriveNode.ChildNodes | Where-Object { $_.LocalName -eq "DriveLetter" }
                If ($Method3) {
                    Write-Host "Method 3 (ChildNodes): $($Method3.InnerText)" -ForegroundColor White
                } Else {
                    Write-Host "Method 3 (ChildNodes): Not found" -ForegroundColor Red
                }
                
                # Method 4: SelectNodes
                $Method4 = $DriveNode.SelectNodes("*[local-name()='DriveLetter']")
                If ($Method4.Count -gt 0) {
                    Write-Host "Method 4 (SelectNodes): $($Method4[0].InnerText)" -ForegroundColor White
                } Else {
                    Write-Host "Method 4 (SelectNodes): Not found" -ForegroundColor Red
                }
                
                # Show all child elements
                Write-Host "All child elements:" -ForegroundColor Cyan
                ForEach ($Child in $DriveNode.ChildNodes) {
                    If ($Child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                        Write-Host "  $($Child.LocalName): '$($Child.InnerText)'" -ForegroundColor White
                    }
                }
            }
        } Else {
            Write-Host "GetUserDrivesResult node not found" -ForegroundColor Red
        }
    } Else {
        Write-Host "SOAP request failed: $($Response.StatusCode)" -ForegroundColor Red
    }
}
Catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
