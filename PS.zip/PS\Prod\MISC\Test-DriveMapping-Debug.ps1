<#
.SYNOPSIS
    Debug script to diagnose drive mapping XML parsing issues
    
.DESCRIPTION
    This script will test the drive mapping service and show exactly what XML
    is being returned and how it's being parsed.
#>

# Import modules
Try {
    Import-Module ".\Modules\Services\DMMapperService.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Framework\DMLogger.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Framework\DMComputer.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Framework\DMUser.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Services\DMServiceCommon.psm1" -Force -ErrorAction Stop
    Write-Host "All modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Create test user and computer objects
$TestUser = [PSCustomObject]@{
    Name = "chanwilw"
    DistinguishedName = "CN=chanwilw,OU=Users,DC=mymsngroup,DC=com"
    Domain = "mymsngroup.com"
    ShortDomain = "MYMSNGROUP"
    LogonServer = "DC01"
    OUMapping = "MYMSNGROUP.COM/HK/Users/Individual"
    Groups = @()
}

$TestComputer = [PSCustomObject]@{
    Name = "TEST-PC"
    DistinguishedName = "CN=TEST-PC,OU=Computers,DC=mymsngroup,DC=com"
    Domain = "mymsngroup.com"
    ShortDomain = "MYMSNGROUP"
    Site = "HK"
    OUMapping = "MYMSNGROUP.COM/NOM"
    CityCode = "HK"
    IPAddresses = @("192.168.1.100")
    OSCaption = "Microsoft Windows 10 Pro"
    IsDesktop = $True
    IsVPNConnected = $False
    Groups = @()
}

Write-Host "`n=== Testing Drive Mapping Service ===" -ForegroundColor Cyan
Write-Host "User: $($TestUser.Name)" -ForegroundColor Yellow
Write-Host "Domain: $($TestUser.Domain)" -ForegroundColor Yellow
Write-Host "Computer: $($TestComputer.Name)" -ForegroundColor Yellow

# Test the service
Try {
    Write-Host "`n--- Calling Get-DMDriveMappings ---" -ForegroundColor Green
    $DriveMappings = Get-DMDriveMappings -UserInfo $TestUser -ComputerInfo $TestComputer
    
    Write-Host "`n--- Results Summary ---" -ForegroundColor Green
    Write-Host "Number of mappings returned: $($DriveMappings.Count)" -ForegroundColor White
    
    If ($DriveMappings.Count -gt 0) {
        Write-Host "`n--- Individual Mapping Details ---" -ForegroundColor Green
        For ($i = 0; $i -lt $DriveMappings.Count; $i++) {
            $Mapping = $DriveMappings[$i]
            Write-Host "`nMapping $($i + 1):" -ForegroundColor Yellow
            Write-Host "  DriveLetter: '$($Mapping.DriveLetter)' (Type: $($Mapping.DriveLetter.GetType().Name))" -ForegroundColor White
            Write-Host "  DriveLetter is null: $($Mapping.DriveLetter -eq $Null)" -ForegroundColor White
            Write-Host "  DriveLetter is empty: $([String]::IsNullOrEmpty($Mapping.DriveLetter))" -ForegroundColor White
            Write-Host "  UncPath: '$($Mapping.UncPath)'" -ForegroundColor White
            Write-Host "  Description: '$($Mapping.Description)'" -ForegroundColor White
            Write-Host "  Id: '$($Mapping.Id)'" -ForegroundColor White
            Write-Host "  Domain: '$($Mapping.Domain)'" -ForegroundColor White
            Write-Host "  UserId: '$($Mapping.UserId)'" -ForegroundColor White
            Write-Host "  AdGroup: '$($Mapping.AdGroup)'" -ForegroundColor White
            Write-Host "  Site: '$($Mapping.Site)'" -ForegroundColor White
            Write-Host "  DisconnectOnLogin: $($Mapping.DisconnectOnLogin)" -ForegroundColor White
            
            # Check if DriveLetter property exists
            If ($Mapping.PSObject.Properties.Name -contains "DriveLetter") {
                Write-Host "  ✓ DriveLetter property exists" -ForegroundColor Green
            } Else {
                Write-Host "  ✗ DriveLetter property MISSING" -ForegroundColor Red
                Write-Host "  Available properties: $($Mapping.PSObject.Properties.Name -join ', ')" -ForegroundColor Red
            }
        }
    } Else {
        Write-Host "No drive mappings returned" -ForegroundColor Red
    }
}
Catch {
    Write-Host "`n--- Error Details ---" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Line: $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Red
    Write-Host "Script: $($_.InvocationInfo.ScriptName)" -ForegroundColor Red
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
