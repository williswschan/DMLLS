# Diagnostic script to identify the exact issue in the real environment
# This will help pinpoint where the "null-valued expression" error occurs

[CmdletBinding()]
Param()

Write-Host "=== Real Environment Drive Mapping Debug ===" -ForegroundColor Green

# Import required modules
Try {
    Import-Module ..\Modules\Framework\DMCommon.psm1 -Force
    Import-Module ..\Modules\Framework\DMLogger.psm1 -Force
    Import-Module ..\Modules\Framework\DMUser.psm1 -Force
    Import-Module ..\Modules\Framework\DMComputer.psm1 -Force
    Import-Module ..\Modules\Utilities\Test-Environment.psm1 -Force
    Import-Module ..\Modules\Services\DMMapperService.psm1 -Force
    Import-Module ..\Modules\Mapper\Invoke-DriveMapper.psm1 -Force
    Write-Host "SUCCESS: All modules imported" -ForegroundColor Green
}
Catch {
    Write-Host "ERROR: Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

Write-Host "`n=== Environment Information ===" -ForegroundColor Yellow
Write-Host "USERNAME: '$env:USERNAME'" -ForegroundColor Cyan
Write-Host "USERDOMAIN: '$env:USERDOMAIN'" -ForegroundColor Cyan
Write-Host "USERDNSDOMAIN: '$env:USERDNSDOMAIN'" -ForegroundColor Cyan
Write-Host "LOGONSERVER: '$env:LOGONSERVER'" -ForegroundColor Cyan

Write-Host "`n=== Getting Real User Information ===" -ForegroundColor Yellow
Try {
    $RealUserInfo = Get-DMUserInfo
    Write-Host "SUCCESS: Retrieved real user information" -ForegroundColor Green
    Write-Host "  Name: '$($RealUserInfo.Name)'" -ForegroundColor Cyan
    Write-Host "  Domain: '$($RealUserInfo.Domain)'" -ForegroundColor Cyan
    Write-Host "  ShortDomain: '$($RealUserInfo.ShortDomain)'" -ForegroundColor Cyan
    Write-Host "  DistinguishedName: '$($RealUserInfo.DistinguishedName)'" -ForegroundColor Cyan
    Write-Host "  CityCode: '$($RealUserInfo.CityCode)'" -ForegroundColor Cyan
    Write-Host "  OUMapping: '$($RealUserInfo.OUMapping)'" -ForegroundColor Cyan
    Write-Host "  Groups Count: $($RealUserInfo.Groups.Count)" -ForegroundColor Cyan
    
    # Check for empty Name (this could cause the issue)
    If ([String]::IsNullOrEmpty($RealUserInfo.Name)) {
        Write-Host "WARNING: UserInfo.Name is empty! This will cause web service failures." -ForegroundColor Red
    }
}
Catch {
    Write-Host "ERROR: Failed to get user information: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
    Exit 1
}

Write-Host "`n=== Getting Real Computer Information ===" -ForegroundColor Yellow
Try {
    $RealComputerInfo = Get-DMComputerInfo
    Write-Host "SUCCESS: Retrieved real computer information" -ForegroundColor Green
    Write-Host "  Name: '$($RealComputerInfo.Name)'" -ForegroundColor Cyan
    Write-Host "  Domain: '$($RealComputerInfo.Domain)'" -ForegroundColor Cyan
    Write-Host "  Site: '$($RealComputerInfo.Site)'" -ForegroundColor Cyan
    Write-Host "  CityCode: '$($RealComputerInfo.CityCode)'" -ForegroundColor Cyan
}
Catch {
    Write-Host "ERROR: Failed to get computer information: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
    Exit 1
}

Write-Host "`n=== Testing Web Service Connection ===" -ForegroundColor Yellow
Try {
    Write-Host "Attempting to get drive mappings from service..." -ForegroundColor Cyan
    $DriveMappings = Get-DMDriveMappings -UserInfo $RealUserInfo -ComputerInfo $RealComputerInfo
    
    Write-Host "SUCCESS: Retrieved drive mappings from service" -ForegroundColor Green
    Write-Host "  Drive Mappings Count: $($DriveMappings.Count)" -ForegroundColor Cyan
    
    If ($DriveMappings.Count -gt 0) {
        Write-Host "Drive Mappings Details:" -ForegroundColor Cyan
        ForEach ($Mapping in $DriveMappings) {
            Write-Host "    DriveLetter: '$($Mapping.DriveLetter)'" -ForegroundColor Cyan
            Write-Host "    UncPath: '$($Mapping.UncPath)'" -ForegroundColor Cyan
            Write-Host "    Description: '$($Mapping.Description)'" -ForegroundColor Cyan
            Write-Host "    DisconnectOnLogin: $($Mapping.DisconnectOnLogin)" -ForegroundColor Cyan
            Write-Host "    ---" -ForegroundColor Gray
            
            # Check for null/empty properties that could cause issues
            If ([String]::IsNullOrEmpty($Mapping.DriveLetter)) {
                Write-Host "WARNING: Mapping has empty DriveLetter!" -ForegroundColor Red
            }
            If ([String]::IsNullOrEmpty($Mapping.UncPath)) {
                Write-Host "WARNING: Mapping has empty UncPath!" -ForegroundColor Red
            }
        }
    } Else {
        Write-Host "No drive mappings returned from service" -ForegroundColor Yellow
    }
}
Catch {
    Write-Host "ERROR: Failed to get drive mappings from service: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
    Write-Host "  Stack Trace: $($_.Exception.StackTrace)" -ForegroundColor Red
}

Write-Host "`n=== Testing Drive Mapping Workflow ===" -ForegroundColor Yellow
Try {
    Write-Host "Attempting complete drive mapping workflow..." -ForegroundColor Cyan
    $Result = Invoke-DMDriveMapper -UserInfo $RealUserInfo -ComputerInfo $RealComputerInfo
    
    If ($Result) {
        Write-Host "SUCCESS: Drive mapping workflow completed successfully" -ForegroundColor Green
    } Else {
        Write-Host "FAILED: Drive mapping workflow failed" -ForegroundColor Red
    }
}
Catch {
    Write-Host "ERROR: Exception during drive mapping workflow: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
    Write-Host "  Stack Trace: $($_.Exception.StackTrace)" -ForegroundColor Red
    
    # Try to identify the exact line causing the issue
    If ($_.Exception.Message -like "*null-valued expression*") {
        Write-Host "`nNULL-VALUED EXPRESSION DETECTED!" -ForegroundColor Red
        Write-Host "This error typically occurs when:" -ForegroundColor Yellow
        Write-Host "  1. A property is accessed on a null object" -ForegroundColor Yellow
        Write-Host "  2. A method is called on a null object" -ForegroundColor Yellow
        Write-Host "  3. An array element is accessed that doesn't exist" -ForegroundColor Yellow
        Write-Host "`nCheck the stack trace above for the exact location." -ForegroundColor Yellow
    }
}

Write-Host "`n=== Final Status ===" -ForegroundColor Yellow
Write-Host "Debug complete. Check the output above for any warnings or errors." -ForegroundColor Cyan

Write-Host "`n=== Test Complete ===" -ForegroundColor Green
