<#
.SYNOPSIS
    Simple SOAP test without execution policy changes
#>

# Import modules
Try {
    Import-Module ".\Modules\Services\DMServiceCommon.psm1" -Force -ErrorAction Stop
    Write-Host "Module imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "Failed to import module: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Test parameters
$UserId = "chanwilw"
$Domain = "MYMSNGROUP"
$OuMapping = "MYMSNGROUP.COM/HK/Users/Individual"
$AdGroups = ""
$Site = "HK"

Write-Host "Testing SOAP connection with 30-second timeout..." -ForegroundColor Cyan

# Build SOAP request
$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 <soap:Header>
  <tem:AuthHeader xmlns:tem="http://webtools.japan.nom">
   <tem:Username>$UserId</tem:Username>
   <tem:Password>placeholder</tem:Password>
  </tem:AuthHeader>
 </soap:Header>
 <soap:Body>
  <GetUserDrives xmlns="http://webtools.japan.nom">
   <UserId xsi:type="xsd:string">$UserId</UserId>
   <Domain xsi:type="xsd:string">$Domain</Domain>
   <OuMapping xsi:type="xsd:string">$OuMapping</OuMapping>
   <AdGroups xsi:type="xsd:string">$AdGroups</AdGroups>
   <Site xsi:type="xsd:string">$Site</Site>
  </GetUserDrives>
 </soap:Body>
</soap:Envelope>
"@

$ServerUrl = "https://gdpmappercb.nomura.com/ClassicMapper.asmx"
$SOAPAction = "http://webtools.japan.nom/GetUserDrives"

Try {
    Write-Host "Making SOAP request to: $ServerUrl" -ForegroundColor Yellow
    Write-Host "Timeout: 30 seconds" -ForegroundColor Yellow
    
    $Response = Send-DMSOAPRequestWithAuth -ServerUrl $ServerUrl -SOAPBody $SOAPBody -SOAPAction $SOAPAction -Username $UserId -Password "placeholder" -Timeout 30000
    
    If ($Response.Success) {
        Write-Host "SOAP request successful!" -ForegroundColor Green
        Write-Host "Response length: $($Response.Content.Length) characters" -ForegroundColor White
        
        # Quick XML check
        Try {
            $XmlDoc = [Xml]$Response.Content
            $ResultNode = $XmlDoc.SelectSingleNode("//*[local-name()='GetUserDrivesResult']")
            If ($ResultNode) {
                $DriveNodes = $ResultNode.SelectNodes(".//*[local-name()='MapperDrive']")
                Write-Host "Found $($DriveNodes.Count) drive mappings in response" -ForegroundColor Green
                
                For ($i = 0; $i -lt $DriveNodes.Count; $i++) {
                    $DriveNode = $DriveNodes[$i]
                    $DriveLetter = $DriveNode.SelectSingleNode("*[local-name()='DriveLetter']")
                    $UncPath = $DriveNode.SelectSingleNode("*[local-name()='UncPath']")
                    
                    Write-Host "Drive $($i + 1): $($DriveLetter.InnerText) -> $($UncPath.InnerText)" -ForegroundColor White
                }
            } Else {
                Write-Host "No GetUserDrivesResult found in response" -ForegroundColor Red
            }
        }
        Catch {
            Write-Host "XML parsing failed: $($_.Exception.Message)" -ForegroundColor Red
        }
    } Else {
        Write-Host "SOAP request failed: $($Response.StatusCode)" -ForegroundColor Red
        If ($Response.Content) {
            Write-Host "Response: $($Response.Content)" -ForegroundColor Red
        }
    }
}
Catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Exception Type: $($_.Exception.GetType().Name)" -ForegroundColor Red
}

Write-Host "Test complete" -ForegroundColor Cyan
