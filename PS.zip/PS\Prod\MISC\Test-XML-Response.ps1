<#
.SYNOPSIS
    Debug script to capture raw XML response from drive mapping service
    
.DESCRIPTION
    This script will make a direct call to the web service and show the raw XML
    response to help identify parsing issues.
#>

# Set execution policy
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force

# Import modules
Try {
    Import-Module ".\Modules\Services\DMServiceCommon.psm1" -Force -ErrorAction Stop
    Import-Module ".\Modules\Framework\DMLogger.psm1" -Force -ErrorAction Stop
    Write-Host "All modules imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "Failed to import modules: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Test parameters
$UserId = "chanwilw"
$Domain = "MYMSNGROUP"
$OuMapping = "MYMSNGROUP.COM/HK/Users/Individual"
$AdGroups = ""  # Empty for now
$Site = "HK"

Write-Host "`n=== Testing Raw XML Response ===" -ForegroundColor Cyan
Write-Host "UserId: $UserId" -ForegroundColor Yellow
Write-Host "Domain: $Domain" -ForegroundColor Yellow
Write-Host "OuMapping: $OuMapping" -ForegroundColor Yellow
Write-Host "Site: $Site" -ForegroundColor Yellow

# Build SOAP request (using the same structure as the working code)
$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 <soap:Header>
  <tem:AuthHeader xmlns:tem="http://webtools.japan.nom">
   <tem:Username>$UserId</tem:Username>
   <tem:Password>placeholder</tem:Password>
  </tem:AuthHeader>
 </soap:Header>
 <soap:Body>
  <GetUserDrives xmlns="http://webtools.japan.nom">
   <UserId xsi:type="xsd:string">$UserId</UserId>
   <Domain xsi:type="xsd:string">$Domain</Domain>
   <OuMapping xsi:type="xsd:string">$OuMapping</OuMapping>
   <AdGroups xsi:type="xsd:string">$AdGroups</AdGroups>
   <Site xsi:type="xsd:string">$Site</Site>
  </GetUserDrives>
 </soap:Body>
</soap:Envelope>
"@

$ServerUrl = "https://gdpmappercb.nomura.com/ClassicMapper.asmx"
$SOAPAction = "http://webtools.japan.nom/GetUserDrives"

Write-Host "`n--- Making SOAP Request ---" -ForegroundColor Green
Write-Host "Server: $ServerUrl" -ForegroundColor White
Write-Host "SOAP Action: $SOAPAction" -ForegroundColor White

Try {
    # Make the SOAP request
    $Response = Send-DMSOAPRequestWithAuth -ServerUrl $ServerUrl -SOAPBody $SOAPBody -SOAPAction $SOAPAction -Username $UserId -Password "placeholder"
    
    If ($Response.Success) {
        Write-Host "`n--- Raw XML Response ---" -ForegroundColor Green
        Write-Host $Response.Content -ForegroundColor White
        
        Write-Host "`n--- Parsed XML Structure ---" -ForegroundColor Green
        Try {
            $XmlDoc = [Xml]$Response.Content
            $XmlDoc | Format-List
            
            Write-Host "`n--- Looking for GetUserDrivesResult ---" -ForegroundColor Green
            $ResultNode = $XmlDoc.SelectSingleNode("//*[local-name()='GetUserDrivesResult']")
            If ($ResultNode) {
                Write-Host "Found GetUserDrivesResult node" -ForegroundColor Green
                Write-Host "Inner XML: $($ResultNode.InnerXml)" -ForegroundColor White
                
                # Look for MapperDrive elements
                $DriveNodes = $ResultNode.SelectNodes(".//*[local-name()='MapperDrive']")
                Write-Host "Found $($DriveNodes.Count) MapperDrive elements" -ForegroundColor Green
                
                For ($i = 0; $i -lt $DriveNodes.Count; $i++) {
                    $DriveNode = $DriveNodes[$i]
                    Write-Host "`nMapperDrive $($i + 1):" -ForegroundColor Yellow
                    Write-Host "  Inner XML: $($DriveNode.InnerXml)" -ForegroundColor White
                    
                    # Check for Drive element
                    $DriveElement = $DriveNode.SelectSingleNode("*[local-name()='Drive']")
                    If ($DriveElement) {
                        Write-Host "  Drive element found: '$($DriveElement.InnerText)'" -ForegroundColor Green
                    } Else {
                        Write-Host "  Drive element NOT found" -ForegroundColor Red
                        Write-Host "  Available child elements: $($DriveNode.ChildNodes | ForEach-Object { $_.LocalName } | Sort-Object | Join-String -Separator ', ')" -ForegroundColor Red
                    }
                }
            } Else {
                Write-Host "GetUserDrivesResult node NOT found" -ForegroundColor Red
                Write-Host "Available nodes: $($XmlDoc.DocumentElement.ChildNodes | ForEach-Object { $_.LocalName } | Sort-Object | Join-String -Separator ', ')" -ForegroundColor Red
            }
        }
        Catch {
            Write-Host "Failed to parse XML: $($_.Exception.Message)" -ForegroundColor Red
        }
    } Else {
        Write-Host "`n--- Request Failed ---" -ForegroundColor Red
        Write-Host "Status Code: $($Response.StatusCode)" -ForegroundColor Red
        Write-Host "Response: $($Response.Content)" -ForegroundColor Red
    }
}
Catch {
    Write-Host "`n--- Error Details ---" -ForegroundColor Red
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Line: $($_.InvocationInfo.ScriptLineNumber)" -ForegroundColor Red
}

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
