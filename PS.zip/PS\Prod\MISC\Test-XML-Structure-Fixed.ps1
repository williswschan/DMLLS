<#
.SYNOPSIS
    Test script to see the exact XML structure returned by the backend
#>

# Import modules
Try {
    Import-Module ".\Modules\Services\DMServiceCommon.psm1" -Force -ErrorAction Stop
    Write-Host "Module imported successfully" -ForegroundColor Green
}
Catch {
    Write-Host "Failed to import module: $($_.Exception.Message)" -ForegroundColor Red
    Exit 1
}

# Test parameters
$UserId = "chanwilw"
$Domain = "MYMSNGROUP"
$OuMapping = "MYMSNGROUP.COM/HK/Users/Individual"
$AdGroups = ""
$Site = "HK"

Write-Host "Testing XML structure..." -ForegroundColor Cyan

# Build SOAP request
$SOAPBody = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 <soap:Header>
  <tem:AuthHeader xmlns:tem="http://webtools.japan.nom">
   <tem:Username>$UserId</tem:Username>
   <tem:Password>placeholder</tem:Password>
  </tem:AuthHeader>
 </soap:Header>
 <soap:Body>
  <GetUserDrives xmlns="http://webtools.japan.nom">
   <UserId xsi:type="xsd:string">$UserId</UserId>
   <Domain xsi:type="xsd:string">$Domain</Domain>
   <OuMapping xsi:type="xsd:string">$OuMapping</OuMapping>
   <AdGroups xsi:type="xsd:string">$AdGroups</AdGroups>
   <Site xsi:type="xsd:string">$Site</Site>
  </GetUserDrives>
 </soap:Body>
</soap:Envelope>
"@

$ServerUrl = "https://gdpmappercb.nomura.com/ClassicMapper.asmx"
$SOAPAction = "http://webtools.japan.nom/GetUserDrives"

Try {
    Write-Host "Making SOAP request..." -ForegroundColor Yellow
    $Response = Send-DMSOAPRequestWithAuth -ServerUrl $ServerUrl -SOAPBody $SOAPBody -SOAPAction $SOAPAction -Username $UserId -Password "placeholder"
    
    If ($Response.Success) {
        Write-Host "SOAP request successful!" -ForegroundColor Green
        
        # Parse XML and show structure
        $XmlDoc = [Xml]$Response.Content
        $ResultNode = $XmlDoc.SelectSingleNode("//*[local-name()='GetUserDrivesResult']")
        
        If ($ResultNode) {
            Write-Host "Found GetUserDrivesResult node" -ForegroundColor Green
            $DriveNodes = $ResultNode.SelectNodes(".//*[local-name()='MapperDrive']")
            Write-Host "Found $($DriveNodes.Count) MapperDrive elements" -ForegroundColor Green
            
            For ($i = 0; $i -lt $DriveNodes.Count; $i++) {
                $DriveNode = $DriveNodes[$i]
                Write-Host "`n--- MapperDrive $($i + 1) Structure ---" -ForegroundColor Yellow
                
                # Show all child elements and their values
                Write-Host "Child elements:" -ForegroundColor Cyan
                ForEach ($Child in $DriveNode.ChildNodes) {
                    If ($Child.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                        Write-Host "  $($Child.LocalName): '$($Child.InnerText)'" -ForegroundColor White
                        
                        # Check if this looks like a drive letter
                        If ($Child.LocalName -match "drive|letter" -or $Child.InnerText -match "^[A-Z]$") {
                            Write-Host "    *** This might be the drive letter! ***" -ForegroundColor Green
                        }
                    }
                }
                
                # Test different ways to get drive letter
                Write-Host "`nTesting drive letter extraction:" -ForegroundColor Cyan
                $Methods = @(
                    @{Name="DriveLetter"; XPath="*[local-name()='DriveLetter']"},
                    @{Name="Drive"; XPath="*[local-name()='Drive']"},
                    @{Name="Letter"; XPath="*[local-name()='Letter']"},
                    @{Name="DriveChar"; XPath="*[local-name()='DriveChar']"},
                    @{Name="MapDrive"; XPath="*[local-name()='MapDrive']"},
                    @{Name="DriveLetter (with namespace)"; XPath="*[local-name()='DriveLetter' and namespace-uri()='http://webtools.japan.nom']"}
                )
                
                ForEach ($Method in $Methods) {
                    $Node = $DriveNode.SelectSingleNode($Method.XPath)
                    If ($Node) {
                        Write-Host "  ✓ $($Method.Name): '$($Node.InnerText)'" -ForegroundColor Green
                    } Else {
                        Write-Host "  ✗ $($Method.Name): Not found" -ForegroundColor Red
                    }
                }
            }
        } Else {
            Write-Host "GetUserDrivesResult node not found" -ForegroundColor Red
        }
    } Else {
        Write-Host "SOAP request failed: $($Response.StatusCode)" -ForegroundColor Red
    }
}
Catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`nTest complete" -ForegroundColor Cyan
